# Webstudio HTTP Client

Enables to optimize the http calls to Webstudio API.
