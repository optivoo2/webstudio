export const cssWideKeywords = new Set([
  "initial",
  "inherit",
  "unset",
  "revert",
  "revert-layer",
]);
