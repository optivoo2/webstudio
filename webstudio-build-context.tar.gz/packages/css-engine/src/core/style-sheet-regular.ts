import { StyleSheet } from "./style-sheet";

export class StyleSheetRegular extends StyleSheet {}
