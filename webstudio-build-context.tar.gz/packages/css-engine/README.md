## CSS Engine

This package is designed to render effectively CSS in the format produced by
Webstudio Builder. It is using CSS variables for all dynamic parts and can
render at runtime as for usage on Live Canvas in the Builder as well as for
extracting a fully static style sheet for production.
