// By default using Vercel's limit https://vercel.com/docs/concepts/limits/overview#serverless-function-payload-size-limit
export const MAX_UPLOAD_SIZE = "4.5";
