# Webstudio Asset Uploader

The asset uploader is the packages that handles all the logic for our assets upload
