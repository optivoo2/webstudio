# trpc-interface

- `trpc-interface` can implement various TRPC server routers.

- it can act as a proxy for TRPC services implemented in any other apps (those services must have the same API interface).
