#!/usr/bin/env node

import { main } from "#cli";

await main();
