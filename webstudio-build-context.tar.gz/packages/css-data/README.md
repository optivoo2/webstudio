# CSS Data

Generated configs and collections from mdn-data into consumable form.
