# Webstudio Prisma client

Package conatining our API to interact with prisma
