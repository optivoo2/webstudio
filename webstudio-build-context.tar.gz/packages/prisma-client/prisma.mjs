import pkg from "./lib/prisma.js";

export const { prisma, Prisma, PrismaClientKnownRequestError, Decimal } = pkg;
