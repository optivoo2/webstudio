const pkg = require("./lib/prisma.js");

exports.prisma = pkg.prisma;
exports.Prisma = pkg.Prisma;
exports.PrismaClientKnownRequestError = pkg.PrismaClientKnownRequestError;
exports.Decimal = pkg.Decimal;
