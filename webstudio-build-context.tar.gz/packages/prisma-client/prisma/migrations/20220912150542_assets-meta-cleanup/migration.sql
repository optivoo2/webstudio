-- AlterTable
ALTER TABLE "Asset" DROP COLUMN "alt",
DROP COLUMN "height",
DROP COLUMN "width";
