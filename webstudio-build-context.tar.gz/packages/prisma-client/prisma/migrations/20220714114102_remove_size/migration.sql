/*
  Warnings:

  - You are about to drop the column `size` on the `Asset` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Asset" DROP COLUMN "size";
