-- AlterTable
ALTER TABLE "Project" DROP COLUMN "devTreeId",
DROP COLUMN "prodTreeId",
DROP COLUMN "prodTreeIdHistory";
