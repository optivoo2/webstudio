-- CreateIndex
CREATE UNIQUE INDEX "InstanceProps_instanceId_treeId_key" ON "InstanceProps"("instanceId", "treeId");
