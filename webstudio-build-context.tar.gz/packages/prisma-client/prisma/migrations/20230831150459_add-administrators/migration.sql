-- AlterEnum
ALTER TYPE "AuthorizationRelation" ADD VALUE 'administrators';
