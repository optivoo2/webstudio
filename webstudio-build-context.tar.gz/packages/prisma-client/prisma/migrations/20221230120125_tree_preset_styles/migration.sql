-- AlterTable
ALTER TABLE "Tree" ADD COLUMN     "presetStyles" TEXT NOT NULL DEFAULT '[]';
