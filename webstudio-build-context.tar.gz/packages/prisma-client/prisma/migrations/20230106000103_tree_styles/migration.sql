-- AlterTable
ALTER TABLE "Tree" ADD COLUMN     "styles" TEXT NOT NULL DEFAULT '[]';
