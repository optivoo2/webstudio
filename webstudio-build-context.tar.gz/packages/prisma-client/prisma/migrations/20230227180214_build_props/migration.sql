-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "props" TEXT NOT NULL DEFAULT '[]';
