-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "dataSources" TEXT NOT NULL DEFAULT '[]';
