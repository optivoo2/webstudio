-- AlterTable
ALTER TABLE "Tree" ADD COLUMN     "instances" TEXT NOT NULL DEFAULT '[]';
