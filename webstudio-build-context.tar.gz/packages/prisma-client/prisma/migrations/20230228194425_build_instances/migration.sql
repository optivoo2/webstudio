-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "instances" TEXT NOT NULL DEFAULT '[]';
