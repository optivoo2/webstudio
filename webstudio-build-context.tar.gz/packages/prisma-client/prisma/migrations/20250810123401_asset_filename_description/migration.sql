-- AlterTable
ALTER TABLE "Asset"
  ADD COLUMN "description" TEXT,
  ADD COLUMN "filename" TEXT;
