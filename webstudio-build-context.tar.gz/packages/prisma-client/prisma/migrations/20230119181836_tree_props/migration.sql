-- AlterTable
ALTER TABLE "Tree" ADD COLUMN     "props" TEXT NOT NULL DEFAULT '[]';
