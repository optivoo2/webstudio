-- AlterTable
ALTER TABLE "Asset" ALTER COLUMN "format" SET NOT NULL;
