-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "styleSourceSelections" TEXT NOT NULL DEFAULT '[]';
