-- AlterTable
ALTER TABLE "Asset" ADD COLUMN     "alt" TEXT;
