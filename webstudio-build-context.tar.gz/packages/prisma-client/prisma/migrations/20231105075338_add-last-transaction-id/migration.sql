-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "lastTransactionId" TEXT;

