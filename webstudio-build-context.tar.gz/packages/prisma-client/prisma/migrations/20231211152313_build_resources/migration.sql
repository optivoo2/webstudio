-- AlterTable
ALTER TABLE "Build" ADD COLUMN     "resources" TEXT NOT NULL DEFAULT '[]';
