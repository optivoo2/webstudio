
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Team
 * 
 */
export type Team = $Result.DefaultSelection<Prisma.$TeamPayload>
/**
 * Model File
 * 
 */
export type File = $Result.DefaultSelection<Prisma.$FilePayload>
/**
 * Model Asset
 * 
 */
export type Asset = $Result.DefaultSelection<Prisma.$AssetPayload>
/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model ClientReferences
 * 
 */
export type ClientReferences = $Result.DefaultSelection<Prisma.$ClientReferencesPayload>
/**
 * Model Product
 * 
 */
export type Product = $Result.DefaultSelection<Prisma.$ProductPayload>
/**
 * Model TransactionLog
 * 
 */
export type TransactionLog = $Result.DefaultSelection<Prisma.$TransactionLogPayload>
/**
 * Model Project
 * 
 */
export type Project = $Result.DefaultSelection<Prisma.$ProjectPayload>
/**
 * Model Build
 * 
 */
export type Build = $Result.DefaultSelection<Prisma.$BuildPayload>
/**
 * Model AuthorizationToken
 * 
 */
export type AuthorizationToken = $Result.DefaultSelection<Prisma.$AuthorizationTokenPayload>
/**
 * Model Domain
 * 
 */
export type Domain = $Result.DefaultSelection<Prisma.$DomainPayload>
/**
 * Model ProjectDomain
 * 
 */
export type ProjectDomain = $Result.DefaultSelection<Prisma.$ProjectDomainPayload>
/**
 * Model UserProduct
 * 
 */
export type UserProduct = $Result.DefaultSelection<Prisma.$UserProductPayload>
/**
 * Model LatestStaticBuildPerProject
 * 
 */
export type LatestStaticBuildPerProject = $Result.DefaultSelection<Prisma.$LatestStaticBuildPerProjectPayload>
/**
 * Model DashboardProject
 * 
 */
export type DashboardProject = $Result.DefaultSelection<Prisma.$DashboardProjectPayload>
/**
 * Model ApprovedMarketplaceProduct
 * 
 */
export type ApprovedMarketplaceProduct = $Result.DefaultSelection<Prisma.$ApprovedMarketplaceProductPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const UploadStatus: {
  UPLOADING: 'UPLOADING',
  UPLOADED: 'UPLOADED'
};

export type UploadStatus = (typeof UploadStatus)[keyof typeof UploadStatus]


export const MarketplaceApprovalStatus: {
  UNLISTED: 'UNLISTED',
  PENDING: 'PENDING',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED'
};

export type MarketplaceApprovalStatus = (typeof MarketplaceApprovalStatus)[keyof typeof MarketplaceApprovalStatus]


export const PublishStatus: {
  PENDING: 'PENDING',
  PUBLISHED: 'PUBLISHED',
  FAILED: 'FAILED'
};

export type PublishStatus = (typeof PublishStatus)[keyof typeof PublishStatus]


export const AuthorizationRelation: {
  viewers: 'viewers',
  editors: 'editors',
  builders: 'builders',
  administrators: 'administrators'
};

export type AuthorizationRelation = (typeof AuthorizationRelation)[keyof typeof AuthorizationRelation]


export const DomainStatus: {
  INITIALIZING: 'INITIALIZING',
  ACTIVE: 'ACTIVE',
  ERROR: 'ERROR',
  PENDING: 'PENDING'
};

export type DomainStatus = (typeof DomainStatus)[keyof typeof DomainStatus]

}

export type UploadStatus = $Enums.UploadStatus

export const UploadStatus: typeof $Enums.UploadStatus

export type MarketplaceApprovalStatus = $Enums.MarketplaceApprovalStatus

export const MarketplaceApprovalStatus: typeof $Enums.MarketplaceApprovalStatus

export type PublishStatus = $Enums.PublishStatus

export const PublishStatus: typeof $Enums.PublishStatus

export type AuthorizationRelation = $Enums.AuthorizationRelation

export const AuthorizationRelation: typeof $Enums.AuthorizationRelation

export type DomainStatus = $Enums.DomainStatus

export const DomainStatus: typeof $Enums.DomainStatus

/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Teams
 * const teams = await prisma.team.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  T extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof T ? T['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<T['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Teams
   * const teams = await prisma.team.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<T, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<'extends', Prisma.TypeMapCb, ExtArgs>

      /**
   * `prisma.team`: Exposes CRUD operations for the **Team** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Teams
    * const teams = await prisma.team.findMany()
    * ```
    */
  get team(): Prisma.TeamDelegate<ExtArgs>;

  /**
   * `prisma.file`: Exposes CRUD operations for the **File** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Files
    * const files = await prisma.file.findMany()
    * ```
    */
  get file(): Prisma.FileDelegate<ExtArgs>;

  /**
   * `prisma.asset`: Exposes CRUD operations for the **Asset** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Assets
    * const assets = await prisma.asset.findMany()
    * ```
    */
  get asset(): Prisma.AssetDelegate<ExtArgs>;

  /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs>;

  /**
   * `prisma.clientReferences`: Exposes CRUD operations for the **ClientReferences** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ClientReferences
    * const clientReferences = await prisma.clientReferences.findMany()
    * ```
    */
  get clientReferences(): Prisma.ClientReferencesDelegate<ExtArgs>;

  /**
   * `prisma.product`: Exposes CRUD operations for the **Product** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Products
    * const products = await prisma.product.findMany()
    * ```
    */
  get product(): Prisma.ProductDelegate<ExtArgs>;

  /**
   * `prisma.transactionLog`: Exposes CRUD operations for the **TransactionLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TransactionLogs
    * const transactionLogs = await prisma.transactionLog.findMany()
    * ```
    */
  get transactionLog(): Prisma.TransactionLogDelegate<ExtArgs>;

  /**
   * `prisma.project`: Exposes CRUD operations for the **Project** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Projects
    * const projects = await prisma.project.findMany()
    * ```
    */
  get project(): Prisma.ProjectDelegate<ExtArgs>;

  /**
   * `prisma.build`: Exposes CRUD operations for the **Build** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Builds
    * const builds = await prisma.build.findMany()
    * ```
    */
  get build(): Prisma.BuildDelegate<ExtArgs>;

  /**
   * `prisma.authorizationToken`: Exposes CRUD operations for the **AuthorizationToken** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AuthorizationTokens
    * const authorizationTokens = await prisma.authorizationToken.findMany()
    * ```
    */
  get authorizationToken(): Prisma.AuthorizationTokenDelegate<ExtArgs>;

  /**
   * `prisma.domain`: Exposes CRUD operations for the **Domain** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Domains
    * const domains = await prisma.domain.findMany()
    * ```
    */
  get domain(): Prisma.DomainDelegate<ExtArgs>;

  /**
   * `prisma.projectDomain`: Exposes CRUD operations for the **ProjectDomain** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ProjectDomains
    * const projectDomains = await prisma.projectDomain.findMany()
    * ```
    */
  get projectDomain(): Prisma.ProjectDomainDelegate<ExtArgs>;

  /**
   * `prisma.userProduct`: Exposes CRUD operations for the **UserProduct** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserProducts
    * const userProducts = await prisma.userProduct.findMany()
    * ```
    */
  get userProduct(): Prisma.UserProductDelegate<ExtArgs>;

  /**
   * `prisma.latestStaticBuildPerProject`: Exposes CRUD operations for the **LatestStaticBuildPerProject** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more LatestStaticBuildPerProjects
    * const latestStaticBuildPerProjects = await prisma.latestStaticBuildPerProject.findMany()
    * ```
    */
  get latestStaticBuildPerProject(): Prisma.LatestStaticBuildPerProjectDelegate<ExtArgs>;

  /**
   * `prisma.dashboardProject`: Exposes CRUD operations for the **DashboardProject** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more DashboardProjects
    * const dashboardProjects = await prisma.dashboardProject.findMany()
    * ```
    */
  get dashboardProject(): Prisma.DashboardProjectDelegate<ExtArgs>;

  /**
   * `prisma.approvedMarketplaceProduct`: Exposes CRUD operations for the **ApprovedMarketplaceProduct** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ApprovedMarketplaceProducts
    * const approvedMarketplaceProducts = await prisma.approvedMarketplaceProduct.findMany()
    * ```
    */
  get approvedMarketplaceProduct(): Prisma.ApprovedMarketplaceProductDelegate<ExtArgs>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError
  export import NotFoundError = runtime.NotFoundError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql

  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics 
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 5.12.1
   * Query Engine version: 473ed3124229e22d881cb7addf559799debae1ab
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON object.
   * This type can be useful to enforce some input to be JSON-compatible or as a super-type to be extended from. 
   */
  export type JsonObject = {[Key in string]?: JsonValue}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON array.
   */
  export interface JsonArray extends Array<JsonValue> {}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches any valid JSON value.
   */
  export type JsonValue = string | number | boolean | JsonObject | JsonArray | null

  /**
   * Matches a JSON object.
   * Unlike `JsonObject`, this type allows undefined and read-only properties.
   */
  export type InputJsonObject = {readonly [Key in string]?: InputJsonValue | null}

  /**
   * Matches a JSON array.
   * Unlike `JsonArray`, readonly arrays are assignable to this type.
   */
  export interface InputJsonArray extends ReadonlyArray<InputJsonValue | null> {}

  /**
   * Matches any valid value that can be used as an input for operations like
   * create and update as the value of a JSON field. Unlike `JsonValue`, this
   * type allows read-only arrays and read-only object properties and disallows
   * `null` at the top level.
   *
   * `null` cannot be used as the value of a JSON field because its meaning
   * would be ambiguous. Use `Prisma.JsonNull` to store the JSON null value or
   * `Prisma.DbNull` to clear the JSON value and set the field to the database
   * NULL value instead.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-by-null-values
   */
  export type InputJsonValue = string | number | boolean | InputJsonObject | InputJsonArray | { toJSON(): unknown }

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? K : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Team: 'Team',
    File: 'File',
    Asset: 'Asset',
    User: 'User',
    ClientReferences: 'ClientReferences',
    Product: 'Product',
    TransactionLog: 'TransactionLog',
    Project: 'Project',
    Build: 'Build',
    AuthorizationToken: 'AuthorizationToken',
    Domain: 'Domain',
    ProjectDomain: 'ProjectDomain',
    UserProduct: 'UserProduct',
    LatestStaticBuildPerProject: 'LatestStaticBuildPerProject',
    DashboardProject: 'DashboardProject',
    ApprovedMarketplaceProduct: 'ApprovedMarketplaceProduct'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }


  interface TypeMapCb extends $Utils.Fn<{extArgs: $Extensions.InternalArgs}, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs']>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meta: {
      modelProps: 'team' | 'file' | 'asset' | 'user' | 'clientReferences' | 'product' | 'transactionLog' | 'project' | 'build' | 'authorizationToken' | 'domain' | 'projectDomain' | 'userProduct' | 'latestStaticBuildPerProject' | 'dashboardProject' | 'approvedMarketplaceProduct'
      txIsolationLevel: Prisma.TransactionIsolationLevel
    },
    model: {
      Team: {
        payload: Prisma.$TeamPayload<ExtArgs>
        fields: Prisma.TeamFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TeamFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TeamFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          findFirst: {
            args: Prisma.TeamFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TeamFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          findMany: {
            args: Prisma.TeamFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>[]
          }
          create: {
            args: Prisma.TeamCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          createMany: {
            args: Prisma.TeamCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.TeamDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          update: {
            args: Prisma.TeamUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          deleteMany: {
            args: Prisma.TeamDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.TeamUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.TeamUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TeamPayload>
          }
          aggregate: {
            args: Prisma.TeamAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateTeam>
          }
          groupBy: {
            args: Prisma.TeamGroupByArgs<ExtArgs>,
            result: $Utils.Optional<TeamGroupByOutputType>[]
          }
          count: {
            args: Prisma.TeamCountArgs<ExtArgs>,
            result: $Utils.Optional<TeamCountAggregateOutputType> | number
          }
        }
      }
      File: {
        payload: Prisma.$FilePayload<ExtArgs>
        fields: Prisma.FileFieldRefs
        operations: {
          findUnique: {
            args: Prisma.FileFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.FileFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          findFirst: {
            args: Prisma.FileFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.FileFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          findMany: {
            args: Prisma.FileFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>[]
          }
          create: {
            args: Prisma.FileCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          createMany: {
            args: Prisma.FileCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.FileDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          update: {
            args: Prisma.FileUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          deleteMany: {
            args: Prisma.FileDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.FileUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.FileUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          aggregate: {
            args: Prisma.FileAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateFile>
          }
          groupBy: {
            args: Prisma.FileGroupByArgs<ExtArgs>,
            result: $Utils.Optional<FileGroupByOutputType>[]
          }
          count: {
            args: Prisma.FileCountArgs<ExtArgs>,
            result: $Utils.Optional<FileCountAggregateOutputType> | number
          }
        }
      }
      Asset: {
        payload: Prisma.$AssetPayload<ExtArgs>
        fields: Prisma.AssetFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AssetFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AssetFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          findFirst: {
            args: Prisma.AssetFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AssetFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          findMany: {
            args: Prisma.AssetFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>[]
          }
          create: {
            args: Prisma.AssetCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          createMany: {
            args: Prisma.AssetCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.AssetDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          update: {
            args: Prisma.AssetUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          deleteMany: {
            args: Prisma.AssetDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.AssetUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.AssetUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AssetPayload>
          }
          aggregate: {
            args: Prisma.AssetAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAsset>
          }
          groupBy: {
            args: Prisma.AssetGroupByArgs<ExtArgs>,
            result: $Utils.Optional<AssetGroupByOutputType>[]
          }
          count: {
            args: Prisma.AssetCountArgs<ExtArgs>,
            result: $Utils.Optional<AssetCountAggregateOutputType> | number
          }
        }
      }
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>,
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      ClientReferences: {
        payload: Prisma.$ClientReferencesPayload<ExtArgs>
        fields: Prisma.ClientReferencesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ClientReferencesFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ClientReferencesFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          findFirst: {
            args: Prisma.ClientReferencesFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ClientReferencesFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          findMany: {
            args: Prisma.ClientReferencesFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>[]
          }
          create: {
            args: Prisma.ClientReferencesCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          createMany: {
            args: Prisma.ClientReferencesCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ClientReferencesDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          update: {
            args: Prisma.ClientReferencesUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          deleteMany: {
            args: Prisma.ClientReferencesDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ClientReferencesUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ClientReferencesUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ClientReferencesPayload>
          }
          aggregate: {
            args: Prisma.ClientReferencesAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateClientReferences>
          }
          groupBy: {
            args: Prisma.ClientReferencesGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ClientReferencesGroupByOutputType>[]
          }
          count: {
            args: Prisma.ClientReferencesCountArgs<ExtArgs>,
            result: $Utils.Optional<ClientReferencesCountAggregateOutputType> | number
          }
        }
      }
      Product: {
        payload: Prisma.$ProductPayload<ExtArgs>
        fields: Prisma.ProductFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProductFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProductFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          findFirst: {
            args: Prisma.ProductFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProductFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          findMany: {
            args: Prisma.ProductFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>[]
          }
          create: {
            args: Prisma.ProductCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          createMany: {
            args: Prisma.ProductCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ProductDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          update: {
            args: Prisma.ProductUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          deleteMany: {
            args: Prisma.ProductDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ProductUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ProductUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          aggregate: {
            args: Prisma.ProductAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateProduct>
          }
          groupBy: {
            args: Prisma.ProductGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProductCountArgs<ExtArgs>,
            result: $Utils.Optional<ProductCountAggregateOutputType> | number
          }
        }
      }
      TransactionLog: {
        payload: Prisma.$TransactionLogPayload<ExtArgs>
        fields: Prisma.TransactionLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TransactionLogFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TransactionLogFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          findFirst: {
            args: Prisma.TransactionLogFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TransactionLogFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          findMany: {
            args: Prisma.TransactionLogFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>[]
          }
          create: {
            args: Prisma.TransactionLogCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          createMany: {
            args: Prisma.TransactionLogCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.TransactionLogDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          update: {
            args: Prisma.TransactionLogUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          deleteMany: {
            args: Prisma.TransactionLogDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.TransactionLogUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.TransactionLogUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$TransactionLogPayload>
          }
          aggregate: {
            args: Prisma.TransactionLogAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateTransactionLog>
          }
          groupBy: {
            args: Prisma.TransactionLogGroupByArgs<ExtArgs>,
            result: $Utils.Optional<TransactionLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.TransactionLogCountArgs<ExtArgs>,
            result: $Utils.Optional<TransactionLogCountAggregateOutputType> | number
          }
        }
      }
      Project: {
        payload: Prisma.$ProjectPayload<ExtArgs>
        fields: Prisma.ProjectFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProjectFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProjectFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          findFirst: {
            args: Prisma.ProjectFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProjectFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          findMany: {
            args: Prisma.ProjectFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>[]
          }
          create: {
            args: Prisma.ProjectCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          createMany: {
            args: Prisma.ProjectCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ProjectDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          update: {
            args: Prisma.ProjectUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          deleteMany: {
            args: Prisma.ProjectDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ProjectUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ProjectUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectPayload>
          }
          aggregate: {
            args: Prisma.ProjectAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateProject>
          }
          groupBy: {
            args: Prisma.ProjectGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ProjectGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProjectCountArgs<ExtArgs>,
            result: $Utils.Optional<ProjectCountAggregateOutputType> | number
          }
        }
      }
      Build: {
        payload: Prisma.$BuildPayload<ExtArgs>
        fields: Prisma.BuildFieldRefs
        operations: {
          findUnique: {
            args: Prisma.BuildFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.BuildFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          findFirst: {
            args: Prisma.BuildFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.BuildFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          findMany: {
            args: Prisma.BuildFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>[]
          }
          create: {
            args: Prisma.BuildCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          createMany: {
            args: Prisma.BuildCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.BuildDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          update: {
            args: Prisma.BuildUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          deleteMany: {
            args: Prisma.BuildDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.BuildUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.BuildUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$BuildPayload>
          }
          aggregate: {
            args: Prisma.BuildAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateBuild>
          }
          groupBy: {
            args: Prisma.BuildGroupByArgs<ExtArgs>,
            result: $Utils.Optional<BuildGroupByOutputType>[]
          }
          count: {
            args: Prisma.BuildCountArgs<ExtArgs>,
            result: $Utils.Optional<BuildCountAggregateOutputType> | number
          }
        }
      }
      AuthorizationToken: {
        payload: Prisma.$AuthorizationTokenPayload<ExtArgs>
        fields: Prisma.AuthorizationTokenFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AuthorizationTokenFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AuthorizationTokenFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          findFirst: {
            args: Prisma.AuthorizationTokenFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AuthorizationTokenFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          findMany: {
            args: Prisma.AuthorizationTokenFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>[]
          }
          create: {
            args: Prisma.AuthorizationTokenCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          createMany: {
            args: Prisma.AuthorizationTokenCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.AuthorizationTokenDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          update: {
            args: Prisma.AuthorizationTokenUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          deleteMany: {
            args: Prisma.AuthorizationTokenDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.AuthorizationTokenUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.AuthorizationTokenUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$AuthorizationTokenPayload>
          }
          aggregate: {
            args: Prisma.AuthorizationTokenAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAuthorizationToken>
          }
          groupBy: {
            args: Prisma.AuthorizationTokenGroupByArgs<ExtArgs>,
            result: $Utils.Optional<AuthorizationTokenGroupByOutputType>[]
          }
          count: {
            args: Prisma.AuthorizationTokenCountArgs<ExtArgs>,
            result: $Utils.Optional<AuthorizationTokenCountAggregateOutputType> | number
          }
        }
      }
      Domain: {
        payload: Prisma.$DomainPayload<ExtArgs>
        fields: Prisma.DomainFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DomainFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DomainFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          findFirst: {
            args: Prisma.DomainFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DomainFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          findMany: {
            args: Prisma.DomainFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>[]
          }
          create: {
            args: Prisma.DomainCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          createMany: {
            args: Prisma.DomainCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.DomainDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          update: {
            args: Prisma.DomainUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          deleteMany: {
            args: Prisma.DomainDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.DomainUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.DomainUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          aggregate: {
            args: Prisma.DomainAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateDomain>
          }
          groupBy: {
            args: Prisma.DomainGroupByArgs<ExtArgs>,
            result: $Utils.Optional<DomainGroupByOutputType>[]
          }
          count: {
            args: Prisma.DomainCountArgs<ExtArgs>,
            result: $Utils.Optional<DomainCountAggregateOutputType> | number
          }
        }
      }
      ProjectDomain: {
        payload: Prisma.$ProjectDomainPayload<ExtArgs>
        fields: Prisma.ProjectDomainFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProjectDomainFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProjectDomainFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          findFirst: {
            args: Prisma.ProjectDomainFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProjectDomainFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          findMany: {
            args: Prisma.ProjectDomainFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>[]
          }
          create: {
            args: Prisma.ProjectDomainCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          createMany: {
            args: Prisma.ProjectDomainCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ProjectDomainDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          update: {
            args: Prisma.ProjectDomainUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          deleteMany: {
            args: Prisma.ProjectDomainDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ProjectDomainUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ProjectDomainUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ProjectDomainPayload>
          }
          aggregate: {
            args: Prisma.ProjectDomainAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateProjectDomain>
          }
          groupBy: {
            args: Prisma.ProjectDomainGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ProjectDomainGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProjectDomainCountArgs<ExtArgs>,
            result: $Utils.Optional<ProjectDomainCountAggregateOutputType> | number
          }
        }
      }
      UserProduct: {
        payload: Prisma.$UserProductPayload<ExtArgs>
        fields: Prisma.UserProductFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserProductFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserProductFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          findFirst: {
            args: Prisma.UserProductFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserProductFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          findMany: {
            args: Prisma.UserProductFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>[]
          }
          create: {
            args: Prisma.UserProductCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          createMany: {
            args: Prisma.UserProductCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.UserProductDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          update: {
            args: Prisma.UserProductUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          deleteMany: {
            args: Prisma.UserProductDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.UserProductUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.UserProductUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$UserProductPayload>
          }
          aggregate: {
            args: Prisma.UserProductAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUserProduct>
          }
          groupBy: {
            args: Prisma.UserProductGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UserProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserProductCountArgs<ExtArgs>,
            result: $Utils.Optional<UserProductCountAggregateOutputType> | number
          }
        }
      }
      LatestStaticBuildPerProject: {
        payload: Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>
        fields: Prisma.LatestStaticBuildPerProjectFieldRefs
        operations: {
          findUnique: {
            args: Prisma.LatestStaticBuildPerProjectFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.LatestStaticBuildPerProjectFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          findFirst: {
            args: Prisma.LatestStaticBuildPerProjectFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.LatestStaticBuildPerProjectFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          findMany: {
            args: Prisma.LatestStaticBuildPerProjectFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>[]
          }
          create: {
            args: Prisma.LatestStaticBuildPerProjectCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          createMany: {
            args: Prisma.LatestStaticBuildPerProjectCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.LatestStaticBuildPerProjectDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          update: {
            args: Prisma.LatestStaticBuildPerProjectUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          deleteMany: {
            args: Prisma.LatestStaticBuildPerProjectDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.LatestStaticBuildPerProjectUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.LatestStaticBuildPerProjectUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$LatestStaticBuildPerProjectPayload>
          }
          aggregate: {
            args: Prisma.LatestStaticBuildPerProjectAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateLatestStaticBuildPerProject>
          }
          groupBy: {
            args: Prisma.LatestStaticBuildPerProjectGroupByArgs<ExtArgs>,
            result: $Utils.Optional<LatestStaticBuildPerProjectGroupByOutputType>[]
          }
          count: {
            args: Prisma.LatestStaticBuildPerProjectCountArgs<ExtArgs>,
            result: $Utils.Optional<LatestStaticBuildPerProjectCountAggregateOutputType> | number
          }
        }
      }
      DashboardProject: {
        payload: Prisma.$DashboardProjectPayload<ExtArgs>
        fields: Prisma.DashboardProjectFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DashboardProjectFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DashboardProjectFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          findFirst: {
            args: Prisma.DashboardProjectFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DashboardProjectFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          findMany: {
            args: Prisma.DashboardProjectFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>[]
          }
          create: {
            args: Prisma.DashboardProjectCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          createMany: {
            args: Prisma.DashboardProjectCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.DashboardProjectDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          update: {
            args: Prisma.DashboardProjectUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          deleteMany: {
            args: Prisma.DashboardProjectDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.DashboardProjectUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.DashboardProjectUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$DashboardProjectPayload>
          }
          aggregate: {
            args: Prisma.DashboardProjectAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateDashboardProject>
          }
          groupBy: {
            args: Prisma.DashboardProjectGroupByArgs<ExtArgs>,
            result: $Utils.Optional<DashboardProjectGroupByOutputType>[]
          }
          count: {
            args: Prisma.DashboardProjectCountArgs<ExtArgs>,
            result: $Utils.Optional<DashboardProjectCountAggregateOutputType> | number
          }
        }
      }
      ApprovedMarketplaceProduct: {
        payload: Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>
        fields: Prisma.ApprovedMarketplaceProductFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ApprovedMarketplaceProductFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ApprovedMarketplaceProductFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          findFirst: {
            args: Prisma.ApprovedMarketplaceProductFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ApprovedMarketplaceProductFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          findMany: {
            args: Prisma.ApprovedMarketplaceProductFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>[]
          }
          create: {
            args: Prisma.ApprovedMarketplaceProductCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          createMany: {
            args: Prisma.ApprovedMarketplaceProductCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          delete: {
            args: Prisma.ApprovedMarketplaceProductDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          update: {
            args: Prisma.ApprovedMarketplaceProductUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          deleteMany: {
            args: Prisma.ApprovedMarketplaceProductDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          updateMany: {
            args: Prisma.ApprovedMarketplaceProductUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
          }
          upsert: {
            args: Prisma.ApprovedMarketplaceProductUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<Prisma.$ApprovedMarketplaceProductPayload>
          }
          aggregate: {
            args: Prisma.ApprovedMarketplaceProductAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateApprovedMarketplaceProduct>
          }
          groupBy: {
            args: Prisma.ApprovedMarketplaceProductGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ApprovedMarketplaceProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.ApprovedMarketplaceProductCountArgs<ExtArgs>,
            result: $Utils.Optional<ApprovedMarketplaceProductCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<'define', Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type TeamCountOutputType
   */

  export type TeamCountOutputType = {
    users: number
  }

  export type TeamCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    users?: boolean | TeamCountOutputTypeCountUsersArgs
  }

  // Custom InputTypes

  /**
   * TeamCountOutputType without action
   */
  export type TeamCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TeamCountOutputType
     */
    select?: TeamCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * TeamCountOutputType without action
   */
  export type TeamCountOutputTypeCountUsersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
  }



  /**
   * Count Type FileCountOutputType
   */

  export type FileCountOutputType = {
    assets: number
  }

  export type FileCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | FileCountOutputTypeCountAssetsArgs
  }

  // Custom InputTypes

  /**
   * FileCountOutputType without action
   */
  export type FileCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the FileCountOutputType
     */
    select?: FileCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * FileCountOutputType without action
   */
  export type FileCountOutputTypeCountAssetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AssetWhereInput
  }



  /**
   * Count Type AssetCountOutputType
   */

  export type AssetCountOutputType = {
    Project: number
    DashboardProject: number
  }

  export type AssetCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    Project?: boolean | AssetCountOutputTypeCountProjectArgs
    DashboardProject?: boolean | AssetCountOutputTypeCountDashboardProjectArgs
  }

  // Custom InputTypes

  /**
   * AssetCountOutputType without action
   */
  export type AssetCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AssetCountOutputType
     */
    select?: AssetCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * AssetCountOutputType without action
   */
  export type AssetCountOutputTypeCountProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectWhereInput
  }


  /**
   * AssetCountOutputType without action
   */
  export type AssetCountOutputTypeCountDashboardProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DashboardProjectWhereInput
  }



  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    projects: number
    clientReferences: number
    checkout: number
    products: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    projects?: boolean | UserCountOutputTypeCountProjectsArgs
    clientReferences?: boolean | UserCountOutputTypeCountClientReferencesArgs
    checkout?: boolean | UserCountOutputTypeCountCheckoutArgs
    products?: boolean | UserCountOutputTypeCountProductsArgs
  }

  // Custom InputTypes

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountProjectsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectWhereInput
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountClientReferencesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ClientReferencesWhereInput
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCheckoutArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionLogWhereInput
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountProductsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserProductWhereInput
  }



  /**
   * Count Type ProductCountOutputType
   */

  export type ProductCountOutputType = {
    checkout: number
    userProducts: number
  }

  export type ProductCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    checkout?: boolean | ProductCountOutputTypeCountCheckoutArgs
    userProducts?: boolean | ProductCountOutputTypeCountUserProductsArgs
  }

  // Custom InputTypes

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductCountOutputType
     */
    select?: ProductCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountCheckoutArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionLogWhereInput
  }


  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountUserProductsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserProductWhereInput
  }



  /**
   * Count Type ProjectCountOutputType
   */

  export type ProjectCountOutputType = {
    build: number
    files: number
    projectDomain: number
    authorizationToken: number
  }

  export type ProjectCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    build?: boolean | ProjectCountOutputTypeCountBuildArgs
    files?: boolean | ProjectCountOutputTypeCountFilesArgs
    projectDomain?: boolean | ProjectCountOutputTypeCountProjectDomainArgs
    authorizationToken?: boolean | ProjectCountOutputTypeCountAuthorizationTokenArgs
  }

  // Custom InputTypes

  /**
   * ProjectCountOutputType without action
   */
  export type ProjectCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectCountOutputType
     */
    select?: ProjectCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * ProjectCountOutputType without action
   */
  export type ProjectCountOutputTypeCountBuildArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BuildWhereInput
  }


  /**
   * ProjectCountOutputType without action
   */
  export type ProjectCountOutputTypeCountFilesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
  }


  /**
   * ProjectCountOutputType without action
   */
  export type ProjectCountOutputTypeCountProjectDomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectDomainWhereInput
  }


  /**
   * ProjectCountOutputType without action
   */
  export type ProjectCountOutputTypeCountAuthorizationTokenArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AuthorizationTokenWhereInput
  }



  /**
   * Count Type DomainCountOutputType
   */

  export type DomainCountOutputType = {
    ProjectDomain: number
  }

  export type DomainCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ProjectDomain?: boolean | DomainCountOutputTypeCountProjectDomainArgs
  }

  // Custom InputTypes

  /**
   * DomainCountOutputType without action
   */
  export type DomainCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DomainCountOutputType
     */
    select?: DomainCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * DomainCountOutputType without action
   */
  export type DomainCountOutputTypeCountProjectDomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectDomainWhereInput
  }



  /**
   * Models
   */

  /**
   * Model Team
   */

  export type AggregateTeam = {
    _count: TeamCountAggregateOutputType | null
    _min: TeamMinAggregateOutputType | null
    _max: TeamMaxAggregateOutputType | null
  }

  export type TeamMinAggregateOutputType = {
    id: string | null
  }

  export type TeamMaxAggregateOutputType = {
    id: string | null
  }

  export type TeamCountAggregateOutputType = {
    id: number
    _all: number
  }


  export type TeamMinAggregateInputType = {
    id?: true
  }

  export type TeamMaxAggregateInputType = {
    id?: true
  }

  export type TeamCountAggregateInputType = {
    id?: true
    _all?: true
  }

  export type TeamAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Team to aggregate.
     */
    where?: TeamWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Teams to fetch.
     */
    orderBy?: TeamOrderByWithRelationInput | TeamOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TeamWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Teams from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Teams.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Teams
    **/
    _count?: true | TeamCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TeamMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TeamMaxAggregateInputType
  }

  export type GetTeamAggregateType<T extends TeamAggregateArgs> = {
        [P in keyof T & keyof AggregateTeam]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTeam[P]>
      : GetScalarType<T[P], AggregateTeam[P]>
  }




  export type TeamGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TeamWhereInput
    orderBy?: TeamOrderByWithAggregationInput | TeamOrderByWithAggregationInput[]
    by: TeamScalarFieldEnum[] | TeamScalarFieldEnum
    having?: TeamScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TeamCountAggregateInputType | true
    _min?: TeamMinAggregateInputType
    _max?: TeamMaxAggregateInputType
  }

  export type TeamGroupByOutputType = {
    id: string
    _count: TeamCountAggregateOutputType | null
    _min: TeamMinAggregateOutputType | null
    _max: TeamMaxAggregateOutputType | null
  }

  type GetTeamGroupByPayload<T extends TeamGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TeamGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TeamGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TeamGroupByOutputType[P]>
            : GetScalarType<T[P], TeamGroupByOutputType[P]>
        }
      >
    >


  export type TeamSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    users?: boolean | Team$usersArgs<ExtArgs>
    _count?: boolean | TeamCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["team"]>

  export type TeamSelectScalar = {
    id?: boolean
  }

  export type TeamInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    users?: boolean | Team$usersArgs<ExtArgs>
    _count?: boolean | TeamCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $TeamPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Team"
    objects: {
      users: Prisma.$UserPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
    }, ExtArgs["result"]["team"]>
    composites: {}
  }


  type TeamGetPayload<S extends boolean | null | undefined | TeamDefaultArgs> = $Result.GetResult<Prisma.$TeamPayload, S>

  type TeamCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<TeamFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: TeamCountAggregateInputType | true
    }

  export interface TeamDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Team'], meta: { name: 'Team' } }
    /**
     * Find zero or one Team that matches the filter.
     * @param {TeamFindUniqueArgs} args - Arguments to find a Team
     * @example
     * // Get one Team
     * const team = await prisma.team.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends TeamFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, TeamFindUniqueArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Team that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {TeamFindUniqueOrThrowArgs} args - Arguments to find a Team
     * @example
     * // Get one Team
     * const team = await prisma.team.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends TeamFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Team that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamFindFirstArgs} args - Arguments to find a Team
     * @example
     * // Get one Team
     * const team = await prisma.team.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends TeamFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamFindFirstArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Team that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamFindFirstOrThrowArgs} args - Arguments to find a Team
     * @example
     * // Get one Team
     * const team = await prisma.team.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends TeamFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Teams that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Teams
     * const teams = await prisma.team.findMany()
     * 
     * // Get first 10 Teams
     * const teams = await prisma.team.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const teamWithIdOnly = await prisma.team.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends TeamFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Team.
     * @param {TeamCreateArgs} args - Arguments to create a Team.
     * @example
     * // Create one Team
     * const Team = await prisma.team.create({
     *   data: {
     *     // ... data to create a Team
     *   }
     * })
     * 
    **/
    create<T extends TeamCreateArgs<ExtArgs>>(
      args: SelectSubset<T, TeamCreateArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Teams.
     *     @param {TeamCreateManyArgs} args - Arguments to create many Teams.
     *     @example
     *     // Create many Teams
     *     const team = await prisma.team.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends TeamCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Team.
     * @param {TeamDeleteArgs} args - Arguments to delete one Team.
     * @example
     * // Delete one Team
     * const Team = await prisma.team.delete({
     *   where: {
     *     // ... filter to delete one Team
     *   }
     * })
     * 
    **/
    delete<T extends TeamDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, TeamDeleteArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Team.
     * @param {TeamUpdateArgs} args - Arguments to update one Team.
     * @example
     * // Update one Team
     * const team = await prisma.team.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends TeamUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, TeamUpdateArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Teams.
     * @param {TeamDeleteManyArgs} args - Arguments to filter Teams to delete.
     * @example
     * // Delete a few Teams
     * const { count } = await prisma.team.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends TeamDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TeamDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Teams.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Teams
     * const team = await prisma.team.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends TeamUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, TeamUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Team.
     * @param {TeamUpsertArgs} args - Arguments to update or create a Team.
     * @example
     * // Update or create a Team
     * const team = await prisma.team.upsert({
     *   create: {
     *     // ... data to create a Team
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Team we want to update
     *   }
     * })
    **/
    upsert<T extends TeamUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, TeamUpsertArgs<ExtArgs>>
    ): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Teams.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamCountArgs} args - Arguments to filter Teams to count.
     * @example
     * // Count the number of Teams
     * const count = await prisma.team.count({
     *   where: {
     *     // ... the filter for the Teams we want to count
     *   }
     * })
    **/
    count<T extends TeamCountArgs>(
      args?: Subset<T, TeamCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TeamCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Team.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TeamAggregateArgs>(args: Subset<T, TeamAggregateArgs>): Prisma.PrismaPromise<GetTeamAggregateType<T>>

    /**
     * Group by Team.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TeamGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TeamGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TeamGroupByArgs['orderBy'] }
        : { orderBy?: TeamGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TeamGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTeamGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Team model
   */
  readonly fields: TeamFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Team.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TeamClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    users<T extends Team$usersArgs<ExtArgs> = {}>(args?: Subset<T, Team$usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Team model
   */ 
  interface TeamFieldRefs {
    readonly id: FieldRef<"Team", 'String'>
  }
    

  // Custom InputTypes

  /**
   * Team findUnique
   */
  export type TeamFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter, which Team to fetch.
     */
    where: TeamWhereUniqueInput
  }


  /**
   * Team findUniqueOrThrow
   */
  export type TeamFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter, which Team to fetch.
     */
    where: TeamWhereUniqueInput
  }


  /**
   * Team findFirst
   */
  export type TeamFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter, which Team to fetch.
     */
    where?: TeamWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Teams to fetch.
     */
    orderBy?: TeamOrderByWithRelationInput | TeamOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Teams.
     */
    cursor?: TeamWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Teams from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Teams.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Teams.
     */
    distinct?: TeamScalarFieldEnum | TeamScalarFieldEnum[]
  }


  /**
   * Team findFirstOrThrow
   */
  export type TeamFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter, which Team to fetch.
     */
    where?: TeamWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Teams to fetch.
     */
    orderBy?: TeamOrderByWithRelationInput | TeamOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Teams.
     */
    cursor?: TeamWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Teams from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Teams.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Teams.
     */
    distinct?: TeamScalarFieldEnum | TeamScalarFieldEnum[]
  }


  /**
   * Team findMany
   */
  export type TeamFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter, which Teams to fetch.
     */
    where?: TeamWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Teams to fetch.
     */
    orderBy?: TeamOrderByWithRelationInput | TeamOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Teams.
     */
    cursor?: TeamWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Teams from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Teams.
     */
    skip?: number
    distinct?: TeamScalarFieldEnum | TeamScalarFieldEnum[]
  }


  /**
   * Team create
   */
  export type TeamCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * The data needed to create a Team.
     */
    data?: XOR<TeamCreateInput, TeamUncheckedCreateInput>
  }


  /**
   * Team createMany
   */
  export type TeamCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Teams.
     */
    data: TeamCreateManyInput | TeamCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Team update
   */
  export type TeamUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * The data needed to update a Team.
     */
    data: XOR<TeamUpdateInput, TeamUncheckedUpdateInput>
    /**
     * Choose, which Team to update.
     */
    where: TeamWhereUniqueInput
  }


  /**
   * Team updateMany
   */
  export type TeamUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Teams.
     */
    data: XOR<TeamUpdateManyMutationInput, TeamUncheckedUpdateManyInput>
    /**
     * Filter which Teams to update
     */
    where?: TeamWhereInput
  }


  /**
   * Team upsert
   */
  export type TeamUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * The filter to search for the Team to update in case it exists.
     */
    where: TeamWhereUniqueInput
    /**
     * In case the Team found by the `where` argument doesn't exist, create a new Team with this data.
     */
    create: XOR<TeamCreateInput, TeamUncheckedCreateInput>
    /**
     * In case the Team was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TeamUpdateInput, TeamUncheckedUpdateInput>
  }


  /**
   * Team delete
   */
  export type TeamDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    /**
     * Filter which Team to delete.
     */
    where: TeamWhereUniqueInput
  }


  /**
   * Team deleteMany
   */
  export type TeamDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Teams to delete
     */
    where?: TeamWhereInput
  }


  /**
   * Team.users
   */
  export type Team$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    cursor?: UserWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }


  /**
   * Team without action
   */
  export type TeamDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
  }



  /**
   * Model File
   */

  export type AggregateFile = {
    _count: FileCountAggregateOutputType | null
    _avg: FileAvgAggregateOutputType | null
    _sum: FileSumAggregateOutputType | null
    _min: FileMinAggregateOutputType | null
    _max: FileMaxAggregateOutputType | null
  }

  export type FileAvgAggregateOutputType = {
    size: number | null
  }

  export type FileSumAggregateOutputType = {
    size: number | null
  }

  export type FileMinAggregateOutputType = {
    name: string | null
    format: string | null
    size: number | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
    meta: string | null
    status: $Enums.UploadStatus | null
    isDeleted: boolean | null
    uploaderProjectId: string | null
  }

  export type FileMaxAggregateOutputType = {
    name: string | null
    format: string | null
    size: number | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
    meta: string | null
    status: $Enums.UploadStatus | null
    isDeleted: boolean | null
    uploaderProjectId: string | null
  }

  export type FileCountAggregateOutputType = {
    name: number
    format: number
    size: number
    description: number
    createdAt: number
    updatedAt: number
    meta: number
    status: number
    isDeleted: number
    uploaderProjectId: number
    _all: number
  }


  export type FileAvgAggregateInputType = {
    size?: true
  }

  export type FileSumAggregateInputType = {
    size?: true
  }

  export type FileMinAggregateInputType = {
    name?: true
    format?: true
    size?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    meta?: true
    status?: true
    isDeleted?: true
    uploaderProjectId?: true
  }

  export type FileMaxAggregateInputType = {
    name?: true
    format?: true
    size?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    meta?: true
    status?: true
    isDeleted?: true
    uploaderProjectId?: true
  }

  export type FileCountAggregateInputType = {
    name?: true
    format?: true
    size?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    meta?: true
    status?: true
    isDeleted?: true
    uploaderProjectId?: true
    _all?: true
  }

  export type FileAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which File to aggregate.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Files
    **/
    _count?: true | FileCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: FileAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: FileSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FileMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FileMaxAggregateInputType
  }

  export type GetFileAggregateType<T extends FileAggregateArgs> = {
        [P in keyof T & keyof AggregateFile]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFile[P]>
      : GetScalarType<T[P], AggregateFile[P]>
  }




  export type FileGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
    orderBy?: FileOrderByWithAggregationInput | FileOrderByWithAggregationInput[]
    by: FileScalarFieldEnum[] | FileScalarFieldEnum
    having?: FileScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FileCountAggregateInputType | true
    _avg?: FileAvgAggregateInputType
    _sum?: FileSumAggregateInputType
    _min?: FileMinAggregateInputType
    _max?: FileMaxAggregateInputType
  }

  export type FileGroupByOutputType = {
    name: string
    format: string
    size: number
    description: string | null
    createdAt: Date
    updatedAt: Date
    meta: string
    status: $Enums.UploadStatus
    isDeleted: boolean
    uploaderProjectId: string | null
    _count: FileCountAggregateOutputType | null
    _avg: FileAvgAggregateOutputType | null
    _sum: FileSumAggregateOutputType | null
    _min: FileMinAggregateOutputType | null
    _max: FileMaxAggregateOutputType | null
  }

  type GetFileGroupByPayload<T extends FileGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<FileGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FileGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FileGroupByOutputType[P]>
            : GetScalarType<T[P], FileGroupByOutputType[P]>
        }
      >
    >


  export type FileSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    name?: boolean
    format?: boolean
    size?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    meta?: boolean
    status?: boolean
    isDeleted?: boolean
    uploaderProjectId?: boolean
    uploaderProject?: boolean | File$uploaderProjectArgs<ExtArgs>
    assets?: boolean | File$assetsArgs<ExtArgs>
    _count?: boolean | FileCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["file"]>

  export type FileSelectScalar = {
    name?: boolean
    format?: boolean
    size?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    meta?: boolean
    status?: boolean
    isDeleted?: boolean
    uploaderProjectId?: boolean
  }

  export type FileInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    uploaderProject?: boolean | File$uploaderProjectArgs<ExtArgs>
    assets?: boolean | File$assetsArgs<ExtArgs>
    _count?: boolean | FileCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $FilePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "File"
    objects: {
      uploaderProject: Prisma.$ProjectPayload<ExtArgs> | null
      assets: Prisma.$AssetPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      name: string
      format: string
      size: number
      description: string | null
      createdAt: Date
      updatedAt: Date
      meta: string
      status: $Enums.UploadStatus
      isDeleted: boolean
      uploaderProjectId: string | null
    }, ExtArgs["result"]["file"]>
    composites: {}
  }


  type FileGetPayload<S extends boolean | null | undefined | FileDefaultArgs> = $Result.GetResult<Prisma.$FilePayload, S>

  type FileCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<FileFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: FileCountAggregateInputType | true
    }

  export interface FileDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['File'], meta: { name: 'File' } }
    /**
     * Find zero or one File that matches the filter.
     * @param {FileFindUniqueArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends FileFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, FileFindUniqueArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one File that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {FileFindUniqueOrThrowArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends FileFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, FileFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first File that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindFirstArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends FileFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, FileFindFirstArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first File that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindFirstOrThrowArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends FileFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, FileFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Files that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Files
     * const files = await prisma.file.findMany()
     * 
     * // Get first 10 Files
     * const files = await prisma.file.findMany({ take: 10 })
     * 
     * // Only select the `name`
     * const fileWithNameOnly = await prisma.file.findMany({ select: { name: true } })
     * 
    **/
    findMany<T extends FileFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, FileFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a File.
     * @param {FileCreateArgs} args - Arguments to create a File.
     * @example
     * // Create one File
     * const File = await prisma.file.create({
     *   data: {
     *     // ... data to create a File
     *   }
     * })
     * 
    **/
    create<T extends FileCreateArgs<ExtArgs>>(
      args: SelectSubset<T, FileCreateArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Files.
     *     @param {FileCreateManyArgs} args - Arguments to create many Files.
     *     @example
     *     // Create many Files
     *     const file = await prisma.file.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends FileCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, FileCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a File.
     * @param {FileDeleteArgs} args - Arguments to delete one File.
     * @example
     * // Delete one File
     * const File = await prisma.file.delete({
     *   where: {
     *     // ... filter to delete one File
     *   }
     * })
     * 
    **/
    delete<T extends FileDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, FileDeleteArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one File.
     * @param {FileUpdateArgs} args - Arguments to update one File.
     * @example
     * // Update one File
     * const file = await prisma.file.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends FileUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, FileUpdateArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Files.
     * @param {FileDeleteManyArgs} args - Arguments to filter Files to delete.
     * @example
     * // Delete a few Files
     * const { count } = await prisma.file.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends FileDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, FileDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Files
     * const file = await prisma.file.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends FileUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, FileUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one File.
     * @param {FileUpsertArgs} args - Arguments to update or create a File.
     * @example
     * // Update or create a File
     * const file = await prisma.file.upsert({
     *   create: {
     *     // ... data to create a File
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the File we want to update
     *   }
     * })
    **/
    upsert<T extends FileUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, FileUpsertArgs<ExtArgs>>
    ): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileCountArgs} args - Arguments to filter Files to count.
     * @example
     * // Count the number of Files
     * const count = await prisma.file.count({
     *   where: {
     *     // ... the filter for the Files we want to count
     *   }
     * })
    **/
    count<T extends FileCountArgs>(
      args?: Subset<T, FileCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FileCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a File.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FileAggregateArgs>(args: Subset<T, FileAggregateArgs>): Prisma.PrismaPromise<GetFileAggregateType<T>>

    /**
     * Group by File.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FileGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FileGroupByArgs['orderBy'] }
        : { orderBy?: FileGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FileGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFileGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the File model
   */
  readonly fields: FileFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for File.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__FileClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    uploaderProject<T extends File$uploaderProjectArgs<ExtArgs> = {}>(args?: Subset<T, File$uploaderProjectArgs<ExtArgs>>): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    assets<T extends File$assetsArgs<ExtArgs> = {}>(args?: Subset<T, File$assetsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the File model
   */ 
  interface FileFieldRefs {
    readonly name: FieldRef<"File", 'String'>
    readonly format: FieldRef<"File", 'String'>
    readonly size: FieldRef<"File", 'Int'>
    readonly description: FieldRef<"File", 'String'>
    readonly createdAt: FieldRef<"File", 'DateTime'>
    readonly updatedAt: FieldRef<"File", 'DateTime'>
    readonly meta: FieldRef<"File", 'String'>
    readonly status: FieldRef<"File", 'UploadStatus'>
    readonly isDeleted: FieldRef<"File", 'Boolean'>
    readonly uploaderProjectId: FieldRef<"File", 'String'>
  }
    

  // Custom InputTypes

  /**
   * File findUnique
   */
  export type FileFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where: FileWhereUniqueInput
  }


  /**
   * File findUniqueOrThrow
   */
  export type FileFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where: FileWhereUniqueInput
  }


  /**
   * File findFirst
   */
  export type FileFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Files.
     */
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }


  /**
   * File findFirstOrThrow
   */
  export type FileFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Files.
     */
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }


  /**
   * File findMany
   */
  export type FileFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which Files to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }


  /**
   * File create
   */
  export type FileCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The data needed to create a File.
     */
    data: XOR<FileCreateInput, FileUncheckedCreateInput>
  }


  /**
   * File createMany
   */
  export type FileCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Files.
     */
    data: FileCreateManyInput | FileCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * File update
   */
  export type FileUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The data needed to update a File.
     */
    data: XOR<FileUpdateInput, FileUncheckedUpdateInput>
    /**
     * Choose, which File to update.
     */
    where: FileWhereUniqueInput
  }


  /**
   * File updateMany
   */
  export type FileUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Files.
     */
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyInput>
    /**
     * Filter which Files to update
     */
    where?: FileWhereInput
  }


  /**
   * File upsert
   */
  export type FileUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The filter to search for the File to update in case it exists.
     */
    where: FileWhereUniqueInput
    /**
     * In case the File found by the `where` argument doesn't exist, create a new File with this data.
     */
    create: XOR<FileCreateInput, FileUncheckedCreateInput>
    /**
     * In case the File was found with the provided `where` argument, update it with this data.
     */
    update: XOR<FileUpdateInput, FileUncheckedUpdateInput>
  }


  /**
   * File delete
   */
  export type FileDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter which File to delete.
     */
    where: FileWhereUniqueInput
  }


  /**
   * File deleteMany
   */
  export type FileDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Files to delete
     */
    where?: FileWhereInput
  }


  /**
   * File.uploaderProject
   */
  export type File$uploaderProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    where?: ProjectWhereInput
  }


  /**
   * File.assets
   */
  export type File$assetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    where?: AssetWhereInput
    orderBy?: AssetOrderByWithRelationInput | AssetOrderByWithRelationInput[]
    cursor?: AssetWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AssetScalarFieldEnum | AssetScalarFieldEnum[]
  }


  /**
   * File without action
   */
  export type FileDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
  }



  /**
   * Model Asset
   */

  export type AggregateAsset = {
    _count: AssetCountAggregateOutputType | null
    _min: AssetMinAggregateOutputType | null
    _max: AssetMaxAggregateOutputType | null
  }

  export type AssetMinAggregateOutputType = {
    id: string | null
    projectId: string | null
    name: string | null
    filename: string | null
    description: string | null
  }

  export type AssetMaxAggregateOutputType = {
    id: string | null
    projectId: string | null
    name: string | null
    filename: string | null
    description: string | null
  }

  export type AssetCountAggregateOutputType = {
    id: number
    projectId: number
    name: number
    filename: number
    description: number
    _all: number
  }


  export type AssetMinAggregateInputType = {
    id?: true
    projectId?: true
    name?: true
    filename?: true
    description?: true
  }

  export type AssetMaxAggregateInputType = {
    id?: true
    projectId?: true
    name?: true
    filename?: true
    description?: true
  }

  export type AssetCountAggregateInputType = {
    id?: true
    projectId?: true
    name?: true
    filename?: true
    description?: true
    _all?: true
  }

  export type AssetAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Asset to aggregate.
     */
    where?: AssetWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Assets to fetch.
     */
    orderBy?: AssetOrderByWithRelationInput | AssetOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AssetWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Assets
    **/
    _count?: true | AssetCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AssetMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AssetMaxAggregateInputType
  }

  export type GetAssetAggregateType<T extends AssetAggregateArgs> = {
        [P in keyof T & keyof AggregateAsset]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAsset[P]>
      : GetScalarType<T[P], AggregateAsset[P]>
  }




  export type AssetGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AssetWhereInput
    orderBy?: AssetOrderByWithAggregationInput | AssetOrderByWithAggregationInput[]
    by: AssetScalarFieldEnum[] | AssetScalarFieldEnum
    having?: AssetScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AssetCountAggregateInputType | true
    _min?: AssetMinAggregateInputType
    _max?: AssetMaxAggregateInputType
  }

  export type AssetGroupByOutputType = {
    id: string
    projectId: string
    name: string
    filename: string | null
    description: string | null
    _count: AssetCountAggregateOutputType | null
    _min: AssetMinAggregateOutputType | null
    _max: AssetMaxAggregateOutputType | null
  }

  type GetAssetGroupByPayload<T extends AssetGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AssetGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AssetGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AssetGroupByOutputType[P]>
            : GetScalarType<T[P], AssetGroupByOutputType[P]>
        }
      >
    >


  export type AssetSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    projectId?: boolean
    name?: boolean
    filename?: boolean
    description?: boolean
    file?: boolean | FileDefaultArgs<ExtArgs>
    Project?: boolean | Asset$ProjectArgs<ExtArgs>
    DashboardProject?: boolean | Asset$DashboardProjectArgs<ExtArgs>
    _count?: boolean | AssetCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["asset"]>

  export type AssetSelectScalar = {
    id?: boolean
    projectId?: boolean
    name?: boolean
    filename?: boolean
    description?: boolean
  }

  export type AssetInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    file?: boolean | FileDefaultArgs<ExtArgs>
    Project?: boolean | Asset$ProjectArgs<ExtArgs>
    DashboardProject?: boolean | Asset$DashboardProjectArgs<ExtArgs>
    _count?: boolean | AssetCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $AssetPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Asset"
    objects: {
      file: Prisma.$FilePayload<ExtArgs>
      Project: Prisma.$ProjectPayload<ExtArgs>[]
      DashboardProject: Prisma.$DashboardProjectPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      projectId: string
      name: string
      filename: string | null
      description: string | null
    }, ExtArgs["result"]["asset"]>
    composites: {}
  }


  type AssetGetPayload<S extends boolean | null | undefined | AssetDefaultArgs> = $Result.GetResult<Prisma.$AssetPayload, S>

  type AssetCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<AssetFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: AssetCountAggregateInputType | true
    }

  export interface AssetDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Asset'], meta: { name: 'Asset' } }
    /**
     * Find zero or one Asset that matches the filter.
     * @param {AssetFindUniqueArgs} args - Arguments to find a Asset
     * @example
     * // Get one Asset
     * const asset = await prisma.asset.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends AssetFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, AssetFindUniqueArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Asset that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {AssetFindUniqueOrThrowArgs} args - Arguments to find a Asset
     * @example
     * // Get one Asset
     * const asset = await prisma.asset.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends AssetFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Asset that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetFindFirstArgs} args - Arguments to find a Asset
     * @example
     * // Get one Asset
     * const asset = await prisma.asset.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends AssetFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetFindFirstArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Asset that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetFindFirstOrThrowArgs} args - Arguments to find a Asset
     * @example
     * // Get one Asset
     * const asset = await prisma.asset.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends AssetFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Assets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Assets
     * const assets = await prisma.asset.findMany()
     * 
     * // Get first 10 Assets
     * const assets = await prisma.asset.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const assetWithIdOnly = await prisma.asset.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends AssetFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Asset.
     * @param {AssetCreateArgs} args - Arguments to create a Asset.
     * @example
     * // Create one Asset
     * const Asset = await prisma.asset.create({
     *   data: {
     *     // ... data to create a Asset
     *   }
     * })
     * 
    **/
    create<T extends AssetCreateArgs<ExtArgs>>(
      args: SelectSubset<T, AssetCreateArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Assets.
     *     @param {AssetCreateManyArgs} args - Arguments to create many Assets.
     *     @example
     *     // Create many Assets
     *     const asset = await prisma.asset.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends AssetCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Asset.
     * @param {AssetDeleteArgs} args - Arguments to delete one Asset.
     * @example
     * // Delete one Asset
     * const Asset = await prisma.asset.delete({
     *   where: {
     *     // ... filter to delete one Asset
     *   }
     * })
     * 
    **/
    delete<T extends AssetDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, AssetDeleteArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Asset.
     * @param {AssetUpdateArgs} args - Arguments to update one Asset.
     * @example
     * // Update one Asset
     * const asset = await prisma.asset.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends AssetUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, AssetUpdateArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Assets.
     * @param {AssetDeleteManyArgs} args - Arguments to filter Assets to delete.
     * @example
     * // Delete a few Assets
     * const { count } = await prisma.asset.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends AssetDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AssetDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Assets
     * const asset = await prisma.asset.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends AssetUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, AssetUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Asset.
     * @param {AssetUpsertArgs} args - Arguments to update or create a Asset.
     * @example
     * // Update or create a Asset
     * const asset = await prisma.asset.upsert({
     *   create: {
     *     // ... data to create a Asset
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Asset we want to update
     *   }
     * })
    **/
    upsert<T extends AssetUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, AssetUpsertArgs<ExtArgs>>
    ): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetCountArgs} args - Arguments to filter Assets to count.
     * @example
     * // Count the number of Assets
     * const count = await prisma.asset.count({
     *   where: {
     *     // ... the filter for the Assets we want to count
     *   }
     * })
    **/
    count<T extends AssetCountArgs>(
      args?: Subset<T, AssetCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AssetCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Asset.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AssetAggregateArgs>(args: Subset<T, AssetAggregateArgs>): Prisma.PrismaPromise<GetAssetAggregateType<T>>

    /**
     * Group by Asset.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AssetGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AssetGroupByArgs['orderBy'] }
        : { orderBy?: AssetGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AssetGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAssetGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Asset model
   */
  readonly fields: AssetFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Asset.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AssetClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    file<T extends FileDefaultArgs<ExtArgs> = {}>(args?: Subset<T, FileDefaultArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    Project<T extends Asset$ProjectArgs<ExtArgs> = {}>(args?: Subset<T, Asset$ProjectArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findMany'> | Null>;

    DashboardProject<T extends Asset$DashboardProjectArgs<ExtArgs> = {}>(args?: Subset<T, Asset$DashboardProjectArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Asset model
   */ 
  interface AssetFieldRefs {
    readonly id: FieldRef<"Asset", 'String'>
    readonly projectId: FieldRef<"Asset", 'String'>
    readonly name: FieldRef<"Asset", 'String'>
    readonly filename: FieldRef<"Asset", 'String'>
    readonly description: FieldRef<"Asset", 'String'>
  }
    

  // Custom InputTypes

  /**
   * Asset findUnique
   */
  export type AssetFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter, which Asset to fetch.
     */
    where: AssetWhereUniqueInput
  }


  /**
   * Asset findUniqueOrThrow
   */
  export type AssetFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter, which Asset to fetch.
     */
    where: AssetWhereUniqueInput
  }


  /**
   * Asset findFirst
   */
  export type AssetFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter, which Asset to fetch.
     */
    where?: AssetWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Assets to fetch.
     */
    orderBy?: AssetOrderByWithRelationInput | AssetOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Assets.
     */
    cursor?: AssetWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Assets.
     */
    distinct?: AssetScalarFieldEnum | AssetScalarFieldEnum[]
  }


  /**
   * Asset findFirstOrThrow
   */
  export type AssetFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter, which Asset to fetch.
     */
    where?: AssetWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Assets to fetch.
     */
    orderBy?: AssetOrderByWithRelationInput | AssetOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Assets.
     */
    cursor?: AssetWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Assets.
     */
    distinct?: AssetScalarFieldEnum | AssetScalarFieldEnum[]
  }


  /**
   * Asset findMany
   */
  export type AssetFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter, which Assets to fetch.
     */
    where?: AssetWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Assets to fetch.
     */
    orderBy?: AssetOrderByWithRelationInput | AssetOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Assets.
     */
    cursor?: AssetWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Assets.
     */
    skip?: number
    distinct?: AssetScalarFieldEnum | AssetScalarFieldEnum[]
  }


  /**
   * Asset create
   */
  export type AssetCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * The data needed to create a Asset.
     */
    data: XOR<AssetCreateInput, AssetUncheckedCreateInput>
  }


  /**
   * Asset createMany
   */
  export type AssetCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Assets.
     */
    data: AssetCreateManyInput | AssetCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Asset update
   */
  export type AssetUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * The data needed to update a Asset.
     */
    data: XOR<AssetUpdateInput, AssetUncheckedUpdateInput>
    /**
     * Choose, which Asset to update.
     */
    where: AssetWhereUniqueInput
  }


  /**
   * Asset updateMany
   */
  export type AssetUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Assets.
     */
    data: XOR<AssetUpdateManyMutationInput, AssetUncheckedUpdateManyInput>
    /**
     * Filter which Assets to update
     */
    where?: AssetWhereInput
  }


  /**
   * Asset upsert
   */
  export type AssetUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * The filter to search for the Asset to update in case it exists.
     */
    where: AssetWhereUniqueInput
    /**
     * In case the Asset found by the `where` argument doesn't exist, create a new Asset with this data.
     */
    create: XOR<AssetCreateInput, AssetUncheckedCreateInput>
    /**
     * In case the Asset was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AssetUpdateInput, AssetUncheckedUpdateInput>
  }


  /**
   * Asset delete
   */
  export type AssetDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    /**
     * Filter which Asset to delete.
     */
    where: AssetWhereUniqueInput
  }


  /**
   * Asset deleteMany
   */
  export type AssetDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Assets to delete
     */
    where?: AssetWhereInput
  }


  /**
   * Asset.Project
   */
  export type Asset$ProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    where?: ProjectWhereInput
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    cursor?: ProjectWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProjectScalarFieldEnum | ProjectScalarFieldEnum[]
  }


  /**
   * Asset.DashboardProject
   */
  export type Asset$DashboardProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    where?: DashboardProjectWhereInput
    orderBy?: DashboardProjectOrderByWithRelationInput | DashboardProjectOrderByWithRelationInput[]
    cursor?: DashboardProjectWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DashboardProjectScalarFieldEnum | DashboardProjectScalarFieldEnum[]
  }


  /**
   * Asset without action
   */
  export type AssetDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
  }



  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    provider: string | null
    image: string | null
    username: string | null
    createdAt: Date | null
    teamId: string | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    provider: string | null
    image: string | null
    username: string | null
    createdAt: Date | null
    teamId: string | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    provider: number
    image: number
    username: number
    createdAt: number
    teamId: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    provider?: true
    image?: true
    username?: true
    createdAt?: true
    teamId?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    provider?: true
    image?: true
    username?: true
    createdAt?: true
    teamId?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    provider?: true
    image?: true
    username?: true
    createdAt?: true
    teamId?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string | null
    provider: string | null
    image: string | null
    username: string | null
    createdAt: Date
    teamId: string | null
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    provider?: boolean
    image?: boolean
    username?: boolean
    createdAt?: boolean
    teamId?: boolean
    team?: boolean | User$teamArgs<ExtArgs>
    projects?: boolean | User$projectsArgs<ExtArgs>
    clientReferences?: boolean | User$clientReferencesArgs<ExtArgs>
    checkout?: boolean | User$checkoutArgs<ExtArgs>
    products?: boolean | User$productsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    provider?: boolean
    image?: boolean
    username?: boolean
    createdAt?: boolean
    teamId?: boolean
  }

  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    team?: boolean | User$teamArgs<ExtArgs>
    projects?: boolean | User$projectsArgs<ExtArgs>
    clientReferences?: boolean | User$clientReferencesArgs<ExtArgs>
    checkout?: boolean | User$checkoutArgs<ExtArgs>
    products?: boolean | User$productsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      team: Prisma.$TeamPayload<ExtArgs> | null
      projects: Prisma.$ProjectPayload<ExtArgs>[]
      clientReferences: Prisma.$ClientReferencesPayload<ExtArgs>[]
      checkout: Prisma.$TransactionLogPayload<ExtArgs>[]
      products: Prisma.$UserProductPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string | null
      provider: string | null
      image: string | null
      username: string | null
      createdAt: Date
      teamId: string | null
    }, ExtArgs["result"]["user"]>
    composites: {}
  }


  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends UserFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one User that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends UserFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends UserFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
    **/
    create<T extends UserCreateArgs<ExtArgs>>(
      args: SelectSubset<T, UserCreateArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Users.
     *     @param {UserCreateManyArgs} args - Arguments to create many Users.
     *     @example
     *     // Create many Users
     *     const user = await prisma.user.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends UserCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
    **/
    delete<T extends UserDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, UserDeleteArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends UserUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpdateArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends UserDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends UserUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
    **/
    upsert<T extends UserUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpsertArgs<ExtArgs>>
    ): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    team<T extends User$teamArgs<ExtArgs> = {}>(args?: Subset<T, User$teamArgs<ExtArgs>>): Prisma__TeamClient<$Result.GetResult<Prisma.$TeamPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    projects<T extends User$projectsArgs<ExtArgs> = {}>(args?: Subset<T, User$projectsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findMany'> | Null>;

    clientReferences<T extends User$clientReferencesArgs<ExtArgs> = {}>(args?: Subset<T, User$clientReferencesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findMany'> | Null>;

    checkout<T extends User$checkoutArgs<ExtArgs> = {}>(args?: Subset<T, User$checkoutArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findMany'> | Null>;

    products<T extends User$productsArgs<ExtArgs> = {}>(args?: Subset<T, User$productsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the User model
   */ 
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly provider: FieldRef<"User", 'String'>
    readonly image: FieldRef<"User", 'String'>
    readonly username: FieldRef<"User", 'String'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly teamId: FieldRef<"User", 'String'>
  }
    

  // Custom InputTypes

  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }


  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }


  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }


  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data?: XOR<UserCreateInput, UserUncheckedCreateInput>
  }


  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
  }


  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }


  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
  }


  /**
   * User.team
   */
  export type User$teamArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Team
     */
    select?: TeamSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TeamInclude<ExtArgs> | null
    where?: TeamWhereInput
  }


  /**
   * User.projects
   */
  export type User$projectsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    where?: ProjectWhereInput
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    cursor?: ProjectWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProjectScalarFieldEnum | ProjectScalarFieldEnum[]
  }


  /**
   * User.clientReferences
   */
  export type User$clientReferencesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    where?: ClientReferencesWhereInput
    orderBy?: ClientReferencesOrderByWithRelationInput | ClientReferencesOrderByWithRelationInput[]
    cursor?: ClientReferencesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ClientReferencesScalarFieldEnum | ClientReferencesScalarFieldEnum[]
  }


  /**
   * User.checkout
   */
  export type User$checkoutArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    where?: TransactionLogWhereInput
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    cursor?: TransactionLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionLogScalarFieldEnum | TransactionLogScalarFieldEnum[]
  }


  /**
   * User.products
   */
  export type User$productsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    where?: UserProductWhereInput
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    cursor?: UserProductWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserProductScalarFieldEnum | UserProductScalarFieldEnum[]
  }


  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
  }



  /**
   * Model ClientReferences
   */

  export type AggregateClientReferences = {
    _count: ClientReferencesCountAggregateOutputType | null
    _min: ClientReferencesMinAggregateOutputType | null
    _max: ClientReferencesMaxAggregateOutputType | null
  }

  export type ClientReferencesMinAggregateOutputType = {
    reference: string | null
    service: string | null
    createdAt: Date | null
    userId: string | null
  }

  export type ClientReferencesMaxAggregateOutputType = {
    reference: string | null
    service: string | null
    createdAt: Date | null
    userId: string | null
  }

  export type ClientReferencesCountAggregateOutputType = {
    reference: number
    service: number
    createdAt: number
    userId: number
    _all: number
  }


  export type ClientReferencesMinAggregateInputType = {
    reference?: true
    service?: true
    createdAt?: true
    userId?: true
  }

  export type ClientReferencesMaxAggregateInputType = {
    reference?: true
    service?: true
    createdAt?: true
    userId?: true
  }

  export type ClientReferencesCountAggregateInputType = {
    reference?: true
    service?: true
    createdAt?: true
    userId?: true
    _all?: true
  }

  export type ClientReferencesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ClientReferences to aggregate.
     */
    where?: ClientReferencesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ClientReferences to fetch.
     */
    orderBy?: ClientReferencesOrderByWithRelationInput | ClientReferencesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ClientReferencesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ClientReferences from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ClientReferences.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ClientReferences
    **/
    _count?: true | ClientReferencesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ClientReferencesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ClientReferencesMaxAggregateInputType
  }

  export type GetClientReferencesAggregateType<T extends ClientReferencesAggregateArgs> = {
        [P in keyof T & keyof AggregateClientReferences]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateClientReferences[P]>
      : GetScalarType<T[P], AggregateClientReferences[P]>
  }




  export type ClientReferencesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ClientReferencesWhereInput
    orderBy?: ClientReferencesOrderByWithAggregationInput | ClientReferencesOrderByWithAggregationInput[]
    by: ClientReferencesScalarFieldEnum[] | ClientReferencesScalarFieldEnum
    having?: ClientReferencesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ClientReferencesCountAggregateInputType | true
    _min?: ClientReferencesMinAggregateInputType
    _max?: ClientReferencesMaxAggregateInputType
  }

  export type ClientReferencesGroupByOutputType = {
    reference: string
    service: string
    createdAt: Date
    userId: string
    _count: ClientReferencesCountAggregateOutputType | null
    _min: ClientReferencesMinAggregateOutputType | null
    _max: ClientReferencesMaxAggregateOutputType | null
  }

  type GetClientReferencesGroupByPayload<T extends ClientReferencesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ClientReferencesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ClientReferencesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ClientReferencesGroupByOutputType[P]>
            : GetScalarType<T[P], ClientReferencesGroupByOutputType[P]>
        }
      >
    >


  export type ClientReferencesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    reference?: boolean
    service?: boolean
    createdAt?: boolean
    userId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["clientReferences"]>

  export type ClientReferencesSelectScalar = {
    reference?: boolean
    service?: boolean
    createdAt?: boolean
    userId?: boolean
  }

  export type ClientReferencesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }


  export type $ClientReferencesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ClientReferences"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      reference: string
      service: string
      createdAt: Date
      userId: string
    }, ExtArgs["result"]["clientReferences"]>
    composites: {}
  }


  type ClientReferencesGetPayload<S extends boolean | null | undefined | ClientReferencesDefaultArgs> = $Result.GetResult<Prisma.$ClientReferencesPayload, S>

  type ClientReferencesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ClientReferencesFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ClientReferencesCountAggregateInputType | true
    }

  export interface ClientReferencesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ClientReferences'], meta: { name: 'ClientReferences' } }
    /**
     * Find zero or one ClientReferences that matches the filter.
     * @param {ClientReferencesFindUniqueArgs} args - Arguments to find a ClientReferences
     * @example
     * // Get one ClientReferences
     * const clientReferences = await prisma.clientReferences.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ClientReferencesFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesFindUniqueArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one ClientReferences that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ClientReferencesFindUniqueOrThrowArgs} args - Arguments to find a ClientReferences
     * @example
     * // Get one ClientReferences
     * const clientReferences = await prisma.clientReferences.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ClientReferencesFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first ClientReferences that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesFindFirstArgs} args - Arguments to find a ClientReferences
     * @example
     * // Get one ClientReferences
     * const clientReferences = await prisma.clientReferences.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ClientReferencesFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesFindFirstArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first ClientReferences that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesFindFirstOrThrowArgs} args - Arguments to find a ClientReferences
     * @example
     * // Get one ClientReferences
     * const clientReferences = await prisma.clientReferences.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ClientReferencesFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more ClientReferences that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ClientReferences
     * const clientReferences = await prisma.clientReferences.findMany()
     * 
     * // Get first 10 ClientReferences
     * const clientReferences = await prisma.clientReferences.findMany({ take: 10 })
     * 
     * // Only select the `reference`
     * const clientReferencesWithReferenceOnly = await prisma.clientReferences.findMany({ select: { reference: true } })
     * 
    **/
    findMany<T extends ClientReferencesFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a ClientReferences.
     * @param {ClientReferencesCreateArgs} args - Arguments to create a ClientReferences.
     * @example
     * // Create one ClientReferences
     * const ClientReferences = await prisma.clientReferences.create({
     *   data: {
     *     // ... data to create a ClientReferences
     *   }
     * })
     * 
    **/
    create<T extends ClientReferencesCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesCreateArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many ClientReferences.
     *     @param {ClientReferencesCreateManyArgs} args - Arguments to create many ClientReferences.
     *     @example
     *     // Create many ClientReferences
     *     const clientReferences = await prisma.clientReferences.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ClientReferencesCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ClientReferences.
     * @param {ClientReferencesDeleteArgs} args - Arguments to delete one ClientReferences.
     * @example
     * // Delete one ClientReferences
     * const ClientReferences = await prisma.clientReferences.delete({
     *   where: {
     *     // ... filter to delete one ClientReferences
     *   }
     * })
     * 
    **/
    delete<T extends ClientReferencesDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesDeleteArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one ClientReferences.
     * @param {ClientReferencesUpdateArgs} args - Arguments to update one ClientReferences.
     * @example
     * // Update one ClientReferences
     * const clientReferences = await prisma.clientReferences.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ClientReferencesUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesUpdateArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more ClientReferences.
     * @param {ClientReferencesDeleteManyArgs} args - Arguments to filter ClientReferences to delete.
     * @example
     * // Delete a few ClientReferences
     * const { count } = await prisma.clientReferences.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ClientReferencesDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ClientReferencesDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ClientReferences.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ClientReferences
     * const clientReferences = await prisma.clientReferences.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ClientReferencesUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ClientReferences.
     * @param {ClientReferencesUpsertArgs} args - Arguments to update or create a ClientReferences.
     * @example
     * // Update or create a ClientReferences
     * const clientReferences = await prisma.clientReferences.upsert({
     *   create: {
     *     // ... data to create a ClientReferences
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ClientReferences we want to update
     *   }
     * })
    **/
    upsert<T extends ClientReferencesUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ClientReferencesUpsertArgs<ExtArgs>>
    ): Prisma__ClientReferencesClient<$Result.GetResult<Prisma.$ClientReferencesPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of ClientReferences.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesCountArgs} args - Arguments to filter ClientReferences to count.
     * @example
     * // Count the number of ClientReferences
     * const count = await prisma.clientReferences.count({
     *   where: {
     *     // ... the filter for the ClientReferences we want to count
     *   }
     * })
    **/
    count<T extends ClientReferencesCountArgs>(
      args?: Subset<T, ClientReferencesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ClientReferencesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ClientReferences.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ClientReferencesAggregateArgs>(args: Subset<T, ClientReferencesAggregateArgs>): Prisma.PrismaPromise<GetClientReferencesAggregateType<T>>

    /**
     * Group by ClientReferences.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClientReferencesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ClientReferencesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ClientReferencesGroupByArgs['orderBy'] }
        : { orderBy?: ClientReferencesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ClientReferencesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetClientReferencesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ClientReferences model
   */
  readonly fields: ClientReferencesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ClientReferences.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ClientReferencesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the ClientReferences model
   */ 
  interface ClientReferencesFieldRefs {
    readonly reference: FieldRef<"ClientReferences", 'String'>
    readonly service: FieldRef<"ClientReferences", 'String'>
    readonly createdAt: FieldRef<"ClientReferences", 'DateTime'>
    readonly userId: FieldRef<"ClientReferences", 'String'>
  }
    

  // Custom InputTypes

  /**
   * ClientReferences findUnique
   */
  export type ClientReferencesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter, which ClientReferences to fetch.
     */
    where: ClientReferencesWhereUniqueInput
  }


  /**
   * ClientReferences findUniqueOrThrow
   */
  export type ClientReferencesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter, which ClientReferences to fetch.
     */
    where: ClientReferencesWhereUniqueInput
  }


  /**
   * ClientReferences findFirst
   */
  export type ClientReferencesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter, which ClientReferences to fetch.
     */
    where?: ClientReferencesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ClientReferences to fetch.
     */
    orderBy?: ClientReferencesOrderByWithRelationInput | ClientReferencesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ClientReferences.
     */
    cursor?: ClientReferencesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ClientReferences from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ClientReferences.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ClientReferences.
     */
    distinct?: ClientReferencesScalarFieldEnum | ClientReferencesScalarFieldEnum[]
  }


  /**
   * ClientReferences findFirstOrThrow
   */
  export type ClientReferencesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter, which ClientReferences to fetch.
     */
    where?: ClientReferencesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ClientReferences to fetch.
     */
    orderBy?: ClientReferencesOrderByWithRelationInput | ClientReferencesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ClientReferences.
     */
    cursor?: ClientReferencesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ClientReferences from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ClientReferences.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ClientReferences.
     */
    distinct?: ClientReferencesScalarFieldEnum | ClientReferencesScalarFieldEnum[]
  }


  /**
   * ClientReferences findMany
   */
  export type ClientReferencesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter, which ClientReferences to fetch.
     */
    where?: ClientReferencesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ClientReferences to fetch.
     */
    orderBy?: ClientReferencesOrderByWithRelationInput | ClientReferencesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ClientReferences.
     */
    cursor?: ClientReferencesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ClientReferences from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ClientReferences.
     */
    skip?: number
    distinct?: ClientReferencesScalarFieldEnum | ClientReferencesScalarFieldEnum[]
  }


  /**
   * ClientReferences create
   */
  export type ClientReferencesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * The data needed to create a ClientReferences.
     */
    data: XOR<ClientReferencesCreateInput, ClientReferencesUncheckedCreateInput>
  }


  /**
   * ClientReferences createMany
   */
  export type ClientReferencesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ClientReferences.
     */
    data: ClientReferencesCreateManyInput | ClientReferencesCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * ClientReferences update
   */
  export type ClientReferencesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * The data needed to update a ClientReferences.
     */
    data: XOR<ClientReferencesUpdateInput, ClientReferencesUncheckedUpdateInput>
    /**
     * Choose, which ClientReferences to update.
     */
    where: ClientReferencesWhereUniqueInput
  }


  /**
   * ClientReferences updateMany
   */
  export type ClientReferencesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ClientReferences.
     */
    data: XOR<ClientReferencesUpdateManyMutationInput, ClientReferencesUncheckedUpdateManyInput>
    /**
     * Filter which ClientReferences to update
     */
    where?: ClientReferencesWhereInput
  }


  /**
   * ClientReferences upsert
   */
  export type ClientReferencesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * The filter to search for the ClientReferences to update in case it exists.
     */
    where: ClientReferencesWhereUniqueInput
    /**
     * In case the ClientReferences found by the `where` argument doesn't exist, create a new ClientReferences with this data.
     */
    create: XOR<ClientReferencesCreateInput, ClientReferencesUncheckedCreateInput>
    /**
     * In case the ClientReferences was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ClientReferencesUpdateInput, ClientReferencesUncheckedUpdateInput>
  }


  /**
   * ClientReferences delete
   */
  export type ClientReferencesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
    /**
     * Filter which ClientReferences to delete.
     */
    where: ClientReferencesWhereUniqueInput
  }


  /**
   * ClientReferences deleteMany
   */
  export type ClientReferencesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ClientReferences to delete
     */
    where?: ClientReferencesWhereInput
  }


  /**
   * ClientReferences without action
   */
  export type ClientReferencesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClientReferences
     */
    select?: ClientReferencesSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ClientReferencesInclude<ExtArgs> | null
  }



  /**
   * Model Product
   */

  export type AggregateProduct = {
    _count: ProductCountAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  export type ProductMinAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    createdAt: Date | null
  }

  export type ProductMaxAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    createdAt: Date | null
  }

  export type ProductCountAggregateOutputType = {
    id: number
    name: number
    description: number
    features: number
    images: number
    meta: number
    createdAt: number
    _all: number
  }


  export type ProductMinAggregateInputType = {
    id?: true
    name?: true
    description?: true
    createdAt?: true
  }

  export type ProductMaxAggregateInputType = {
    id?: true
    name?: true
    description?: true
    createdAt?: true
  }

  export type ProductCountAggregateInputType = {
    id?: true
    name?: true
    description?: true
    features?: true
    images?: true
    meta?: true
    createdAt?: true
    _all?: true
  }

  export type ProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Product to aggregate.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Products
    **/
    _count?: true | ProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductMaxAggregateInputType
  }

  export type GetProductAggregateType<T extends ProductAggregateArgs> = {
        [P in keyof T & keyof AggregateProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProduct[P]>
      : GetScalarType<T[P], AggregateProduct[P]>
  }




  export type ProductGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProductWhereInput
    orderBy?: ProductOrderByWithAggregationInput | ProductOrderByWithAggregationInput[]
    by: ProductScalarFieldEnum[] | ProductScalarFieldEnum
    having?: ProductScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductCountAggregateInputType | true
    _min?: ProductMinAggregateInputType
    _max?: ProductMaxAggregateInputType
  }

  export type ProductGroupByOutputType = {
    id: string
    name: string
    description: string | null
    features: string[]
    images: string[]
    meta: JsonValue
    createdAt: Date
    _count: ProductCountAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  type GetProductGroupByPayload<T extends ProductGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductGroupByOutputType[P]>
            : GetScalarType<T[P], ProductGroupByOutputType[P]>
        }
      >
    >


  export type ProductSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    features?: boolean
    images?: boolean
    meta?: boolean
    createdAt?: boolean
    checkout?: boolean | Product$checkoutArgs<ExtArgs>
    userProducts?: boolean | Product$userProductsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["product"]>

  export type ProductSelectScalar = {
    id?: boolean
    name?: boolean
    description?: boolean
    features?: boolean
    images?: boolean
    meta?: boolean
    createdAt?: boolean
  }

  export type ProductInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    checkout?: boolean | Product$checkoutArgs<ExtArgs>
    userProducts?: boolean | Product$userProductsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $ProductPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Product"
    objects: {
      checkout: Prisma.$TransactionLogPayload<ExtArgs>[]
      userProducts: Prisma.$UserProductPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      description: string | null
      features: string[]
      images: string[]
      meta: Prisma.JsonValue
      createdAt: Date
    }, ExtArgs["result"]["product"]>
    composites: {}
  }


  type ProductGetPayload<S extends boolean | null | undefined | ProductDefaultArgs> = $Result.GetResult<Prisma.$ProductPayload, S>

  type ProductCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ProductFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ProductCountAggregateInputType | true
    }

  export interface ProductDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Product'], meta: { name: 'Product' } }
    /**
     * Find zero or one Product that matches the filter.
     * @param {ProductFindUniqueArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ProductFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ProductFindUniqueArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Product that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ProductFindUniqueOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ProductFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Product that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindFirstArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ProductFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductFindFirstArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Product that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindFirstOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ProductFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Products that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Products
     * const products = await prisma.product.findMany()
     * 
     * // Get first 10 Products
     * const products = await prisma.product.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const productWithIdOnly = await prisma.product.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends ProductFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Product.
     * @param {ProductCreateArgs} args - Arguments to create a Product.
     * @example
     * // Create one Product
     * const Product = await prisma.product.create({
     *   data: {
     *     // ... data to create a Product
     *   }
     * })
     * 
    **/
    create<T extends ProductCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ProductCreateArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Products.
     *     @param {ProductCreateManyArgs} args - Arguments to create many Products.
     *     @example
     *     // Create many Products
     *     const product = await prisma.product.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ProductCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Product.
     * @param {ProductDeleteArgs} args - Arguments to delete one Product.
     * @example
     * // Delete one Product
     * const Product = await prisma.product.delete({
     *   where: {
     *     // ... filter to delete one Product
     *   }
     * })
     * 
    **/
    delete<T extends ProductDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ProductDeleteArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Product.
     * @param {ProductUpdateArgs} args - Arguments to update one Product.
     * @example
     * // Update one Product
     * const product = await prisma.product.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ProductUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ProductUpdateArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Products.
     * @param {ProductDeleteManyArgs} args - Arguments to filter Products to delete.
     * @example
     * // Delete a few Products
     * const { count } = await prisma.product.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ProductDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Products
     * const product = await prisma.product.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ProductUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ProductUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Product.
     * @param {ProductUpsertArgs} args - Arguments to update or create a Product.
     * @example
     * // Update or create a Product
     * const product = await prisma.product.upsert({
     *   create: {
     *     // ... data to create a Product
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Product we want to update
     *   }
     * })
    **/
    upsert<T extends ProductUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ProductUpsertArgs<ExtArgs>>
    ): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductCountArgs} args - Arguments to filter Products to count.
     * @example
     * // Count the number of Products
     * const count = await prisma.product.count({
     *   where: {
     *     // ... the filter for the Products we want to count
     *   }
     * })
    **/
    count<T extends ProductCountArgs>(
      args?: Subset<T, ProductCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductAggregateArgs>(args: Subset<T, ProductAggregateArgs>): Prisma.PrismaPromise<GetProductAggregateType<T>>

    /**
     * Group by Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProductGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProductGroupByArgs['orderBy'] }
        : { orderBy?: ProductGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProductGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Product model
   */
  readonly fields: ProductFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Product.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProductClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    checkout<T extends Product$checkoutArgs<ExtArgs> = {}>(args?: Subset<T, Product$checkoutArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findMany'> | Null>;

    userProducts<T extends Product$userProductsArgs<ExtArgs> = {}>(args?: Subset<T, Product$userProductsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Product model
   */ 
  interface ProductFieldRefs {
    readonly id: FieldRef<"Product", 'String'>
    readonly name: FieldRef<"Product", 'String'>
    readonly description: FieldRef<"Product", 'String'>
    readonly features: FieldRef<"Product", 'String[]'>
    readonly images: FieldRef<"Product", 'String[]'>
    readonly meta: FieldRef<"Product", 'Json'>
    readonly createdAt: FieldRef<"Product", 'DateTime'>
  }
    

  // Custom InputTypes

  /**
   * Product findUnique
   */
  export type ProductFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where: ProductWhereUniqueInput
  }


  /**
   * Product findUniqueOrThrow
   */
  export type ProductFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where: ProductWhereUniqueInput
  }


  /**
   * Product findFirst
   */
  export type ProductFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }


  /**
   * Product findFirstOrThrow
   */
  export type ProductFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }


  /**
   * Product findMany
   */
  export type ProductFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Products to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }


  /**
   * Product create
   */
  export type ProductCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The data needed to create a Product.
     */
    data: XOR<ProductCreateInput, ProductUncheckedCreateInput>
  }


  /**
   * Product createMany
   */
  export type ProductCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Products.
     */
    data: ProductCreateManyInput | ProductCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Product update
   */
  export type ProductUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The data needed to update a Product.
     */
    data: XOR<ProductUpdateInput, ProductUncheckedUpdateInput>
    /**
     * Choose, which Product to update.
     */
    where: ProductWhereUniqueInput
  }


  /**
   * Product updateMany
   */
  export type ProductUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Products.
     */
    data: XOR<ProductUpdateManyMutationInput, ProductUncheckedUpdateManyInput>
    /**
     * Filter which Products to update
     */
    where?: ProductWhereInput
  }


  /**
   * Product upsert
   */
  export type ProductUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The filter to search for the Product to update in case it exists.
     */
    where: ProductWhereUniqueInput
    /**
     * In case the Product found by the `where` argument doesn't exist, create a new Product with this data.
     */
    create: XOR<ProductCreateInput, ProductUncheckedCreateInput>
    /**
     * In case the Product was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProductUpdateInput, ProductUncheckedUpdateInput>
  }


  /**
   * Product delete
   */
  export type ProductDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter which Product to delete.
     */
    where: ProductWhereUniqueInput
  }


  /**
   * Product deleteMany
   */
  export type ProductDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Products to delete
     */
    where?: ProductWhereInput
  }


  /**
   * Product.checkout
   */
  export type Product$checkoutArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    where?: TransactionLogWhereInput
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    cursor?: TransactionLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionLogScalarFieldEnum | TransactionLogScalarFieldEnum[]
  }


  /**
   * Product.userProducts
   */
  export type Product$userProductsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    where?: UserProductWhereInput
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    cursor?: UserProductWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserProductScalarFieldEnum | UserProductScalarFieldEnum[]
  }


  /**
   * Product without action
   */
  export type ProductDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
  }



  /**
   * Model TransactionLog
   */

  export type AggregateTransactionLog = {
    _count: TransactionLogCountAggregateOutputType | null
    _avg: TransactionLogAvgAggregateOutputType | null
    _sum: TransactionLogSumAggregateOutputType | null
    _min: TransactionLogMinAggregateOutputType | null
    _max: TransactionLogMaxAggregateOutputType | null
  }

  export type TransactionLogAvgAggregateOutputType = {
    eventCreated: number | null
  }

  export type TransactionLogSumAggregateOutputType = {
    eventCreated: number | null
  }

  export type TransactionLogMinAggregateOutputType = {
    eventId: string | null
    userId: string | null
    productId: string | null
    createdAt: Date | null
    eventType: string | null
    eventCreated: number | null
    status: string | null
    customerId: string | null
    customerEmail: string | null
    subscriptionId: string | null
    paymentIntent: string | null
  }

  export type TransactionLogMaxAggregateOutputType = {
    eventId: string | null
    userId: string | null
    productId: string | null
    createdAt: Date | null
    eventType: string | null
    eventCreated: number | null
    status: string | null
    customerId: string | null
    customerEmail: string | null
    subscriptionId: string | null
    paymentIntent: string | null
  }

  export type TransactionLogCountAggregateOutputType = {
    eventId: number
    userId: number
    productId: number
    createdAt: number
    eventData: number
    eventType: number
    eventCreated: number
    status: number
    customerId: number
    customerEmail: number
    subscriptionId: number
    paymentIntent: number
    _all: number
  }


  export type TransactionLogAvgAggregateInputType = {
    eventCreated?: true
  }

  export type TransactionLogSumAggregateInputType = {
    eventCreated?: true
  }

  export type TransactionLogMinAggregateInputType = {
    eventId?: true
    userId?: true
    productId?: true
    createdAt?: true
    eventType?: true
    eventCreated?: true
    status?: true
    customerId?: true
    customerEmail?: true
    subscriptionId?: true
    paymentIntent?: true
  }

  export type TransactionLogMaxAggregateInputType = {
    eventId?: true
    userId?: true
    productId?: true
    createdAt?: true
    eventType?: true
    eventCreated?: true
    status?: true
    customerId?: true
    customerEmail?: true
    subscriptionId?: true
    paymentIntent?: true
  }

  export type TransactionLogCountAggregateInputType = {
    eventId?: true
    userId?: true
    productId?: true
    createdAt?: true
    eventData?: true
    eventType?: true
    eventCreated?: true
    status?: true
    customerId?: true
    customerEmail?: true
    subscriptionId?: true
    paymentIntent?: true
    _all?: true
  }

  export type TransactionLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TransactionLog to aggregate.
     */
    where?: TransactionLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionLogs to fetch.
     */
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TransactionLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TransactionLogs
    **/
    _count?: true | TransactionLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TransactionLogAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TransactionLogSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TransactionLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TransactionLogMaxAggregateInputType
  }

  export type GetTransactionLogAggregateType<T extends TransactionLogAggregateArgs> = {
        [P in keyof T & keyof AggregateTransactionLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTransactionLog[P]>
      : GetScalarType<T[P], AggregateTransactionLog[P]>
  }




  export type TransactionLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionLogWhereInput
    orderBy?: TransactionLogOrderByWithAggregationInput | TransactionLogOrderByWithAggregationInput[]
    by: TransactionLogScalarFieldEnum[] | TransactionLogScalarFieldEnum
    having?: TransactionLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TransactionLogCountAggregateInputType | true
    _avg?: TransactionLogAvgAggregateInputType
    _sum?: TransactionLogSumAggregateInputType
    _min?: TransactionLogMinAggregateInputType
    _max?: TransactionLogMaxAggregateInputType
  }

  export type TransactionLogGroupByOutputType = {
    eventId: string
    userId: string | null
    productId: string | null
    createdAt: Date
    eventData: JsonValue | null
    eventType: string | null
    eventCreated: number | null
    status: string | null
    customerId: string | null
    customerEmail: string | null
    subscriptionId: string | null
    paymentIntent: string | null
    _count: TransactionLogCountAggregateOutputType | null
    _avg: TransactionLogAvgAggregateOutputType | null
    _sum: TransactionLogSumAggregateOutputType | null
    _min: TransactionLogMinAggregateOutputType | null
    _max: TransactionLogMaxAggregateOutputType | null
  }

  type GetTransactionLogGroupByPayload<T extends TransactionLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TransactionLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TransactionLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TransactionLogGroupByOutputType[P]>
            : GetScalarType<T[P], TransactionLogGroupByOutputType[P]>
        }
      >
    >


  export type TransactionLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    eventId?: boolean
    userId?: boolean
    productId?: boolean
    createdAt?: boolean
    eventData?: boolean
    eventType?: boolean
    eventCreated?: boolean
    status?: boolean
    customerId?: boolean
    customerEmail?: boolean
    subscriptionId?: boolean
    paymentIntent?: boolean
    user?: boolean | TransactionLog$userArgs<ExtArgs>
    product?: boolean | TransactionLog$productArgs<ExtArgs>
  }, ExtArgs["result"]["transactionLog"]>

  export type TransactionLogSelectScalar = {
    eventId?: boolean
    userId?: boolean
    productId?: boolean
    createdAt?: boolean
    eventData?: boolean
    eventType?: boolean
    eventCreated?: boolean
    status?: boolean
    customerId?: boolean
    customerEmail?: boolean
    subscriptionId?: boolean
    paymentIntent?: boolean
  }

  export type TransactionLogInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | TransactionLog$userArgs<ExtArgs>
    product?: boolean | TransactionLog$productArgs<ExtArgs>
  }


  export type $TransactionLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TransactionLog"
    objects: {
      user: Prisma.$UserPayload<ExtArgs> | null
      product: Prisma.$ProductPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      eventId: string
      userId: string | null
      productId: string | null
      createdAt: Date
      eventData: Prisma.JsonValue | null
      eventType: string | null
      eventCreated: number | null
      status: string | null
      customerId: string | null
      customerEmail: string | null
      subscriptionId: string | null
      paymentIntent: string | null
    }, ExtArgs["result"]["transactionLog"]>
    composites: {}
  }


  type TransactionLogGetPayload<S extends boolean | null | undefined | TransactionLogDefaultArgs> = $Result.GetResult<Prisma.$TransactionLogPayload, S>

  type TransactionLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<TransactionLogFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: TransactionLogCountAggregateInputType | true
    }

  export interface TransactionLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TransactionLog'], meta: { name: 'TransactionLog' } }
    /**
     * Find zero or one TransactionLog that matches the filter.
     * @param {TransactionLogFindUniqueArgs} args - Arguments to find a TransactionLog
     * @example
     * // Get one TransactionLog
     * const transactionLog = await prisma.transactionLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends TransactionLogFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogFindUniqueArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one TransactionLog that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {TransactionLogFindUniqueOrThrowArgs} args - Arguments to find a TransactionLog
     * @example
     * // Get one TransactionLog
     * const transactionLog = await prisma.transactionLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends TransactionLogFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first TransactionLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogFindFirstArgs} args - Arguments to find a TransactionLog
     * @example
     * // Get one TransactionLog
     * const transactionLog = await prisma.transactionLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends TransactionLogFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogFindFirstArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first TransactionLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogFindFirstOrThrowArgs} args - Arguments to find a TransactionLog
     * @example
     * // Get one TransactionLog
     * const transactionLog = await prisma.transactionLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends TransactionLogFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more TransactionLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TransactionLogs
     * const transactionLogs = await prisma.transactionLog.findMany()
     * 
     * // Get first 10 TransactionLogs
     * const transactionLogs = await prisma.transactionLog.findMany({ take: 10 })
     * 
     * // Only select the `eventId`
     * const transactionLogWithEventIdOnly = await prisma.transactionLog.findMany({ select: { eventId: true } })
     * 
    **/
    findMany<T extends TransactionLogFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a TransactionLog.
     * @param {TransactionLogCreateArgs} args - Arguments to create a TransactionLog.
     * @example
     * // Create one TransactionLog
     * const TransactionLog = await prisma.transactionLog.create({
     *   data: {
     *     // ... data to create a TransactionLog
     *   }
     * })
     * 
    **/
    create<T extends TransactionLogCreateArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogCreateArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many TransactionLogs.
     *     @param {TransactionLogCreateManyArgs} args - Arguments to create many TransactionLogs.
     *     @example
     *     // Create many TransactionLogs
     *     const transactionLog = await prisma.transactionLog.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends TransactionLogCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TransactionLog.
     * @param {TransactionLogDeleteArgs} args - Arguments to delete one TransactionLog.
     * @example
     * // Delete one TransactionLog
     * const TransactionLog = await prisma.transactionLog.delete({
     *   where: {
     *     // ... filter to delete one TransactionLog
     *   }
     * })
     * 
    **/
    delete<T extends TransactionLogDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogDeleteArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one TransactionLog.
     * @param {TransactionLogUpdateArgs} args - Arguments to update one TransactionLog.
     * @example
     * // Update one TransactionLog
     * const transactionLog = await prisma.transactionLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends TransactionLogUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogUpdateArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more TransactionLogs.
     * @param {TransactionLogDeleteManyArgs} args - Arguments to filter TransactionLogs to delete.
     * @example
     * // Delete a few TransactionLogs
     * const { count } = await prisma.transactionLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends TransactionLogDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TransactionLogDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TransactionLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TransactionLogs
     * const transactionLog = await prisma.transactionLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends TransactionLogUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TransactionLog.
     * @param {TransactionLogUpsertArgs} args - Arguments to update or create a TransactionLog.
     * @example
     * // Update or create a TransactionLog
     * const transactionLog = await prisma.transactionLog.upsert({
     *   create: {
     *     // ... data to create a TransactionLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TransactionLog we want to update
     *   }
     * })
    **/
    upsert<T extends TransactionLogUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, TransactionLogUpsertArgs<ExtArgs>>
    ): Prisma__TransactionLogClient<$Result.GetResult<Prisma.$TransactionLogPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of TransactionLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogCountArgs} args - Arguments to filter TransactionLogs to count.
     * @example
     * // Count the number of TransactionLogs
     * const count = await prisma.transactionLog.count({
     *   where: {
     *     // ... the filter for the TransactionLogs we want to count
     *   }
     * })
    **/
    count<T extends TransactionLogCountArgs>(
      args?: Subset<T, TransactionLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TransactionLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TransactionLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TransactionLogAggregateArgs>(args: Subset<T, TransactionLogAggregateArgs>): Prisma.PrismaPromise<GetTransactionLogAggregateType<T>>

    /**
     * Group by TransactionLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TransactionLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TransactionLogGroupByArgs['orderBy'] }
        : { orderBy?: TransactionLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TransactionLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTransactionLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TransactionLog model
   */
  readonly fields: TransactionLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TransactionLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TransactionLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    user<T extends TransactionLog$userArgs<ExtArgs> = {}>(args?: Subset<T, TransactionLog$userArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    product<T extends TransactionLog$productArgs<ExtArgs> = {}>(args?: Subset<T, TransactionLog$productArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the TransactionLog model
   */ 
  interface TransactionLogFieldRefs {
    readonly eventId: FieldRef<"TransactionLog", 'String'>
    readonly userId: FieldRef<"TransactionLog", 'String'>
    readonly productId: FieldRef<"TransactionLog", 'String'>
    readonly createdAt: FieldRef<"TransactionLog", 'DateTime'>
    readonly eventData: FieldRef<"TransactionLog", 'Json'>
    readonly eventType: FieldRef<"TransactionLog", 'String'>
    readonly eventCreated: FieldRef<"TransactionLog", 'Int'>
    readonly status: FieldRef<"TransactionLog", 'String'>
    readonly customerId: FieldRef<"TransactionLog", 'String'>
    readonly customerEmail: FieldRef<"TransactionLog", 'String'>
    readonly subscriptionId: FieldRef<"TransactionLog", 'String'>
    readonly paymentIntent: FieldRef<"TransactionLog", 'String'>
  }
    

  // Custom InputTypes

  /**
   * TransactionLog findUnique
   */
  export type TransactionLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter, which TransactionLog to fetch.
     */
    where: TransactionLogWhereUniqueInput
  }


  /**
   * TransactionLog findUniqueOrThrow
   */
  export type TransactionLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter, which TransactionLog to fetch.
     */
    where: TransactionLogWhereUniqueInput
  }


  /**
   * TransactionLog findFirst
   */
  export type TransactionLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter, which TransactionLog to fetch.
     */
    where?: TransactionLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionLogs to fetch.
     */
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TransactionLogs.
     */
    cursor?: TransactionLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TransactionLogs.
     */
    distinct?: TransactionLogScalarFieldEnum | TransactionLogScalarFieldEnum[]
  }


  /**
   * TransactionLog findFirstOrThrow
   */
  export type TransactionLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter, which TransactionLog to fetch.
     */
    where?: TransactionLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionLogs to fetch.
     */
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TransactionLogs.
     */
    cursor?: TransactionLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TransactionLogs.
     */
    distinct?: TransactionLogScalarFieldEnum | TransactionLogScalarFieldEnum[]
  }


  /**
   * TransactionLog findMany
   */
  export type TransactionLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter, which TransactionLogs to fetch.
     */
    where?: TransactionLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionLogs to fetch.
     */
    orderBy?: TransactionLogOrderByWithRelationInput | TransactionLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TransactionLogs.
     */
    cursor?: TransactionLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionLogs.
     */
    skip?: number
    distinct?: TransactionLogScalarFieldEnum | TransactionLogScalarFieldEnum[]
  }


  /**
   * TransactionLog create
   */
  export type TransactionLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * The data needed to create a TransactionLog.
     */
    data: XOR<TransactionLogCreateInput, TransactionLogUncheckedCreateInput>
  }


  /**
   * TransactionLog createMany
   */
  export type TransactionLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TransactionLogs.
     */
    data: TransactionLogCreateManyInput | TransactionLogCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * TransactionLog update
   */
  export type TransactionLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * The data needed to update a TransactionLog.
     */
    data: XOR<TransactionLogUpdateInput, TransactionLogUncheckedUpdateInput>
    /**
     * Choose, which TransactionLog to update.
     */
    where: TransactionLogWhereUniqueInput
  }


  /**
   * TransactionLog updateMany
   */
  export type TransactionLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TransactionLogs.
     */
    data: XOR<TransactionLogUpdateManyMutationInput, TransactionLogUncheckedUpdateManyInput>
    /**
     * Filter which TransactionLogs to update
     */
    where?: TransactionLogWhereInput
  }


  /**
   * TransactionLog upsert
   */
  export type TransactionLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * The filter to search for the TransactionLog to update in case it exists.
     */
    where: TransactionLogWhereUniqueInput
    /**
     * In case the TransactionLog found by the `where` argument doesn't exist, create a new TransactionLog with this data.
     */
    create: XOR<TransactionLogCreateInput, TransactionLogUncheckedCreateInput>
    /**
     * In case the TransactionLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TransactionLogUpdateInput, TransactionLogUncheckedUpdateInput>
  }


  /**
   * TransactionLog delete
   */
  export type TransactionLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
    /**
     * Filter which TransactionLog to delete.
     */
    where: TransactionLogWhereUniqueInput
  }


  /**
   * TransactionLog deleteMany
   */
  export type TransactionLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TransactionLogs to delete
     */
    where?: TransactionLogWhereInput
  }


  /**
   * TransactionLog.user
   */
  export type TransactionLog$userArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }


  /**
   * TransactionLog.product
   */
  export type TransactionLog$productArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProductInclude<ExtArgs> | null
    where?: ProductWhereInput
  }


  /**
   * TransactionLog without action
   */
  export type TransactionLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionLog
     */
    select?: TransactionLogSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: TransactionLogInclude<ExtArgs> | null
  }



  /**
   * Model Project
   */

  export type AggregateProject = {
    _count: ProjectCountAggregateOutputType | null
    _min: ProjectMinAggregateOutputType | null
    _max: ProjectMaxAggregateOutputType | null
  }

  export type ProjectMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    title: string | null
    domain: string | null
    userId: string | null
    isDeleted: boolean | null
    previewImageAssetId: string | null
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus | null
  }

  export type ProjectMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    title: string | null
    domain: string | null
    userId: string | null
    isDeleted: boolean | null
    previewImageAssetId: string | null
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus | null
  }

  export type ProjectCountAggregateOutputType = {
    id: number
    createdAt: number
    title: number
    domain: number
    userId: number
    isDeleted: number
    previewImageAssetId: number
    marketplaceApprovalStatus: number
    _all: number
  }


  export type ProjectMinAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    isDeleted?: true
    previewImageAssetId?: true
    marketplaceApprovalStatus?: true
  }

  export type ProjectMaxAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    isDeleted?: true
    previewImageAssetId?: true
    marketplaceApprovalStatus?: true
  }

  export type ProjectCountAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    isDeleted?: true
    previewImageAssetId?: true
    marketplaceApprovalStatus?: true
    _all?: true
  }

  export type ProjectAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Project to aggregate.
     */
    where?: ProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Projects to fetch.
     */
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Projects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Projects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Projects
    **/
    _count?: true | ProjectCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProjectMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProjectMaxAggregateInputType
  }

  export type GetProjectAggregateType<T extends ProjectAggregateArgs> = {
        [P in keyof T & keyof AggregateProject]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProject[P]>
      : GetScalarType<T[P], AggregateProject[P]>
  }




  export type ProjectGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectWhereInput
    orderBy?: ProjectOrderByWithAggregationInput | ProjectOrderByWithAggregationInput[]
    by: ProjectScalarFieldEnum[] | ProjectScalarFieldEnum
    having?: ProjectScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProjectCountAggregateInputType | true
    _min?: ProjectMinAggregateInputType
    _max?: ProjectMaxAggregateInputType
  }

  export type ProjectGroupByOutputType = {
    id: string
    createdAt: Date
    title: string
    domain: string
    userId: string | null
    isDeleted: boolean
    previewImageAssetId: string | null
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus
    _count: ProjectCountAggregateOutputType | null
    _min: ProjectMinAggregateOutputType | null
    _max: ProjectMaxAggregateOutputType | null
  }

  type GetProjectGroupByPayload<T extends ProjectGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProjectGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProjectGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProjectGroupByOutputType[P]>
            : GetScalarType<T[P], ProjectGroupByOutputType[P]>
        }
      >
    >


  export type ProjectSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    title?: boolean
    domain?: boolean
    userId?: boolean
    isDeleted?: boolean
    previewImageAssetId?: boolean
    marketplaceApprovalStatus?: boolean
    user?: boolean | Project$userArgs<ExtArgs>
    build?: boolean | Project$buildArgs<ExtArgs>
    files?: boolean | Project$filesArgs<ExtArgs>
    projectDomain?: boolean | Project$projectDomainArgs<ExtArgs>
    authorizationToken?: boolean | Project$authorizationTokenArgs<ExtArgs>
    previewImageAsset?: boolean | Project$previewImageAssetArgs<ExtArgs>
    latestStaticBuild?: boolean | Project$latestStaticBuildArgs<ExtArgs>
    _count?: boolean | ProjectCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["project"]>

  export type ProjectSelectScalar = {
    id?: boolean
    createdAt?: boolean
    title?: boolean
    domain?: boolean
    userId?: boolean
    isDeleted?: boolean
    previewImageAssetId?: boolean
    marketplaceApprovalStatus?: boolean
  }

  export type ProjectInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | Project$userArgs<ExtArgs>
    build?: boolean | Project$buildArgs<ExtArgs>
    files?: boolean | Project$filesArgs<ExtArgs>
    projectDomain?: boolean | Project$projectDomainArgs<ExtArgs>
    authorizationToken?: boolean | Project$authorizationTokenArgs<ExtArgs>
    previewImageAsset?: boolean | Project$previewImageAssetArgs<ExtArgs>
    latestStaticBuild?: boolean | Project$latestStaticBuildArgs<ExtArgs>
    _count?: boolean | ProjectCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $ProjectPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Project"
    objects: {
      user: Prisma.$UserPayload<ExtArgs> | null
      build: Prisma.$BuildPayload<ExtArgs>[]
      files: Prisma.$FilePayload<ExtArgs>[]
      projectDomain: Prisma.$ProjectDomainPayload<ExtArgs>[]
      authorizationToken: Prisma.$AuthorizationTokenPayload<ExtArgs>[]
      previewImageAsset: Prisma.$AssetPayload<ExtArgs> | null
      latestStaticBuild: Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      title: string
      domain: string
      userId: string | null
      isDeleted: boolean
      previewImageAssetId: string | null
      marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus
    }, ExtArgs["result"]["project"]>
    composites: {}
  }


  type ProjectGetPayload<S extends boolean | null | undefined | ProjectDefaultArgs> = $Result.GetResult<Prisma.$ProjectPayload, S>

  type ProjectCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ProjectFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ProjectCountAggregateInputType | true
    }

  export interface ProjectDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Project'], meta: { name: 'Project' } }
    /**
     * Find zero or one Project that matches the filter.
     * @param {ProjectFindUniqueArgs} args - Arguments to find a Project
     * @example
     * // Get one Project
     * const project = await prisma.project.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ProjectFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectFindUniqueArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Project that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ProjectFindUniqueOrThrowArgs} args - Arguments to find a Project
     * @example
     * // Get one Project
     * const project = await prisma.project.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ProjectFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Project that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectFindFirstArgs} args - Arguments to find a Project
     * @example
     * // Get one Project
     * const project = await prisma.project.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ProjectFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectFindFirstArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Project that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectFindFirstOrThrowArgs} args - Arguments to find a Project
     * @example
     * // Get one Project
     * const project = await prisma.project.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ProjectFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Projects that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Projects
     * const projects = await prisma.project.findMany()
     * 
     * // Get first 10 Projects
     * const projects = await prisma.project.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const projectWithIdOnly = await prisma.project.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends ProjectFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Project.
     * @param {ProjectCreateArgs} args - Arguments to create a Project.
     * @example
     * // Create one Project
     * const Project = await prisma.project.create({
     *   data: {
     *     // ... data to create a Project
     *   }
     * })
     * 
    **/
    create<T extends ProjectCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectCreateArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Projects.
     *     @param {ProjectCreateManyArgs} args - Arguments to create many Projects.
     *     @example
     *     // Create many Projects
     *     const project = await prisma.project.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ProjectCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Project.
     * @param {ProjectDeleteArgs} args - Arguments to delete one Project.
     * @example
     * // Delete one Project
     * const Project = await prisma.project.delete({
     *   where: {
     *     // ... filter to delete one Project
     *   }
     * })
     * 
    **/
    delete<T extends ProjectDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDeleteArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Project.
     * @param {ProjectUpdateArgs} args - Arguments to update one Project.
     * @example
     * // Update one Project
     * const project = await prisma.project.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ProjectUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectUpdateArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Projects.
     * @param {ProjectDeleteManyArgs} args - Arguments to filter Projects to delete.
     * @example
     * // Delete a few Projects
     * const { count } = await prisma.project.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ProjectDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Projects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Projects
     * const project = await prisma.project.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ProjectUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Project.
     * @param {ProjectUpsertArgs} args - Arguments to update or create a Project.
     * @example
     * // Update or create a Project
     * const project = await prisma.project.upsert({
     *   create: {
     *     // ... data to create a Project
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Project we want to update
     *   }
     * })
    **/
    upsert<T extends ProjectUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectUpsertArgs<ExtArgs>>
    ): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Projects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectCountArgs} args - Arguments to filter Projects to count.
     * @example
     * // Count the number of Projects
     * const count = await prisma.project.count({
     *   where: {
     *     // ... the filter for the Projects we want to count
     *   }
     * })
    **/
    count<T extends ProjectCountArgs>(
      args?: Subset<T, ProjectCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProjectCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Project.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProjectAggregateArgs>(args: Subset<T, ProjectAggregateArgs>): Prisma.PrismaPromise<GetProjectAggregateType<T>>

    /**
     * Group by Project.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProjectGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProjectGroupByArgs['orderBy'] }
        : { orderBy?: ProjectGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProjectGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProjectGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Project model
   */
  readonly fields: ProjectFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Project.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProjectClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    user<T extends Project$userArgs<ExtArgs> = {}>(args?: Subset<T, Project$userArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    build<T extends Project$buildArgs<ExtArgs> = {}>(args?: Subset<T, Project$buildArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findMany'> | Null>;

    files<T extends Project$filesArgs<ExtArgs> = {}>(args?: Subset<T, Project$filesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, 'findMany'> | Null>;

    projectDomain<T extends Project$projectDomainArgs<ExtArgs> = {}>(args?: Subset<T, Project$projectDomainArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findMany'> | Null>;

    authorizationToken<T extends Project$authorizationTokenArgs<ExtArgs> = {}>(args?: Subset<T, Project$authorizationTokenArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findMany'> | Null>;

    previewImageAsset<T extends Project$previewImageAssetArgs<ExtArgs> = {}>(args?: Subset<T, Project$previewImageAssetArgs<ExtArgs>>): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    latestStaticBuild<T extends Project$latestStaticBuildArgs<ExtArgs> = {}>(args?: Subset<T, Project$latestStaticBuildArgs<ExtArgs>>): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Project model
   */ 
  interface ProjectFieldRefs {
    readonly id: FieldRef<"Project", 'String'>
    readonly createdAt: FieldRef<"Project", 'DateTime'>
    readonly title: FieldRef<"Project", 'String'>
    readonly domain: FieldRef<"Project", 'String'>
    readonly userId: FieldRef<"Project", 'String'>
    readonly isDeleted: FieldRef<"Project", 'Boolean'>
    readonly previewImageAssetId: FieldRef<"Project", 'String'>
    readonly marketplaceApprovalStatus: FieldRef<"Project", 'MarketplaceApprovalStatus'>
  }
    

  // Custom InputTypes

  /**
   * Project findUnique
   */
  export type ProjectFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter, which Project to fetch.
     */
    where: ProjectWhereUniqueInput
  }


  /**
   * Project findUniqueOrThrow
   */
  export type ProjectFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter, which Project to fetch.
     */
    where: ProjectWhereUniqueInput
  }


  /**
   * Project findFirst
   */
  export type ProjectFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter, which Project to fetch.
     */
    where?: ProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Projects to fetch.
     */
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Projects.
     */
    cursor?: ProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Projects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Projects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Projects.
     */
    distinct?: ProjectScalarFieldEnum | ProjectScalarFieldEnum[]
  }


  /**
   * Project findFirstOrThrow
   */
  export type ProjectFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter, which Project to fetch.
     */
    where?: ProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Projects to fetch.
     */
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Projects.
     */
    cursor?: ProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Projects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Projects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Projects.
     */
    distinct?: ProjectScalarFieldEnum | ProjectScalarFieldEnum[]
  }


  /**
   * Project findMany
   */
  export type ProjectFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter, which Projects to fetch.
     */
    where?: ProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Projects to fetch.
     */
    orderBy?: ProjectOrderByWithRelationInput | ProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Projects.
     */
    cursor?: ProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Projects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Projects.
     */
    skip?: number
    distinct?: ProjectScalarFieldEnum | ProjectScalarFieldEnum[]
  }


  /**
   * Project create
   */
  export type ProjectCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * The data needed to create a Project.
     */
    data: XOR<ProjectCreateInput, ProjectUncheckedCreateInput>
  }


  /**
   * Project createMany
   */
  export type ProjectCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Projects.
     */
    data: ProjectCreateManyInput | ProjectCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Project update
   */
  export type ProjectUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * The data needed to update a Project.
     */
    data: XOR<ProjectUpdateInput, ProjectUncheckedUpdateInput>
    /**
     * Choose, which Project to update.
     */
    where: ProjectWhereUniqueInput
  }


  /**
   * Project updateMany
   */
  export type ProjectUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Projects.
     */
    data: XOR<ProjectUpdateManyMutationInput, ProjectUncheckedUpdateManyInput>
    /**
     * Filter which Projects to update
     */
    where?: ProjectWhereInput
  }


  /**
   * Project upsert
   */
  export type ProjectUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * The filter to search for the Project to update in case it exists.
     */
    where: ProjectWhereUniqueInput
    /**
     * In case the Project found by the `where` argument doesn't exist, create a new Project with this data.
     */
    create: XOR<ProjectCreateInput, ProjectUncheckedCreateInput>
    /**
     * In case the Project was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProjectUpdateInput, ProjectUncheckedUpdateInput>
  }


  /**
   * Project delete
   */
  export type ProjectDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
    /**
     * Filter which Project to delete.
     */
    where: ProjectWhereUniqueInput
  }


  /**
   * Project deleteMany
   */
  export type ProjectDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Projects to delete
     */
    where?: ProjectWhereInput
  }


  /**
   * Project.user
   */
  export type Project$userArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }


  /**
   * Project.build
   */
  export type Project$buildArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    where?: BuildWhereInput
    orderBy?: BuildOrderByWithRelationInput | BuildOrderByWithRelationInput[]
    cursor?: BuildWhereUniqueInput
    take?: number
    skip?: number
    distinct?: BuildScalarFieldEnum | BuildScalarFieldEnum[]
  }


  /**
   * Project.files
   */
  export type Project$filesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: FileInclude<ExtArgs> | null
    where?: FileWhereInput
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    cursor?: FileWhereUniqueInput
    take?: number
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }


  /**
   * Project.projectDomain
   */
  export type Project$projectDomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    where?: ProjectDomainWhereInput
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    cursor?: ProjectDomainWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProjectDomainScalarFieldEnum | ProjectDomainScalarFieldEnum[]
  }


  /**
   * Project.authorizationToken
   */
  export type Project$authorizationTokenArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    where?: AuthorizationTokenWhereInput
    orderBy?: AuthorizationTokenOrderByWithRelationInput | AuthorizationTokenOrderByWithRelationInput[]
    cursor?: AuthorizationTokenWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AuthorizationTokenScalarFieldEnum | AuthorizationTokenScalarFieldEnum[]
  }


  /**
   * Project.previewImageAsset
   */
  export type Project$previewImageAssetArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    where?: AssetWhereInput
  }


  /**
   * Project.latestStaticBuild
   */
  export type Project$latestStaticBuildArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    where?: LatestStaticBuildPerProjectWhereInput
  }


  /**
   * Project without action
   */
  export type ProjectDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Project
     */
    select?: ProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectInclude<ExtArgs> | null
  }



  /**
   * Model Build
   */

  export type AggregateBuild = {
    _count: BuildCountAggregateOutputType | null
    _avg: BuildAvgAggregateOutputType | null
    _sum: BuildSumAggregateOutputType | null
    _min: BuildMinAggregateOutputType | null
    _max: BuildMaxAggregateOutputType | null
  }

  export type BuildAvgAggregateOutputType = {
    version: number | null
  }

  export type BuildSumAggregateOutputType = {
    version: number | null
  }

  export type BuildMinAggregateOutputType = {
    id: string | null
    version: number | null
    lastTransactionId: string | null
    createdAt: Date | null
    updatedAt: Date | null
    pages: string | null
    projectId: string | null
    breakpoints: string | null
    styles: string | null
    styleSources: string | null
    styleSourceSelections: string | null
    props: string | null
    dataSources: string | null
    resources: string | null
    instances: string | null
    marketplaceProduct: string | null
    deployment: string | null
    publishStatus: $Enums.PublishStatus | null
  }

  export type BuildMaxAggregateOutputType = {
    id: string | null
    version: number | null
    lastTransactionId: string | null
    createdAt: Date | null
    updatedAt: Date | null
    pages: string | null
    projectId: string | null
    breakpoints: string | null
    styles: string | null
    styleSources: string | null
    styleSourceSelections: string | null
    props: string | null
    dataSources: string | null
    resources: string | null
    instances: string | null
    marketplaceProduct: string | null
    deployment: string | null
    publishStatus: $Enums.PublishStatus | null
  }

  export type BuildCountAggregateOutputType = {
    id: number
    version: number
    lastTransactionId: number
    createdAt: number
    updatedAt: number
    pages: number
    projectId: number
    breakpoints: number
    styles: number
    styleSources: number
    styleSourceSelections: number
    props: number
    dataSources: number
    resources: number
    instances: number
    marketplaceProduct: number
    deployment: number
    publishStatus: number
    _all: number
  }


  export type BuildAvgAggregateInputType = {
    version?: true
  }

  export type BuildSumAggregateInputType = {
    version?: true
  }

  export type BuildMinAggregateInputType = {
    id?: true
    version?: true
    lastTransactionId?: true
    createdAt?: true
    updatedAt?: true
    pages?: true
    projectId?: true
    breakpoints?: true
    styles?: true
    styleSources?: true
    styleSourceSelections?: true
    props?: true
    dataSources?: true
    resources?: true
    instances?: true
    marketplaceProduct?: true
    deployment?: true
    publishStatus?: true
  }

  export type BuildMaxAggregateInputType = {
    id?: true
    version?: true
    lastTransactionId?: true
    createdAt?: true
    updatedAt?: true
    pages?: true
    projectId?: true
    breakpoints?: true
    styles?: true
    styleSources?: true
    styleSourceSelections?: true
    props?: true
    dataSources?: true
    resources?: true
    instances?: true
    marketplaceProduct?: true
    deployment?: true
    publishStatus?: true
  }

  export type BuildCountAggregateInputType = {
    id?: true
    version?: true
    lastTransactionId?: true
    createdAt?: true
    updatedAt?: true
    pages?: true
    projectId?: true
    breakpoints?: true
    styles?: true
    styleSources?: true
    styleSourceSelections?: true
    props?: true
    dataSources?: true
    resources?: true
    instances?: true
    marketplaceProduct?: true
    deployment?: true
    publishStatus?: true
    _all?: true
  }

  export type BuildAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Build to aggregate.
     */
    where?: BuildWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Builds to fetch.
     */
    orderBy?: BuildOrderByWithRelationInput | BuildOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: BuildWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Builds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Builds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Builds
    **/
    _count?: true | BuildCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: BuildAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: BuildSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: BuildMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: BuildMaxAggregateInputType
  }

  export type GetBuildAggregateType<T extends BuildAggregateArgs> = {
        [P in keyof T & keyof AggregateBuild]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateBuild[P]>
      : GetScalarType<T[P], AggregateBuild[P]>
  }




  export type BuildGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BuildWhereInput
    orderBy?: BuildOrderByWithAggregationInput | BuildOrderByWithAggregationInput[]
    by: BuildScalarFieldEnum[] | BuildScalarFieldEnum
    having?: BuildScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: BuildCountAggregateInputType | true
    _avg?: BuildAvgAggregateInputType
    _sum?: BuildSumAggregateInputType
    _min?: BuildMinAggregateInputType
    _max?: BuildMaxAggregateInputType
  }

  export type BuildGroupByOutputType = {
    id: string
    version: number
    lastTransactionId: string | null
    createdAt: Date
    updatedAt: Date
    pages: string
    projectId: string
    breakpoints: string
    styles: string
    styleSources: string
    styleSourceSelections: string
    props: string
    dataSources: string
    resources: string
    instances: string
    marketplaceProduct: string
    deployment: string | null
    publishStatus: $Enums.PublishStatus
    _count: BuildCountAggregateOutputType | null
    _avg: BuildAvgAggregateOutputType | null
    _sum: BuildSumAggregateOutputType | null
    _min: BuildMinAggregateOutputType | null
    _max: BuildMaxAggregateOutputType | null
  }

  type GetBuildGroupByPayload<T extends BuildGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<BuildGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof BuildGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], BuildGroupByOutputType[P]>
            : GetScalarType<T[P], BuildGroupByOutputType[P]>
        }
      >
    >


  export type BuildSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    version?: boolean
    lastTransactionId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    pages?: boolean
    projectId?: boolean
    breakpoints?: boolean
    styles?: boolean
    styleSources?: boolean
    styleSourceSelections?: boolean
    props?: boolean
    dataSources?: boolean
    resources?: boolean
    instances?: boolean
    marketplaceProduct?: boolean
    deployment?: boolean
    publishStatus?: boolean
    project?: boolean | ProjectDefaultArgs<ExtArgs>
    latestStaticBuildPerProject?: boolean | Build$latestStaticBuildPerProjectArgs<ExtArgs>
  }, ExtArgs["result"]["build"]>

  export type BuildSelectScalar = {
    id?: boolean
    version?: boolean
    lastTransactionId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    pages?: boolean
    projectId?: boolean
    breakpoints?: boolean
    styles?: boolean
    styleSources?: boolean
    styleSourceSelections?: boolean
    props?: boolean
    dataSources?: boolean
    resources?: boolean
    instances?: boolean
    marketplaceProduct?: boolean
    deployment?: boolean
    publishStatus?: boolean
  }

  export type BuildInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    project?: boolean | ProjectDefaultArgs<ExtArgs>
    latestStaticBuildPerProject?: boolean | Build$latestStaticBuildPerProjectArgs<ExtArgs>
  }


  export type $BuildPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Build"
    objects: {
      project: Prisma.$ProjectPayload<ExtArgs>
      latestStaticBuildPerProject: Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      version: number
      lastTransactionId: string | null
      createdAt: Date
      updatedAt: Date
      pages: string
      projectId: string
      breakpoints: string
      styles: string
      styleSources: string
      styleSourceSelections: string
      props: string
      dataSources: string
      resources: string
      instances: string
      marketplaceProduct: string
      deployment: string | null
      publishStatus: $Enums.PublishStatus
    }, ExtArgs["result"]["build"]>
    composites: {}
  }


  type BuildGetPayload<S extends boolean | null | undefined | BuildDefaultArgs> = $Result.GetResult<Prisma.$BuildPayload, S>

  type BuildCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<BuildFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: BuildCountAggregateInputType | true
    }

  export interface BuildDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Build'], meta: { name: 'Build' } }
    /**
     * Find zero or one Build that matches the filter.
     * @param {BuildFindUniqueArgs} args - Arguments to find a Build
     * @example
     * // Get one Build
     * const build = await prisma.build.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends BuildFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, BuildFindUniqueArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Build that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {BuildFindUniqueOrThrowArgs} args - Arguments to find a Build
     * @example
     * // Get one Build
     * const build = await prisma.build.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends BuildFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Build that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildFindFirstArgs} args - Arguments to find a Build
     * @example
     * // Get one Build
     * const build = await prisma.build.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends BuildFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildFindFirstArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Build that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildFindFirstOrThrowArgs} args - Arguments to find a Build
     * @example
     * // Get one Build
     * const build = await prisma.build.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends BuildFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Builds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Builds
     * const builds = await prisma.build.findMany()
     * 
     * // Get first 10 Builds
     * const builds = await prisma.build.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const buildWithIdOnly = await prisma.build.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends BuildFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Build.
     * @param {BuildCreateArgs} args - Arguments to create a Build.
     * @example
     * // Create one Build
     * const Build = await prisma.build.create({
     *   data: {
     *     // ... data to create a Build
     *   }
     * })
     * 
    **/
    create<T extends BuildCreateArgs<ExtArgs>>(
      args: SelectSubset<T, BuildCreateArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Builds.
     *     @param {BuildCreateManyArgs} args - Arguments to create many Builds.
     *     @example
     *     // Create many Builds
     *     const build = await prisma.build.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends BuildCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Build.
     * @param {BuildDeleteArgs} args - Arguments to delete one Build.
     * @example
     * // Delete one Build
     * const Build = await prisma.build.delete({
     *   where: {
     *     // ... filter to delete one Build
     *   }
     * })
     * 
    **/
    delete<T extends BuildDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, BuildDeleteArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Build.
     * @param {BuildUpdateArgs} args - Arguments to update one Build.
     * @example
     * // Update one Build
     * const build = await prisma.build.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends BuildUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, BuildUpdateArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Builds.
     * @param {BuildDeleteManyArgs} args - Arguments to filter Builds to delete.
     * @example
     * // Delete a few Builds
     * const { count } = await prisma.build.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends BuildDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, BuildDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Builds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Builds
     * const build = await prisma.build.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends BuildUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, BuildUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Build.
     * @param {BuildUpsertArgs} args - Arguments to update or create a Build.
     * @example
     * // Update or create a Build
     * const build = await prisma.build.upsert({
     *   create: {
     *     // ... data to create a Build
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Build we want to update
     *   }
     * })
    **/
    upsert<T extends BuildUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, BuildUpsertArgs<ExtArgs>>
    ): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Builds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildCountArgs} args - Arguments to filter Builds to count.
     * @example
     * // Count the number of Builds
     * const count = await prisma.build.count({
     *   where: {
     *     // ... the filter for the Builds we want to count
     *   }
     * })
    **/
    count<T extends BuildCountArgs>(
      args?: Subset<T, BuildCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], BuildCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Build.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends BuildAggregateArgs>(args: Subset<T, BuildAggregateArgs>): Prisma.PrismaPromise<GetBuildAggregateType<T>>

    /**
     * Group by Build.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BuildGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends BuildGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: BuildGroupByArgs['orderBy'] }
        : { orderBy?: BuildGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, BuildGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetBuildGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Build model
   */
  readonly fields: BuildFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Build.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__BuildClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    project<T extends ProjectDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProjectDefaultArgs<ExtArgs>>): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    latestStaticBuildPerProject<T extends Build$latestStaticBuildPerProjectArgs<ExtArgs> = {}>(args?: Subset<T, Build$latestStaticBuildPerProjectArgs<ExtArgs>>): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Build model
   */ 
  interface BuildFieldRefs {
    readonly id: FieldRef<"Build", 'String'>
    readonly version: FieldRef<"Build", 'Int'>
    readonly lastTransactionId: FieldRef<"Build", 'String'>
    readonly createdAt: FieldRef<"Build", 'DateTime'>
    readonly updatedAt: FieldRef<"Build", 'DateTime'>
    readonly pages: FieldRef<"Build", 'String'>
    readonly projectId: FieldRef<"Build", 'String'>
    readonly breakpoints: FieldRef<"Build", 'String'>
    readonly styles: FieldRef<"Build", 'String'>
    readonly styleSources: FieldRef<"Build", 'String'>
    readonly styleSourceSelections: FieldRef<"Build", 'String'>
    readonly props: FieldRef<"Build", 'String'>
    readonly dataSources: FieldRef<"Build", 'String'>
    readonly resources: FieldRef<"Build", 'String'>
    readonly instances: FieldRef<"Build", 'String'>
    readonly marketplaceProduct: FieldRef<"Build", 'String'>
    readonly deployment: FieldRef<"Build", 'String'>
    readonly publishStatus: FieldRef<"Build", 'PublishStatus'>
  }
    

  // Custom InputTypes

  /**
   * Build findUnique
   */
  export type BuildFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter, which Build to fetch.
     */
    where: BuildWhereUniqueInput
  }


  /**
   * Build findUniqueOrThrow
   */
  export type BuildFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter, which Build to fetch.
     */
    where: BuildWhereUniqueInput
  }


  /**
   * Build findFirst
   */
  export type BuildFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter, which Build to fetch.
     */
    where?: BuildWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Builds to fetch.
     */
    orderBy?: BuildOrderByWithRelationInput | BuildOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Builds.
     */
    cursor?: BuildWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Builds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Builds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Builds.
     */
    distinct?: BuildScalarFieldEnum | BuildScalarFieldEnum[]
  }


  /**
   * Build findFirstOrThrow
   */
  export type BuildFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter, which Build to fetch.
     */
    where?: BuildWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Builds to fetch.
     */
    orderBy?: BuildOrderByWithRelationInput | BuildOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Builds.
     */
    cursor?: BuildWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Builds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Builds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Builds.
     */
    distinct?: BuildScalarFieldEnum | BuildScalarFieldEnum[]
  }


  /**
   * Build findMany
   */
  export type BuildFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter, which Builds to fetch.
     */
    where?: BuildWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Builds to fetch.
     */
    orderBy?: BuildOrderByWithRelationInput | BuildOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Builds.
     */
    cursor?: BuildWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Builds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Builds.
     */
    skip?: number
    distinct?: BuildScalarFieldEnum | BuildScalarFieldEnum[]
  }


  /**
   * Build create
   */
  export type BuildCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * The data needed to create a Build.
     */
    data: XOR<BuildCreateInput, BuildUncheckedCreateInput>
  }


  /**
   * Build createMany
   */
  export type BuildCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Builds.
     */
    data: BuildCreateManyInput | BuildCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Build update
   */
  export type BuildUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * The data needed to update a Build.
     */
    data: XOR<BuildUpdateInput, BuildUncheckedUpdateInput>
    /**
     * Choose, which Build to update.
     */
    where: BuildWhereUniqueInput
  }


  /**
   * Build updateMany
   */
  export type BuildUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Builds.
     */
    data: XOR<BuildUpdateManyMutationInput, BuildUncheckedUpdateManyInput>
    /**
     * Filter which Builds to update
     */
    where?: BuildWhereInput
  }


  /**
   * Build upsert
   */
  export type BuildUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * The filter to search for the Build to update in case it exists.
     */
    where: BuildWhereUniqueInput
    /**
     * In case the Build found by the `where` argument doesn't exist, create a new Build with this data.
     */
    create: XOR<BuildCreateInput, BuildUncheckedCreateInput>
    /**
     * In case the Build was found with the provided `where` argument, update it with this data.
     */
    update: XOR<BuildUpdateInput, BuildUncheckedUpdateInput>
  }


  /**
   * Build delete
   */
  export type BuildDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
    /**
     * Filter which Build to delete.
     */
    where: BuildWhereUniqueInput
  }


  /**
   * Build deleteMany
   */
  export type BuildDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Builds to delete
     */
    where?: BuildWhereInput
  }


  /**
   * Build.latestStaticBuildPerProject
   */
  export type Build$latestStaticBuildPerProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    where?: LatestStaticBuildPerProjectWhereInput
  }


  /**
   * Build without action
   */
  export type BuildDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Build
     */
    select?: BuildSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: BuildInclude<ExtArgs> | null
  }



  /**
   * Model AuthorizationToken
   */

  export type AggregateAuthorizationToken = {
    _count: AuthorizationTokenCountAggregateOutputType | null
    _min: AuthorizationTokenMinAggregateOutputType | null
    _max: AuthorizationTokenMaxAggregateOutputType | null
  }

  export type AuthorizationTokenMinAggregateOutputType = {
    token: string | null
    projectId: string | null
    name: string | null
    relation: $Enums.AuthorizationRelation | null
    createdAt: Date | null
    canClone: boolean | null
    canCopy: boolean | null
  }

  export type AuthorizationTokenMaxAggregateOutputType = {
    token: string | null
    projectId: string | null
    name: string | null
    relation: $Enums.AuthorizationRelation | null
    createdAt: Date | null
    canClone: boolean | null
    canCopy: boolean | null
  }

  export type AuthorizationTokenCountAggregateOutputType = {
    token: number
    projectId: number
    name: number
    relation: number
    createdAt: number
    canClone: number
    canCopy: number
    _all: number
  }


  export type AuthorizationTokenMinAggregateInputType = {
    token?: true
    projectId?: true
    name?: true
    relation?: true
    createdAt?: true
    canClone?: true
    canCopy?: true
  }

  export type AuthorizationTokenMaxAggregateInputType = {
    token?: true
    projectId?: true
    name?: true
    relation?: true
    createdAt?: true
    canClone?: true
    canCopy?: true
  }

  export type AuthorizationTokenCountAggregateInputType = {
    token?: true
    projectId?: true
    name?: true
    relation?: true
    createdAt?: true
    canClone?: true
    canCopy?: true
    _all?: true
  }

  export type AuthorizationTokenAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AuthorizationToken to aggregate.
     */
    where?: AuthorizationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AuthorizationTokens to fetch.
     */
    orderBy?: AuthorizationTokenOrderByWithRelationInput | AuthorizationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AuthorizationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AuthorizationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AuthorizationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AuthorizationTokens
    **/
    _count?: true | AuthorizationTokenCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AuthorizationTokenMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AuthorizationTokenMaxAggregateInputType
  }

  export type GetAuthorizationTokenAggregateType<T extends AuthorizationTokenAggregateArgs> = {
        [P in keyof T & keyof AggregateAuthorizationToken]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAuthorizationToken[P]>
      : GetScalarType<T[P], AggregateAuthorizationToken[P]>
  }




  export type AuthorizationTokenGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AuthorizationTokenWhereInput
    orderBy?: AuthorizationTokenOrderByWithAggregationInput | AuthorizationTokenOrderByWithAggregationInput[]
    by: AuthorizationTokenScalarFieldEnum[] | AuthorizationTokenScalarFieldEnum
    having?: AuthorizationTokenScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AuthorizationTokenCountAggregateInputType | true
    _min?: AuthorizationTokenMinAggregateInputType
    _max?: AuthorizationTokenMaxAggregateInputType
  }

  export type AuthorizationTokenGroupByOutputType = {
    token: string
    projectId: string
    name: string
    relation: $Enums.AuthorizationRelation
    createdAt: Date
    canClone: boolean
    canCopy: boolean
    _count: AuthorizationTokenCountAggregateOutputType | null
    _min: AuthorizationTokenMinAggregateOutputType | null
    _max: AuthorizationTokenMaxAggregateOutputType | null
  }

  type GetAuthorizationTokenGroupByPayload<T extends AuthorizationTokenGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AuthorizationTokenGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AuthorizationTokenGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AuthorizationTokenGroupByOutputType[P]>
            : GetScalarType<T[P], AuthorizationTokenGroupByOutputType[P]>
        }
      >
    >


  export type AuthorizationTokenSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    token?: boolean
    projectId?: boolean
    name?: boolean
    relation?: boolean
    createdAt?: boolean
    canClone?: boolean
    canCopy?: boolean
    project?: boolean | ProjectDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["authorizationToken"]>

  export type AuthorizationTokenSelectScalar = {
    token?: boolean
    projectId?: boolean
    name?: boolean
    relation?: boolean
    createdAt?: boolean
    canClone?: boolean
    canCopy?: boolean
  }

  export type AuthorizationTokenInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    project?: boolean | ProjectDefaultArgs<ExtArgs>
  }


  export type $AuthorizationTokenPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AuthorizationToken"
    objects: {
      project: Prisma.$ProjectPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      token: string
      projectId: string
      name: string
      relation: $Enums.AuthorizationRelation
      createdAt: Date
      canClone: boolean
      canCopy: boolean
    }, ExtArgs["result"]["authorizationToken"]>
    composites: {}
  }


  type AuthorizationTokenGetPayload<S extends boolean | null | undefined | AuthorizationTokenDefaultArgs> = $Result.GetResult<Prisma.$AuthorizationTokenPayload, S>

  type AuthorizationTokenCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<AuthorizationTokenFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: AuthorizationTokenCountAggregateInputType | true
    }

  export interface AuthorizationTokenDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AuthorizationToken'], meta: { name: 'AuthorizationToken' } }
    /**
     * Find zero or one AuthorizationToken that matches the filter.
     * @param {AuthorizationTokenFindUniqueArgs} args - Arguments to find a AuthorizationToken
     * @example
     * // Get one AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends AuthorizationTokenFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenFindUniqueArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one AuthorizationToken that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {AuthorizationTokenFindUniqueOrThrowArgs} args - Arguments to find a AuthorizationToken
     * @example
     * // Get one AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends AuthorizationTokenFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first AuthorizationToken that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenFindFirstArgs} args - Arguments to find a AuthorizationToken
     * @example
     * // Get one AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends AuthorizationTokenFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenFindFirstArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first AuthorizationToken that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenFindFirstOrThrowArgs} args - Arguments to find a AuthorizationToken
     * @example
     * // Get one AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends AuthorizationTokenFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more AuthorizationTokens that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AuthorizationTokens
     * const authorizationTokens = await prisma.authorizationToken.findMany()
     * 
     * // Get first 10 AuthorizationTokens
     * const authorizationTokens = await prisma.authorizationToken.findMany({ take: 10 })
     * 
     * // Only select the `token`
     * const authorizationTokenWithTokenOnly = await prisma.authorizationToken.findMany({ select: { token: true } })
     * 
    **/
    findMany<T extends AuthorizationTokenFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a AuthorizationToken.
     * @param {AuthorizationTokenCreateArgs} args - Arguments to create a AuthorizationToken.
     * @example
     * // Create one AuthorizationToken
     * const AuthorizationToken = await prisma.authorizationToken.create({
     *   data: {
     *     // ... data to create a AuthorizationToken
     *   }
     * })
     * 
    **/
    create<T extends AuthorizationTokenCreateArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenCreateArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many AuthorizationTokens.
     *     @param {AuthorizationTokenCreateManyArgs} args - Arguments to create many AuthorizationTokens.
     *     @example
     *     // Create many AuthorizationTokens
     *     const authorizationToken = await prisma.authorizationToken.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends AuthorizationTokenCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a AuthorizationToken.
     * @param {AuthorizationTokenDeleteArgs} args - Arguments to delete one AuthorizationToken.
     * @example
     * // Delete one AuthorizationToken
     * const AuthorizationToken = await prisma.authorizationToken.delete({
     *   where: {
     *     // ... filter to delete one AuthorizationToken
     *   }
     * })
     * 
    **/
    delete<T extends AuthorizationTokenDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenDeleteArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one AuthorizationToken.
     * @param {AuthorizationTokenUpdateArgs} args - Arguments to update one AuthorizationToken.
     * @example
     * // Update one AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends AuthorizationTokenUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenUpdateArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more AuthorizationTokens.
     * @param {AuthorizationTokenDeleteManyArgs} args - Arguments to filter AuthorizationTokens to delete.
     * @example
     * // Delete a few AuthorizationTokens
     * const { count } = await prisma.authorizationToken.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends AuthorizationTokenDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AuthorizationTokenDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AuthorizationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AuthorizationTokens
     * const authorizationToken = await prisma.authorizationToken.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends AuthorizationTokenUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one AuthorizationToken.
     * @param {AuthorizationTokenUpsertArgs} args - Arguments to update or create a AuthorizationToken.
     * @example
     * // Update or create a AuthorizationToken
     * const authorizationToken = await prisma.authorizationToken.upsert({
     *   create: {
     *     // ... data to create a AuthorizationToken
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AuthorizationToken we want to update
     *   }
     * })
    **/
    upsert<T extends AuthorizationTokenUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, AuthorizationTokenUpsertArgs<ExtArgs>>
    ): Prisma__AuthorizationTokenClient<$Result.GetResult<Prisma.$AuthorizationTokenPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of AuthorizationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenCountArgs} args - Arguments to filter AuthorizationTokens to count.
     * @example
     * // Count the number of AuthorizationTokens
     * const count = await prisma.authorizationToken.count({
     *   where: {
     *     // ... the filter for the AuthorizationTokens we want to count
     *   }
     * })
    **/
    count<T extends AuthorizationTokenCountArgs>(
      args?: Subset<T, AuthorizationTokenCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AuthorizationTokenCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AuthorizationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AuthorizationTokenAggregateArgs>(args: Subset<T, AuthorizationTokenAggregateArgs>): Prisma.PrismaPromise<GetAuthorizationTokenAggregateType<T>>

    /**
     * Group by AuthorizationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AuthorizationTokenGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AuthorizationTokenGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AuthorizationTokenGroupByArgs['orderBy'] }
        : { orderBy?: AuthorizationTokenGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AuthorizationTokenGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAuthorizationTokenGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AuthorizationToken model
   */
  readonly fields: AuthorizationTokenFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AuthorizationToken.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AuthorizationTokenClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    project<T extends ProjectDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProjectDefaultArgs<ExtArgs>>): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the AuthorizationToken model
   */ 
  interface AuthorizationTokenFieldRefs {
    readonly token: FieldRef<"AuthorizationToken", 'String'>
    readonly projectId: FieldRef<"AuthorizationToken", 'String'>
    readonly name: FieldRef<"AuthorizationToken", 'String'>
    readonly relation: FieldRef<"AuthorizationToken", 'AuthorizationRelation'>
    readonly createdAt: FieldRef<"AuthorizationToken", 'DateTime'>
    readonly canClone: FieldRef<"AuthorizationToken", 'Boolean'>
    readonly canCopy: FieldRef<"AuthorizationToken", 'Boolean'>
  }
    

  // Custom InputTypes

  /**
   * AuthorizationToken findUnique
   */
  export type AuthorizationTokenFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter, which AuthorizationToken to fetch.
     */
    where: AuthorizationTokenWhereUniqueInput
  }


  /**
   * AuthorizationToken findUniqueOrThrow
   */
  export type AuthorizationTokenFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter, which AuthorizationToken to fetch.
     */
    where: AuthorizationTokenWhereUniqueInput
  }


  /**
   * AuthorizationToken findFirst
   */
  export type AuthorizationTokenFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter, which AuthorizationToken to fetch.
     */
    where?: AuthorizationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AuthorizationTokens to fetch.
     */
    orderBy?: AuthorizationTokenOrderByWithRelationInput | AuthorizationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AuthorizationTokens.
     */
    cursor?: AuthorizationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AuthorizationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AuthorizationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AuthorizationTokens.
     */
    distinct?: AuthorizationTokenScalarFieldEnum | AuthorizationTokenScalarFieldEnum[]
  }


  /**
   * AuthorizationToken findFirstOrThrow
   */
  export type AuthorizationTokenFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter, which AuthorizationToken to fetch.
     */
    where?: AuthorizationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AuthorizationTokens to fetch.
     */
    orderBy?: AuthorizationTokenOrderByWithRelationInput | AuthorizationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AuthorizationTokens.
     */
    cursor?: AuthorizationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AuthorizationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AuthorizationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AuthorizationTokens.
     */
    distinct?: AuthorizationTokenScalarFieldEnum | AuthorizationTokenScalarFieldEnum[]
  }


  /**
   * AuthorizationToken findMany
   */
  export type AuthorizationTokenFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter, which AuthorizationTokens to fetch.
     */
    where?: AuthorizationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AuthorizationTokens to fetch.
     */
    orderBy?: AuthorizationTokenOrderByWithRelationInput | AuthorizationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AuthorizationTokens.
     */
    cursor?: AuthorizationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AuthorizationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AuthorizationTokens.
     */
    skip?: number
    distinct?: AuthorizationTokenScalarFieldEnum | AuthorizationTokenScalarFieldEnum[]
  }


  /**
   * AuthorizationToken create
   */
  export type AuthorizationTokenCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * The data needed to create a AuthorizationToken.
     */
    data: XOR<AuthorizationTokenCreateInput, AuthorizationTokenUncheckedCreateInput>
  }


  /**
   * AuthorizationToken createMany
   */
  export type AuthorizationTokenCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AuthorizationTokens.
     */
    data: AuthorizationTokenCreateManyInput | AuthorizationTokenCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * AuthorizationToken update
   */
  export type AuthorizationTokenUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * The data needed to update a AuthorizationToken.
     */
    data: XOR<AuthorizationTokenUpdateInput, AuthorizationTokenUncheckedUpdateInput>
    /**
     * Choose, which AuthorizationToken to update.
     */
    where: AuthorizationTokenWhereUniqueInput
  }


  /**
   * AuthorizationToken updateMany
   */
  export type AuthorizationTokenUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AuthorizationTokens.
     */
    data: XOR<AuthorizationTokenUpdateManyMutationInput, AuthorizationTokenUncheckedUpdateManyInput>
    /**
     * Filter which AuthorizationTokens to update
     */
    where?: AuthorizationTokenWhereInput
  }


  /**
   * AuthorizationToken upsert
   */
  export type AuthorizationTokenUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * The filter to search for the AuthorizationToken to update in case it exists.
     */
    where: AuthorizationTokenWhereUniqueInput
    /**
     * In case the AuthorizationToken found by the `where` argument doesn't exist, create a new AuthorizationToken with this data.
     */
    create: XOR<AuthorizationTokenCreateInput, AuthorizationTokenUncheckedCreateInput>
    /**
     * In case the AuthorizationToken was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AuthorizationTokenUpdateInput, AuthorizationTokenUncheckedUpdateInput>
  }


  /**
   * AuthorizationToken delete
   */
  export type AuthorizationTokenDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
    /**
     * Filter which AuthorizationToken to delete.
     */
    where: AuthorizationTokenWhereUniqueInput
  }


  /**
   * AuthorizationToken deleteMany
   */
  export type AuthorizationTokenDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AuthorizationTokens to delete
     */
    where?: AuthorizationTokenWhereInput
  }


  /**
   * AuthorizationToken without action
   */
  export type AuthorizationTokenDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AuthorizationToken
     */
    select?: AuthorizationTokenSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AuthorizationTokenInclude<ExtArgs> | null
  }



  /**
   * Model Domain
   */

  export type AggregateDomain = {
    _count: DomainCountAggregateOutputType | null
    _min: DomainMinAggregateOutputType | null
    _max: DomainMaxAggregateOutputType | null
  }

  export type DomainMinAggregateOutputType = {
    id: string | null
    domain: string | null
    createdAt: Date | null
    updatedAt: Date | null
    txtRecord: string | null
    status: $Enums.DomainStatus | null
    error: string | null
  }

  export type DomainMaxAggregateOutputType = {
    id: string | null
    domain: string | null
    createdAt: Date | null
    updatedAt: Date | null
    txtRecord: string | null
    status: $Enums.DomainStatus | null
    error: string | null
  }

  export type DomainCountAggregateOutputType = {
    id: number
    domain: number
    createdAt: number
    updatedAt: number
    txtRecord: number
    status: number
    error: number
    _all: number
  }


  export type DomainMinAggregateInputType = {
    id?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
    txtRecord?: true
    status?: true
    error?: true
  }

  export type DomainMaxAggregateInputType = {
    id?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
    txtRecord?: true
    status?: true
    error?: true
  }

  export type DomainCountAggregateInputType = {
    id?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
    txtRecord?: true
    status?: true
    error?: true
    _all?: true
  }

  export type DomainAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Domain to aggregate.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Domains
    **/
    _count?: true | DomainCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DomainMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DomainMaxAggregateInputType
  }

  export type GetDomainAggregateType<T extends DomainAggregateArgs> = {
        [P in keyof T & keyof AggregateDomain]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDomain[P]>
      : GetScalarType<T[P], AggregateDomain[P]>
  }




  export type DomainGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DomainWhereInput
    orderBy?: DomainOrderByWithAggregationInput | DomainOrderByWithAggregationInput[]
    by: DomainScalarFieldEnum[] | DomainScalarFieldEnum
    having?: DomainScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DomainCountAggregateInputType | true
    _min?: DomainMinAggregateInputType
    _max?: DomainMaxAggregateInputType
  }

  export type DomainGroupByOutputType = {
    id: string
    domain: string
    createdAt: Date
    updatedAt: Date
    txtRecord: string | null
    status: $Enums.DomainStatus
    error: string | null
    _count: DomainCountAggregateOutputType | null
    _min: DomainMinAggregateOutputType | null
    _max: DomainMaxAggregateOutputType | null
  }

  type GetDomainGroupByPayload<T extends DomainGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DomainGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DomainGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DomainGroupByOutputType[P]>
            : GetScalarType<T[P], DomainGroupByOutputType[P]>
        }
      >
    >


  export type DomainSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    txtRecord?: boolean
    status?: boolean
    error?: boolean
    ProjectDomain?: boolean | Domain$ProjectDomainArgs<ExtArgs>
    _count?: boolean | DomainCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["domain"]>

  export type DomainSelectScalar = {
    id?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    txtRecord?: boolean
    status?: boolean
    error?: boolean
  }

  export type DomainInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ProjectDomain?: boolean | Domain$ProjectDomainArgs<ExtArgs>
    _count?: boolean | DomainCountOutputTypeDefaultArgs<ExtArgs>
  }


  export type $DomainPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Domain"
    objects: {
      ProjectDomain: Prisma.$ProjectDomainPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      domain: string
      createdAt: Date
      updatedAt: Date
      txtRecord: string | null
      status: $Enums.DomainStatus
      error: string | null
    }, ExtArgs["result"]["domain"]>
    composites: {}
  }


  type DomainGetPayload<S extends boolean | null | undefined | DomainDefaultArgs> = $Result.GetResult<Prisma.$DomainPayload, S>

  type DomainCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<DomainFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: DomainCountAggregateInputType | true
    }

  export interface DomainDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Domain'], meta: { name: 'Domain' } }
    /**
     * Find zero or one Domain that matches the filter.
     * @param {DomainFindUniqueArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends DomainFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, DomainFindUniqueArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one Domain that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {DomainFindUniqueOrThrowArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends DomainFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first Domain that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindFirstArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends DomainFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainFindFirstArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first Domain that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindFirstOrThrowArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends DomainFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more Domains that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Domains
     * const domains = await prisma.domain.findMany()
     * 
     * // Get first 10 Domains
     * const domains = await prisma.domain.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const domainWithIdOnly = await prisma.domain.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends DomainFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a Domain.
     * @param {DomainCreateArgs} args - Arguments to create a Domain.
     * @example
     * // Create one Domain
     * const Domain = await prisma.domain.create({
     *   data: {
     *     // ... data to create a Domain
     *   }
     * })
     * 
    **/
    create<T extends DomainCreateArgs<ExtArgs>>(
      args: SelectSubset<T, DomainCreateArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many Domains.
     *     @param {DomainCreateManyArgs} args - Arguments to create many Domains.
     *     @example
     *     // Create many Domains
     *     const domain = await prisma.domain.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends DomainCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Domain.
     * @param {DomainDeleteArgs} args - Arguments to delete one Domain.
     * @example
     * // Delete one Domain
     * const Domain = await prisma.domain.delete({
     *   where: {
     *     // ... filter to delete one Domain
     *   }
     * })
     * 
    **/
    delete<T extends DomainDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, DomainDeleteArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one Domain.
     * @param {DomainUpdateArgs} args - Arguments to update one Domain.
     * @example
     * // Update one Domain
     * const domain = await prisma.domain.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends DomainUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, DomainUpdateArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more Domains.
     * @param {DomainDeleteManyArgs} args - Arguments to filter Domains to delete.
     * @example
     * // Delete a few Domains
     * const { count } = await prisma.domain.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends DomainDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DomainDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Domains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Domains
     * const domain = await prisma.domain.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends DomainUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, DomainUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Domain.
     * @param {DomainUpsertArgs} args - Arguments to update or create a Domain.
     * @example
     * // Update or create a Domain
     * const domain = await prisma.domain.upsert({
     *   create: {
     *     // ... data to create a Domain
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Domain we want to update
     *   }
     * })
    **/
    upsert<T extends DomainUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, DomainUpsertArgs<ExtArgs>>
    ): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of Domains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainCountArgs} args - Arguments to filter Domains to count.
     * @example
     * // Count the number of Domains
     * const count = await prisma.domain.count({
     *   where: {
     *     // ... the filter for the Domains we want to count
     *   }
     * })
    **/
    count<T extends DomainCountArgs>(
      args?: Subset<T, DomainCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DomainCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Domain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DomainAggregateArgs>(args: Subset<T, DomainAggregateArgs>): Prisma.PrismaPromise<GetDomainAggregateType<T>>

    /**
     * Group by Domain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DomainGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DomainGroupByArgs['orderBy'] }
        : { orderBy?: DomainGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DomainGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDomainGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Domain model
   */
  readonly fields: DomainFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Domain.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DomainClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    ProjectDomain<T extends Domain$ProjectDomainArgs<ExtArgs> = {}>(args?: Subset<T, Domain$ProjectDomainArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findMany'> | Null>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the Domain model
   */ 
  interface DomainFieldRefs {
    readonly id: FieldRef<"Domain", 'String'>
    readonly domain: FieldRef<"Domain", 'String'>
    readonly createdAt: FieldRef<"Domain", 'DateTime'>
    readonly updatedAt: FieldRef<"Domain", 'DateTime'>
    readonly txtRecord: FieldRef<"Domain", 'String'>
    readonly status: FieldRef<"Domain", 'DomainStatus'>
    readonly error: FieldRef<"Domain", 'String'>
  }
    

  // Custom InputTypes

  /**
   * Domain findUnique
   */
  export type DomainFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where: DomainWhereUniqueInput
  }


  /**
   * Domain findUniqueOrThrow
   */
  export type DomainFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where: DomainWhereUniqueInput
  }


  /**
   * Domain findFirst
   */
  export type DomainFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Domains.
     */
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }


  /**
   * Domain findFirstOrThrow
   */
  export type DomainFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Domains.
     */
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }


  /**
   * Domain findMany
   */
  export type DomainFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domains to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }


  /**
   * Domain create
   */
  export type DomainCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The data needed to create a Domain.
     */
    data: XOR<DomainCreateInput, DomainUncheckedCreateInput>
  }


  /**
   * Domain createMany
   */
  export type DomainCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Domains.
     */
    data: DomainCreateManyInput | DomainCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * Domain update
   */
  export type DomainUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The data needed to update a Domain.
     */
    data: XOR<DomainUpdateInput, DomainUncheckedUpdateInput>
    /**
     * Choose, which Domain to update.
     */
    where: DomainWhereUniqueInput
  }


  /**
   * Domain updateMany
   */
  export type DomainUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Domains.
     */
    data: XOR<DomainUpdateManyMutationInput, DomainUncheckedUpdateManyInput>
    /**
     * Filter which Domains to update
     */
    where?: DomainWhereInput
  }


  /**
   * Domain upsert
   */
  export type DomainUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The filter to search for the Domain to update in case it exists.
     */
    where: DomainWhereUniqueInput
    /**
     * In case the Domain found by the `where` argument doesn't exist, create a new Domain with this data.
     */
    create: XOR<DomainCreateInput, DomainUncheckedCreateInput>
    /**
     * In case the Domain was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DomainUpdateInput, DomainUncheckedUpdateInput>
  }


  /**
   * Domain delete
   */
  export type DomainDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter which Domain to delete.
     */
    where: DomainWhereUniqueInput
  }


  /**
   * Domain deleteMany
   */
  export type DomainDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Domains to delete
     */
    where?: DomainWhereInput
  }


  /**
   * Domain.ProjectDomain
   */
  export type Domain$ProjectDomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    where?: ProjectDomainWhereInput
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    cursor?: ProjectDomainWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProjectDomainScalarFieldEnum | ProjectDomainScalarFieldEnum[]
  }


  /**
   * Domain without action
   */
  export type DomainDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DomainInclude<ExtArgs> | null
  }



  /**
   * Model ProjectDomain
   */

  export type AggregateProjectDomain = {
    _count: ProjectDomainCountAggregateOutputType | null
    _min: ProjectDomainMinAggregateOutputType | null
    _max: ProjectDomainMaxAggregateOutputType | null
  }

  export type ProjectDomainMinAggregateOutputType = {
    projectId: string | null
    domainId: string | null
    createdAt: Date | null
    txtRecord: string | null
    cname: string | null
  }

  export type ProjectDomainMaxAggregateOutputType = {
    projectId: string | null
    domainId: string | null
    createdAt: Date | null
    txtRecord: string | null
    cname: string | null
  }

  export type ProjectDomainCountAggregateOutputType = {
    projectId: number
    domainId: number
    createdAt: number
    txtRecord: number
    cname: number
    _all: number
  }


  export type ProjectDomainMinAggregateInputType = {
    projectId?: true
    domainId?: true
    createdAt?: true
    txtRecord?: true
    cname?: true
  }

  export type ProjectDomainMaxAggregateInputType = {
    projectId?: true
    domainId?: true
    createdAt?: true
    txtRecord?: true
    cname?: true
  }

  export type ProjectDomainCountAggregateInputType = {
    projectId?: true
    domainId?: true
    createdAt?: true
    txtRecord?: true
    cname?: true
    _all?: true
  }

  export type ProjectDomainAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProjectDomain to aggregate.
     */
    where?: ProjectDomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProjectDomains to fetch.
     */
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProjectDomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProjectDomains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProjectDomains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ProjectDomains
    **/
    _count?: true | ProjectDomainCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProjectDomainMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProjectDomainMaxAggregateInputType
  }

  export type GetProjectDomainAggregateType<T extends ProjectDomainAggregateArgs> = {
        [P in keyof T & keyof AggregateProjectDomain]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProjectDomain[P]>
      : GetScalarType<T[P], AggregateProjectDomain[P]>
  }




  export type ProjectDomainGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProjectDomainWhereInput
    orderBy?: ProjectDomainOrderByWithAggregationInput | ProjectDomainOrderByWithAggregationInput[]
    by: ProjectDomainScalarFieldEnum[] | ProjectDomainScalarFieldEnum
    having?: ProjectDomainScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProjectDomainCountAggregateInputType | true
    _min?: ProjectDomainMinAggregateInputType
    _max?: ProjectDomainMaxAggregateInputType
  }

  export type ProjectDomainGroupByOutputType = {
    projectId: string
    domainId: string
    createdAt: Date
    txtRecord: string
    cname: string
    _count: ProjectDomainCountAggregateOutputType | null
    _min: ProjectDomainMinAggregateOutputType | null
    _max: ProjectDomainMaxAggregateOutputType | null
  }

  type GetProjectDomainGroupByPayload<T extends ProjectDomainGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProjectDomainGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProjectDomainGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProjectDomainGroupByOutputType[P]>
            : GetScalarType<T[P], ProjectDomainGroupByOutputType[P]>
        }
      >
    >


  export type ProjectDomainSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    projectId?: boolean
    domainId?: boolean
    createdAt?: boolean
    txtRecord?: boolean
    cname?: boolean
    project?: boolean | ProjectDefaultArgs<ExtArgs>
    domain?: boolean | DomainDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["projectDomain"]>

  export type ProjectDomainSelectScalar = {
    projectId?: boolean
    domainId?: boolean
    createdAt?: boolean
    txtRecord?: boolean
    cname?: boolean
  }

  export type ProjectDomainInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    project?: boolean | ProjectDefaultArgs<ExtArgs>
    domain?: boolean | DomainDefaultArgs<ExtArgs>
  }


  export type $ProjectDomainPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ProjectDomain"
    objects: {
      project: Prisma.$ProjectPayload<ExtArgs>
      domain: Prisma.$DomainPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      projectId: string
      domainId: string
      createdAt: Date
      txtRecord: string
      cname: string
    }, ExtArgs["result"]["projectDomain"]>
    composites: {}
  }


  type ProjectDomainGetPayload<S extends boolean | null | undefined | ProjectDomainDefaultArgs> = $Result.GetResult<Prisma.$ProjectDomainPayload, S>

  type ProjectDomainCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ProjectDomainFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ProjectDomainCountAggregateInputType | true
    }

  export interface ProjectDomainDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ProjectDomain'], meta: { name: 'ProjectDomain' } }
    /**
     * Find zero or one ProjectDomain that matches the filter.
     * @param {ProjectDomainFindUniqueArgs} args - Arguments to find a ProjectDomain
     * @example
     * // Get one ProjectDomain
     * const projectDomain = await prisma.projectDomain.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ProjectDomainFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainFindUniqueArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one ProjectDomain that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ProjectDomainFindUniqueOrThrowArgs} args - Arguments to find a ProjectDomain
     * @example
     * // Get one ProjectDomain
     * const projectDomain = await prisma.projectDomain.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ProjectDomainFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first ProjectDomain that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainFindFirstArgs} args - Arguments to find a ProjectDomain
     * @example
     * // Get one ProjectDomain
     * const projectDomain = await prisma.projectDomain.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ProjectDomainFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainFindFirstArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first ProjectDomain that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainFindFirstOrThrowArgs} args - Arguments to find a ProjectDomain
     * @example
     * // Get one ProjectDomain
     * const projectDomain = await prisma.projectDomain.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ProjectDomainFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more ProjectDomains that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ProjectDomains
     * const projectDomains = await prisma.projectDomain.findMany()
     * 
     * // Get first 10 ProjectDomains
     * const projectDomains = await prisma.projectDomain.findMany({ take: 10 })
     * 
     * // Only select the `projectId`
     * const projectDomainWithProjectIdOnly = await prisma.projectDomain.findMany({ select: { projectId: true } })
     * 
    **/
    findMany<T extends ProjectDomainFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a ProjectDomain.
     * @param {ProjectDomainCreateArgs} args - Arguments to create a ProjectDomain.
     * @example
     * // Create one ProjectDomain
     * const ProjectDomain = await prisma.projectDomain.create({
     *   data: {
     *     // ... data to create a ProjectDomain
     *   }
     * })
     * 
    **/
    create<T extends ProjectDomainCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainCreateArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many ProjectDomains.
     *     @param {ProjectDomainCreateManyArgs} args - Arguments to create many ProjectDomains.
     *     @example
     *     // Create many ProjectDomains
     *     const projectDomain = await prisma.projectDomain.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ProjectDomainCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ProjectDomain.
     * @param {ProjectDomainDeleteArgs} args - Arguments to delete one ProjectDomain.
     * @example
     * // Delete one ProjectDomain
     * const ProjectDomain = await prisma.projectDomain.delete({
     *   where: {
     *     // ... filter to delete one ProjectDomain
     *   }
     * })
     * 
    **/
    delete<T extends ProjectDomainDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainDeleteArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one ProjectDomain.
     * @param {ProjectDomainUpdateArgs} args - Arguments to update one ProjectDomain.
     * @example
     * // Update one ProjectDomain
     * const projectDomain = await prisma.projectDomain.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ProjectDomainUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainUpdateArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more ProjectDomains.
     * @param {ProjectDomainDeleteManyArgs} args - Arguments to filter ProjectDomains to delete.
     * @example
     * // Delete a few ProjectDomains
     * const { count } = await prisma.projectDomain.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ProjectDomainDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProjectDomainDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ProjectDomains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ProjectDomains
     * const projectDomain = await prisma.projectDomain.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ProjectDomainUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ProjectDomain.
     * @param {ProjectDomainUpsertArgs} args - Arguments to update or create a ProjectDomain.
     * @example
     * // Update or create a ProjectDomain
     * const projectDomain = await prisma.projectDomain.upsert({
     *   create: {
     *     // ... data to create a ProjectDomain
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ProjectDomain we want to update
     *   }
     * })
    **/
    upsert<T extends ProjectDomainUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ProjectDomainUpsertArgs<ExtArgs>>
    ): Prisma__ProjectDomainClient<$Result.GetResult<Prisma.$ProjectDomainPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of ProjectDomains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainCountArgs} args - Arguments to filter ProjectDomains to count.
     * @example
     * // Count the number of ProjectDomains
     * const count = await prisma.projectDomain.count({
     *   where: {
     *     // ... the filter for the ProjectDomains we want to count
     *   }
     * })
    **/
    count<T extends ProjectDomainCountArgs>(
      args?: Subset<T, ProjectDomainCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProjectDomainCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ProjectDomain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProjectDomainAggregateArgs>(args: Subset<T, ProjectDomainAggregateArgs>): Prisma.PrismaPromise<GetProjectDomainAggregateType<T>>

    /**
     * Group by ProjectDomain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProjectDomainGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProjectDomainGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProjectDomainGroupByArgs['orderBy'] }
        : { orderBy?: ProjectDomainGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProjectDomainGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProjectDomainGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ProjectDomain model
   */
  readonly fields: ProjectDomainFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ProjectDomain.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProjectDomainClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    project<T extends ProjectDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProjectDefaultArgs<ExtArgs>>): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    domain<T extends DomainDefaultArgs<ExtArgs> = {}>(args?: Subset<T, DomainDefaultArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the ProjectDomain model
   */ 
  interface ProjectDomainFieldRefs {
    readonly projectId: FieldRef<"ProjectDomain", 'String'>
    readonly domainId: FieldRef<"ProjectDomain", 'String'>
    readonly createdAt: FieldRef<"ProjectDomain", 'DateTime'>
    readonly txtRecord: FieldRef<"ProjectDomain", 'String'>
    readonly cname: FieldRef<"ProjectDomain", 'String'>
  }
    

  // Custom InputTypes

  /**
   * ProjectDomain findUnique
   */
  export type ProjectDomainFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter, which ProjectDomain to fetch.
     */
    where: ProjectDomainWhereUniqueInput
  }


  /**
   * ProjectDomain findUniqueOrThrow
   */
  export type ProjectDomainFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter, which ProjectDomain to fetch.
     */
    where: ProjectDomainWhereUniqueInput
  }


  /**
   * ProjectDomain findFirst
   */
  export type ProjectDomainFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter, which ProjectDomain to fetch.
     */
    where?: ProjectDomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProjectDomains to fetch.
     */
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProjectDomains.
     */
    cursor?: ProjectDomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProjectDomains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProjectDomains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProjectDomains.
     */
    distinct?: ProjectDomainScalarFieldEnum | ProjectDomainScalarFieldEnum[]
  }


  /**
   * ProjectDomain findFirstOrThrow
   */
  export type ProjectDomainFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter, which ProjectDomain to fetch.
     */
    where?: ProjectDomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProjectDomains to fetch.
     */
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProjectDomains.
     */
    cursor?: ProjectDomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProjectDomains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProjectDomains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProjectDomains.
     */
    distinct?: ProjectDomainScalarFieldEnum | ProjectDomainScalarFieldEnum[]
  }


  /**
   * ProjectDomain findMany
   */
  export type ProjectDomainFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter, which ProjectDomains to fetch.
     */
    where?: ProjectDomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProjectDomains to fetch.
     */
    orderBy?: ProjectDomainOrderByWithRelationInput | ProjectDomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ProjectDomains.
     */
    cursor?: ProjectDomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProjectDomains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProjectDomains.
     */
    skip?: number
    distinct?: ProjectDomainScalarFieldEnum | ProjectDomainScalarFieldEnum[]
  }


  /**
   * ProjectDomain create
   */
  export type ProjectDomainCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * The data needed to create a ProjectDomain.
     */
    data: XOR<ProjectDomainCreateInput, ProjectDomainUncheckedCreateInput>
  }


  /**
   * ProjectDomain createMany
   */
  export type ProjectDomainCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ProjectDomains.
     */
    data: ProjectDomainCreateManyInput | ProjectDomainCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * ProjectDomain update
   */
  export type ProjectDomainUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * The data needed to update a ProjectDomain.
     */
    data: XOR<ProjectDomainUpdateInput, ProjectDomainUncheckedUpdateInput>
    /**
     * Choose, which ProjectDomain to update.
     */
    where: ProjectDomainWhereUniqueInput
  }


  /**
   * ProjectDomain updateMany
   */
  export type ProjectDomainUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ProjectDomains.
     */
    data: XOR<ProjectDomainUpdateManyMutationInput, ProjectDomainUncheckedUpdateManyInput>
    /**
     * Filter which ProjectDomains to update
     */
    where?: ProjectDomainWhereInput
  }


  /**
   * ProjectDomain upsert
   */
  export type ProjectDomainUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * The filter to search for the ProjectDomain to update in case it exists.
     */
    where: ProjectDomainWhereUniqueInput
    /**
     * In case the ProjectDomain found by the `where` argument doesn't exist, create a new ProjectDomain with this data.
     */
    create: XOR<ProjectDomainCreateInput, ProjectDomainUncheckedCreateInput>
    /**
     * In case the ProjectDomain was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProjectDomainUpdateInput, ProjectDomainUncheckedUpdateInput>
  }


  /**
   * ProjectDomain delete
   */
  export type ProjectDomainDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
    /**
     * Filter which ProjectDomain to delete.
     */
    where: ProjectDomainWhereUniqueInput
  }


  /**
   * ProjectDomain deleteMany
   */
  export type ProjectDomainDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProjectDomains to delete
     */
    where?: ProjectDomainWhereInput
  }


  /**
   * ProjectDomain without action
   */
  export type ProjectDomainDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProjectDomain
     */
    select?: ProjectDomainSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: ProjectDomainInclude<ExtArgs> | null
  }



  /**
   * Model UserProduct
   */

  export type AggregateUserProduct = {
    _count: UserProductCountAggregateOutputType | null
    _min: UserProductMinAggregateOutputType | null
    _max: UserProductMaxAggregateOutputType | null
  }

  export type UserProductMinAggregateOutputType = {
    userId: string | null
    productId: string | null
    subscriptionId: string | null
    customerId: string | null
    customerEmail: string | null
  }

  export type UserProductMaxAggregateOutputType = {
    userId: string | null
    productId: string | null
    subscriptionId: string | null
    customerId: string | null
    customerEmail: string | null
  }

  export type UserProductCountAggregateOutputType = {
    userId: number
    productId: number
    subscriptionId: number
    customerId: number
    customerEmail: number
    _all: number
  }


  export type UserProductMinAggregateInputType = {
    userId?: true
    productId?: true
    subscriptionId?: true
    customerId?: true
    customerEmail?: true
  }

  export type UserProductMaxAggregateInputType = {
    userId?: true
    productId?: true
    subscriptionId?: true
    customerId?: true
    customerEmail?: true
  }

  export type UserProductCountAggregateInputType = {
    userId?: true
    productId?: true
    subscriptionId?: true
    customerId?: true
    customerEmail?: true
    _all?: true
  }

  export type UserProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserProduct to aggregate.
     */
    where?: UserProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserProducts to fetch.
     */
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserProducts
    **/
    _count?: true | UserProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserProductMaxAggregateInputType
  }

  export type GetUserProductAggregateType<T extends UserProductAggregateArgs> = {
        [P in keyof T & keyof AggregateUserProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserProduct[P]>
      : GetScalarType<T[P], AggregateUserProduct[P]>
  }




  export type UserProductGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserProductWhereInput
    orderBy?: UserProductOrderByWithAggregationInput | UserProductOrderByWithAggregationInput[]
    by: UserProductScalarFieldEnum[] | UserProductScalarFieldEnum
    having?: UserProductScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserProductCountAggregateInputType | true
    _min?: UserProductMinAggregateInputType
    _max?: UserProductMaxAggregateInputType
  }

  export type UserProductGroupByOutputType = {
    userId: string
    productId: string
    subscriptionId: string | null
    customerId: string | null
    customerEmail: string | null
    _count: UserProductCountAggregateOutputType | null
    _min: UserProductMinAggregateOutputType | null
    _max: UserProductMaxAggregateOutputType | null
  }

  type GetUserProductGroupByPayload<T extends UserProductGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserProductGroupByOutputType[P]>
            : GetScalarType<T[P], UserProductGroupByOutputType[P]>
        }
      >
    >


  export type UserProductSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    userId?: boolean
    productId?: boolean
    subscriptionId?: boolean
    customerId?: boolean
    customerEmail?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userProduct"]>

  export type UserProductSelectScalar = {
    userId?: boolean
    productId?: boolean
    subscriptionId?: boolean
    customerId?: boolean
    customerEmail?: boolean
  }

  export type UserProductInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }


  export type $UserProductPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserProduct"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      product: Prisma.$ProductPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      userId: string
      productId: string
      subscriptionId: string | null
      customerId: string | null
      customerEmail: string | null
    }, ExtArgs["result"]["userProduct"]>
    composites: {}
  }


  type UserProductGetPayload<S extends boolean | null | undefined | UserProductDefaultArgs> = $Result.GetResult<Prisma.$UserProductPayload, S>

  type UserProductCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<UserProductFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: UserProductCountAggregateInputType | true
    }

  export interface UserProductDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserProduct'], meta: { name: 'UserProduct' } }
    /**
     * Find zero or one UserProduct that matches the filter.
     * @param {UserProductFindUniqueArgs} args - Arguments to find a UserProduct
     * @example
     * // Get one UserProduct
     * const userProduct = await prisma.userProduct.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends UserProductFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductFindUniqueArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one UserProduct that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {UserProductFindUniqueOrThrowArgs} args - Arguments to find a UserProduct
     * @example
     * // Get one UserProduct
     * const userProduct = await prisma.userProduct.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends UserProductFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first UserProduct that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductFindFirstArgs} args - Arguments to find a UserProduct
     * @example
     * // Get one UserProduct
     * const userProduct = await prisma.userProduct.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends UserProductFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductFindFirstArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first UserProduct that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductFindFirstOrThrowArgs} args - Arguments to find a UserProduct
     * @example
     * // Get one UserProduct
     * const userProduct = await prisma.userProduct.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends UserProductFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more UserProducts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserProducts
     * const userProducts = await prisma.userProduct.findMany()
     * 
     * // Get first 10 UserProducts
     * const userProducts = await prisma.userProduct.findMany({ take: 10 })
     * 
     * // Only select the `userId`
     * const userProductWithUserIdOnly = await prisma.userProduct.findMany({ select: { userId: true } })
     * 
    **/
    findMany<T extends UserProductFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a UserProduct.
     * @param {UserProductCreateArgs} args - Arguments to create a UserProduct.
     * @example
     * // Create one UserProduct
     * const UserProduct = await prisma.userProduct.create({
     *   data: {
     *     // ... data to create a UserProduct
     *   }
     * })
     * 
    **/
    create<T extends UserProductCreateArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductCreateArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many UserProducts.
     *     @param {UserProductCreateManyArgs} args - Arguments to create many UserProducts.
     *     @example
     *     // Create many UserProducts
     *     const userProduct = await prisma.userProduct.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends UserProductCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a UserProduct.
     * @param {UserProductDeleteArgs} args - Arguments to delete one UserProduct.
     * @example
     * // Delete one UserProduct
     * const UserProduct = await prisma.userProduct.delete({
     *   where: {
     *     // ... filter to delete one UserProduct
     *   }
     * })
     * 
    **/
    delete<T extends UserProductDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductDeleteArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one UserProduct.
     * @param {UserProductUpdateArgs} args - Arguments to update one UserProduct.
     * @example
     * // Update one UserProduct
     * const userProduct = await prisma.userProduct.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends UserProductUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductUpdateArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more UserProducts.
     * @param {UserProductDeleteManyArgs} args - Arguments to filter UserProducts to delete.
     * @example
     * // Delete a few UserProducts
     * const { count } = await prisma.userProduct.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends UserProductDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserProductDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserProducts
     * const userProduct = await prisma.userProduct.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends UserProductUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one UserProduct.
     * @param {UserProductUpsertArgs} args - Arguments to update or create a UserProduct.
     * @example
     * // Update or create a UserProduct
     * const userProduct = await prisma.userProduct.upsert({
     *   create: {
     *     // ... data to create a UserProduct
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserProduct we want to update
     *   }
     * })
    **/
    upsert<T extends UserProductUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, UserProductUpsertArgs<ExtArgs>>
    ): Prisma__UserProductClient<$Result.GetResult<Prisma.$UserProductPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of UserProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductCountArgs} args - Arguments to filter UserProducts to count.
     * @example
     * // Count the number of UserProducts
     * const count = await prisma.userProduct.count({
     *   where: {
     *     // ... the filter for the UserProducts we want to count
     *   }
     * })
    **/
    count<T extends UserProductCountArgs>(
      args?: Subset<T, UserProductCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserProductAggregateArgs>(args: Subset<T, UserProductAggregateArgs>): Prisma.PrismaPromise<GetUserProductAggregateType<T>>

    /**
     * Group by UserProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserProductGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserProductGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserProductGroupByArgs['orderBy'] }
        : { orderBy?: UserProductGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserProductGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserProduct model
   */
  readonly fields: UserProductFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserProduct.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserProductClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    product<T extends ProductDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProductDefaultArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the UserProduct model
   */ 
  interface UserProductFieldRefs {
    readonly userId: FieldRef<"UserProduct", 'String'>
    readonly productId: FieldRef<"UserProduct", 'String'>
    readonly subscriptionId: FieldRef<"UserProduct", 'String'>
    readonly customerId: FieldRef<"UserProduct", 'String'>
    readonly customerEmail: FieldRef<"UserProduct", 'String'>
  }
    

  // Custom InputTypes

  /**
   * UserProduct findUnique
   */
  export type UserProductFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter, which UserProduct to fetch.
     */
    where: UserProductWhereUniqueInput
  }


  /**
   * UserProduct findUniqueOrThrow
   */
  export type UserProductFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter, which UserProduct to fetch.
     */
    where: UserProductWhereUniqueInput
  }


  /**
   * UserProduct findFirst
   */
  export type UserProductFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter, which UserProduct to fetch.
     */
    where?: UserProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserProducts to fetch.
     */
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserProducts.
     */
    cursor?: UserProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserProducts.
     */
    distinct?: UserProductScalarFieldEnum | UserProductScalarFieldEnum[]
  }


  /**
   * UserProduct findFirstOrThrow
   */
  export type UserProductFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter, which UserProduct to fetch.
     */
    where?: UserProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserProducts to fetch.
     */
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserProducts.
     */
    cursor?: UserProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserProducts.
     */
    distinct?: UserProductScalarFieldEnum | UserProductScalarFieldEnum[]
  }


  /**
   * UserProduct findMany
   */
  export type UserProductFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter, which UserProducts to fetch.
     */
    where?: UserProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserProducts to fetch.
     */
    orderBy?: UserProductOrderByWithRelationInput | UserProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserProducts.
     */
    cursor?: UserProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserProducts.
     */
    skip?: number
    distinct?: UserProductScalarFieldEnum | UserProductScalarFieldEnum[]
  }


  /**
   * UserProduct create
   */
  export type UserProductCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * The data needed to create a UserProduct.
     */
    data: XOR<UserProductCreateInput, UserProductUncheckedCreateInput>
  }


  /**
   * UserProduct createMany
   */
  export type UserProductCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserProducts.
     */
    data: UserProductCreateManyInput | UserProductCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * UserProduct update
   */
  export type UserProductUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * The data needed to update a UserProduct.
     */
    data: XOR<UserProductUpdateInput, UserProductUncheckedUpdateInput>
    /**
     * Choose, which UserProduct to update.
     */
    where: UserProductWhereUniqueInput
  }


  /**
   * UserProduct updateMany
   */
  export type UserProductUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserProducts.
     */
    data: XOR<UserProductUpdateManyMutationInput, UserProductUncheckedUpdateManyInput>
    /**
     * Filter which UserProducts to update
     */
    where?: UserProductWhereInput
  }


  /**
   * UserProduct upsert
   */
  export type UserProductUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * The filter to search for the UserProduct to update in case it exists.
     */
    where: UserProductWhereUniqueInput
    /**
     * In case the UserProduct found by the `where` argument doesn't exist, create a new UserProduct with this data.
     */
    create: XOR<UserProductCreateInput, UserProductUncheckedCreateInput>
    /**
     * In case the UserProduct was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserProductUpdateInput, UserProductUncheckedUpdateInput>
  }


  /**
   * UserProduct delete
   */
  export type UserProductDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
    /**
     * Filter which UserProduct to delete.
     */
    where: UserProductWhereUniqueInput
  }


  /**
   * UserProduct deleteMany
   */
  export type UserProductDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserProducts to delete
     */
    where?: UserProductWhereInput
  }


  /**
   * UserProduct without action
   */
  export type UserProductDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserProduct
     */
    select?: UserProductSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserProductInclude<ExtArgs> | null
  }



  /**
   * Model LatestStaticBuildPerProject
   */

  export type AggregateLatestStaticBuildPerProject = {
    _count: LatestStaticBuildPerProjectCountAggregateOutputType | null
    _min: LatestStaticBuildPerProjectMinAggregateOutputType | null
    _max: LatestStaticBuildPerProjectMaxAggregateOutputType | null
  }

  export type LatestStaticBuildPerProjectMinAggregateOutputType = {
    buildId: string | null
    projectId: string | null
    publishStatus: $Enums.PublishStatus | null
    updatedAt: Date | null
  }

  export type LatestStaticBuildPerProjectMaxAggregateOutputType = {
    buildId: string | null
    projectId: string | null
    publishStatus: $Enums.PublishStatus | null
    updatedAt: Date | null
  }

  export type LatestStaticBuildPerProjectCountAggregateOutputType = {
    buildId: number
    projectId: number
    publishStatus: number
    updatedAt: number
    _all: number
  }


  export type LatestStaticBuildPerProjectMinAggregateInputType = {
    buildId?: true
    projectId?: true
    publishStatus?: true
    updatedAt?: true
  }

  export type LatestStaticBuildPerProjectMaxAggregateInputType = {
    buildId?: true
    projectId?: true
    publishStatus?: true
    updatedAt?: true
  }

  export type LatestStaticBuildPerProjectCountAggregateInputType = {
    buildId?: true
    projectId?: true
    publishStatus?: true
    updatedAt?: true
    _all?: true
  }

  export type LatestStaticBuildPerProjectAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which LatestStaticBuildPerProject to aggregate.
     */
    where?: LatestStaticBuildPerProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LatestStaticBuildPerProjects to fetch.
     */
    orderBy?: LatestStaticBuildPerProjectOrderByWithRelationInput | LatestStaticBuildPerProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: LatestStaticBuildPerProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LatestStaticBuildPerProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LatestStaticBuildPerProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned LatestStaticBuildPerProjects
    **/
    _count?: true | LatestStaticBuildPerProjectCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: LatestStaticBuildPerProjectMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: LatestStaticBuildPerProjectMaxAggregateInputType
  }

  export type GetLatestStaticBuildPerProjectAggregateType<T extends LatestStaticBuildPerProjectAggregateArgs> = {
        [P in keyof T & keyof AggregateLatestStaticBuildPerProject]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateLatestStaticBuildPerProject[P]>
      : GetScalarType<T[P], AggregateLatestStaticBuildPerProject[P]>
  }




  export type LatestStaticBuildPerProjectGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: LatestStaticBuildPerProjectWhereInput
    orderBy?: LatestStaticBuildPerProjectOrderByWithAggregationInput | LatestStaticBuildPerProjectOrderByWithAggregationInput[]
    by: LatestStaticBuildPerProjectScalarFieldEnum[] | LatestStaticBuildPerProjectScalarFieldEnum
    having?: LatestStaticBuildPerProjectScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: LatestStaticBuildPerProjectCountAggregateInputType | true
    _min?: LatestStaticBuildPerProjectMinAggregateInputType
    _max?: LatestStaticBuildPerProjectMaxAggregateInputType
  }

  export type LatestStaticBuildPerProjectGroupByOutputType = {
    buildId: string
    projectId: string
    publishStatus: $Enums.PublishStatus
    updatedAt: Date
    _count: LatestStaticBuildPerProjectCountAggregateOutputType | null
    _min: LatestStaticBuildPerProjectMinAggregateOutputType | null
    _max: LatestStaticBuildPerProjectMaxAggregateOutputType | null
  }

  type GetLatestStaticBuildPerProjectGroupByPayload<T extends LatestStaticBuildPerProjectGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<LatestStaticBuildPerProjectGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof LatestStaticBuildPerProjectGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], LatestStaticBuildPerProjectGroupByOutputType[P]>
            : GetScalarType<T[P], LatestStaticBuildPerProjectGroupByOutputType[P]>
        }
      >
    >


  export type LatestStaticBuildPerProjectSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    buildId?: boolean
    projectId?: boolean
    publishStatus?: boolean
    updatedAt?: boolean
    build?: boolean | BuildDefaultArgs<ExtArgs>
    project?: boolean | ProjectDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["latestStaticBuildPerProject"]>

  export type LatestStaticBuildPerProjectSelectScalar = {
    buildId?: boolean
    projectId?: boolean
    publishStatus?: boolean
    updatedAt?: boolean
  }

  export type LatestStaticBuildPerProjectInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    build?: boolean | BuildDefaultArgs<ExtArgs>
    project?: boolean | ProjectDefaultArgs<ExtArgs>
  }


  export type $LatestStaticBuildPerProjectPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "LatestStaticBuildPerProject"
    objects: {
      build: Prisma.$BuildPayload<ExtArgs>
      project: Prisma.$ProjectPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      buildId: string
      projectId: string
      publishStatus: $Enums.PublishStatus
      updatedAt: Date
    }, ExtArgs["result"]["latestStaticBuildPerProject"]>
    composites: {}
  }


  type LatestStaticBuildPerProjectGetPayload<S extends boolean | null | undefined | LatestStaticBuildPerProjectDefaultArgs> = $Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload, S>

  type LatestStaticBuildPerProjectCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<LatestStaticBuildPerProjectFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: LatestStaticBuildPerProjectCountAggregateInputType | true
    }

  export interface LatestStaticBuildPerProjectDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['LatestStaticBuildPerProject'], meta: { name: 'LatestStaticBuildPerProject' } }
    /**
     * Find zero or one LatestStaticBuildPerProject that matches the filter.
     * @param {LatestStaticBuildPerProjectFindUniqueArgs} args - Arguments to find a LatestStaticBuildPerProject
     * @example
     * // Get one LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends LatestStaticBuildPerProjectFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectFindUniqueArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one LatestStaticBuildPerProject that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {LatestStaticBuildPerProjectFindUniqueOrThrowArgs} args - Arguments to find a LatestStaticBuildPerProject
     * @example
     * // Get one LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends LatestStaticBuildPerProjectFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first LatestStaticBuildPerProject that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectFindFirstArgs} args - Arguments to find a LatestStaticBuildPerProject
     * @example
     * // Get one LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends LatestStaticBuildPerProjectFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectFindFirstArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first LatestStaticBuildPerProject that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectFindFirstOrThrowArgs} args - Arguments to find a LatestStaticBuildPerProject
     * @example
     * // Get one LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends LatestStaticBuildPerProjectFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more LatestStaticBuildPerProjects that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all LatestStaticBuildPerProjects
     * const latestStaticBuildPerProjects = await prisma.latestStaticBuildPerProject.findMany()
     * 
     * // Get first 10 LatestStaticBuildPerProjects
     * const latestStaticBuildPerProjects = await prisma.latestStaticBuildPerProject.findMany({ take: 10 })
     * 
     * // Only select the `buildId`
     * const latestStaticBuildPerProjectWithBuildIdOnly = await prisma.latestStaticBuildPerProject.findMany({ select: { buildId: true } })
     * 
    **/
    findMany<T extends LatestStaticBuildPerProjectFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a LatestStaticBuildPerProject.
     * @param {LatestStaticBuildPerProjectCreateArgs} args - Arguments to create a LatestStaticBuildPerProject.
     * @example
     * // Create one LatestStaticBuildPerProject
     * const LatestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.create({
     *   data: {
     *     // ... data to create a LatestStaticBuildPerProject
     *   }
     * })
     * 
    **/
    create<T extends LatestStaticBuildPerProjectCreateArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectCreateArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many LatestStaticBuildPerProjects.
     *     @param {LatestStaticBuildPerProjectCreateManyArgs} args - Arguments to create many LatestStaticBuildPerProjects.
     *     @example
     *     // Create many LatestStaticBuildPerProjects
     *     const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends LatestStaticBuildPerProjectCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a LatestStaticBuildPerProject.
     * @param {LatestStaticBuildPerProjectDeleteArgs} args - Arguments to delete one LatestStaticBuildPerProject.
     * @example
     * // Delete one LatestStaticBuildPerProject
     * const LatestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.delete({
     *   where: {
     *     // ... filter to delete one LatestStaticBuildPerProject
     *   }
     * })
     * 
    **/
    delete<T extends LatestStaticBuildPerProjectDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectDeleteArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one LatestStaticBuildPerProject.
     * @param {LatestStaticBuildPerProjectUpdateArgs} args - Arguments to update one LatestStaticBuildPerProject.
     * @example
     * // Update one LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends LatestStaticBuildPerProjectUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectUpdateArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more LatestStaticBuildPerProjects.
     * @param {LatestStaticBuildPerProjectDeleteManyArgs} args - Arguments to filter LatestStaticBuildPerProjects to delete.
     * @example
     * // Delete a few LatestStaticBuildPerProjects
     * const { count } = await prisma.latestStaticBuildPerProject.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends LatestStaticBuildPerProjectDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LatestStaticBuildPerProjectDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more LatestStaticBuildPerProjects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many LatestStaticBuildPerProjects
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends LatestStaticBuildPerProjectUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one LatestStaticBuildPerProject.
     * @param {LatestStaticBuildPerProjectUpsertArgs} args - Arguments to update or create a LatestStaticBuildPerProject.
     * @example
     * // Update or create a LatestStaticBuildPerProject
     * const latestStaticBuildPerProject = await prisma.latestStaticBuildPerProject.upsert({
     *   create: {
     *     // ... data to create a LatestStaticBuildPerProject
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the LatestStaticBuildPerProject we want to update
     *   }
     * })
    **/
    upsert<T extends LatestStaticBuildPerProjectUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, LatestStaticBuildPerProjectUpsertArgs<ExtArgs>>
    ): Prisma__LatestStaticBuildPerProjectClient<$Result.GetResult<Prisma.$LatestStaticBuildPerProjectPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of LatestStaticBuildPerProjects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectCountArgs} args - Arguments to filter LatestStaticBuildPerProjects to count.
     * @example
     * // Count the number of LatestStaticBuildPerProjects
     * const count = await prisma.latestStaticBuildPerProject.count({
     *   where: {
     *     // ... the filter for the LatestStaticBuildPerProjects we want to count
     *   }
     * })
    **/
    count<T extends LatestStaticBuildPerProjectCountArgs>(
      args?: Subset<T, LatestStaticBuildPerProjectCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], LatestStaticBuildPerProjectCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a LatestStaticBuildPerProject.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends LatestStaticBuildPerProjectAggregateArgs>(args: Subset<T, LatestStaticBuildPerProjectAggregateArgs>): Prisma.PrismaPromise<GetLatestStaticBuildPerProjectAggregateType<T>>

    /**
     * Group by LatestStaticBuildPerProject.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LatestStaticBuildPerProjectGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends LatestStaticBuildPerProjectGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: LatestStaticBuildPerProjectGroupByArgs['orderBy'] }
        : { orderBy?: LatestStaticBuildPerProjectGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, LatestStaticBuildPerProjectGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetLatestStaticBuildPerProjectGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the LatestStaticBuildPerProject model
   */
  readonly fields: LatestStaticBuildPerProjectFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for LatestStaticBuildPerProject.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__LatestStaticBuildPerProjectClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    build<T extends BuildDefaultArgs<ExtArgs> = {}>(args?: Subset<T, BuildDefaultArgs<ExtArgs>>): Prisma__BuildClient<$Result.GetResult<Prisma.$BuildPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    project<T extends ProjectDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProjectDefaultArgs<ExtArgs>>): Prisma__ProjectClient<$Result.GetResult<Prisma.$ProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'> | Null, Null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the LatestStaticBuildPerProject model
   */ 
  interface LatestStaticBuildPerProjectFieldRefs {
    readonly buildId: FieldRef<"LatestStaticBuildPerProject", 'String'>
    readonly projectId: FieldRef<"LatestStaticBuildPerProject", 'String'>
    readonly publishStatus: FieldRef<"LatestStaticBuildPerProject", 'PublishStatus'>
    readonly updatedAt: FieldRef<"LatestStaticBuildPerProject", 'DateTime'>
  }
    

  // Custom InputTypes

  /**
   * LatestStaticBuildPerProject findUnique
   */
  export type LatestStaticBuildPerProjectFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter, which LatestStaticBuildPerProject to fetch.
     */
    where: LatestStaticBuildPerProjectWhereUniqueInput
  }


  /**
   * LatestStaticBuildPerProject findUniqueOrThrow
   */
  export type LatestStaticBuildPerProjectFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter, which LatestStaticBuildPerProject to fetch.
     */
    where: LatestStaticBuildPerProjectWhereUniqueInput
  }


  /**
   * LatestStaticBuildPerProject findFirst
   */
  export type LatestStaticBuildPerProjectFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter, which LatestStaticBuildPerProject to fetch.
     */
    where?: LatestStaticBuildPerProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LatestStaticBuildPerProjects to fetch.
     */
    orderBy?: LatestStaticBuildPerProjectOrderByWithRelationInput | LatestStaticBuildPerProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LatestStaticBuildPerProjects.
     */
    cursor?: LatestStaticBuildPerProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LatestStaticBuildPerProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LatestStaticBuildPerProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LatestStaticBuildPerProjects.
     */
    distinct?: LatestStaticBuildPerProjectScalarFieldEnum | LatestStaticBuildPerProjectScalarFieldEnum[]
  }


  /**
   * LatestStaticBuildPerProject findFirstOrThrow
   */
  export type LatestStaticBuildPerProjectFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter, which LatestStaticBuildPerProject to fetch.
     */
    where?: LatestStaticBuildPerProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LatestStaticBuildPerProjects to fetch.
     */
    orderBy?: LatestStaticBuildPerProjectOrderByWithRelationInput | LatestStaticBuildPerProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LatestStaticBuildPerProjects.
     */
    cursor?: LatestStaticBuildPerProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LatestStaticBuildPerProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LatestStaticBuildPerProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LatestStaticBuildPerProjects.
     */
    distinct?: LatestStaticBuildPerProjectScalarFieldEnum | LatestStaticBuildPerProjectScalarFieldEnum[]
  }


  /**
   * LatestStaticBuildPerProject findMany
   */
  export type LatestStaticBuildPerProjectFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter, which LatestStaticBuildPerProjects to fetch.
     */
    where?: LatestStaticBuildPerProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LatestStaticBuildPerProjects to fetch.
     */
    orderBy?: LatestStaticBuildPerProjectOrderByWithRelationInput | LatestStaticBuildPerProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing LatestStaticBuildPerProjects.
     */
    cursor?: LatestStaticBuildPerProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LatestStaticBuildPerProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LatestStaticBuildPerProjects.
     */
    skip?: number
    distinct?: LatestStaticBuildPerProjectScalarFieldEnum | LatestStaticBuildPerProjectScalarFieldEnum[]
  }


  /**
   * LatestStaticBuildPerProject create
   */
  export type LatestStaticBuildPerProjectCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * The data needed to create a LatestStaticBuildPerProject.
     */
    data: XOR<LatestStaticBuildPerProjectCreateInput, LatestStaticBuildPerProjectUncheckedCreateInput>
  }


  /**
   * LatestStaticBuildPerProject createMany
   */
  export type LatestStaticBuildPerProjectCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many LatestStaticBuildPerProjects.
     */
    data: LatestStaticBuildPerProjectCreateManyInput | LatestStaticBuildPerProjectCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * LatestStaticBuildPerProject update
   */
  export type LatestStaticBuildPerProjectUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * The data needed to update a LatestStaticBuildPerProject.
     */
    data: XOR<LatestStaticBuildPerProjectUpdateInput, LatestStaticBuildPerProjectUncheckedUpdateInput>
    /**
     * Choose, which LatestStaticBuildPerProject to update.
     */
    where: LatestStaticBuildPerProjectWhereUniqueInput
  }


  /**
   * LatestStaticBuildPerProject updateMany
   */
  export type LatestStaticBuildPerProjectUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update LatestStaticBuildPerProjects.
     */
    data: XOR<LatestStaticBuildPerProjectUpdateManyMutationInput, LatestStaticBuildPerProjectUncheckedUpdateManyInput>
    /**
     * Filter which LatestStaticBuildPerProjects to update
     */
    where?: LatestStaticBuildPerProjectWhereInput
  }


  /**
   * LatestStaticBuildPerProject upsert
   */
  export type LatestStaticBuildPerProjectUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * The filter to search for the LatestStaticBuildPerProject to update in case it exists.
     */
    where: LatestStaticBuildPerProjectWhereUniqueInput
    /**
     * In case the LatestStaticBuildPerProject found by the `where` argument doesn't exist, create a new LatestStaticBuildPerProject with this data.
     */
    create: XOR<LatestStaticBuildPerProjectCreateInput, LatestStaticBuildPerProjectUncheckedCreateInput>
    /**
     * In case the LatestStaticBuildPerProject was found with the provided `where` argument, update it with this data.
     */
    update: XOR<LatestStaticBuildPerProjectUpdateInput, LatestStaticBuildPerProjectUncheckedUpdateInput>
  }


  /**
   * LatestStaticBuildPerProject delete
   */
  export type LatestStaticBuildPerProjectDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
    /**
     * Filter which LatestStaticBuildPerProject to delete.
     */
    where: LatestStaticBuildPerProjectWhereUniqueInput
  }


  /**
   * LatestStaticBuildPerProject deleteMany
   */
  export type LatestStaticBuildPerProjectDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which LatestStaticBuildPerProjects to delete
     */
    where?: LatestStaticBuildPerProjectWhereInput
  }


  /**
   * LatestStaticBuildPerProject without action
   */
  export type LatestStaticBuildPerProjectDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LatestStaticBuildPerProject
     */
    select?: LatestStaticBuildPerProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: LatestStaticBuildPerProjectInclude<ExtArgs> | null
  }



  /**
   * Model DashboardProject
   */

  export type AggregateDashboardProject = {
    _count: DashboardProjectCountAggregateOutputType | null
    _min: DashboardProjectMinAggregateOutputType | null
    _max: DashboardProjectMaxAggregateOutputType | null
  }

  export type DashboardProjectMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    title: string | null
    domain: string | null
    userId: string | null
    previewImageAssetId: string | null
    isDeleted: boolean | null
    isPublished: boolean | null
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus | null
  }

  export type DashboardProjectMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    title: string | null
    domain: string | null
    userId: string | null
    previewImageAssetId: string | null
    isDeleted: boolean | null
    isPublished: boolean | null
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus | null
  }

  export type DashboardProjectCountAggregateOutputType = {
    id: number
    createdAt: number
    title: number
    domain: number
    userId: number
    previewImageAssetId: number
    isDeleted: number
    isPublished: number
    marketplaceApprovalStatus: number
    _all: number
  }


  export type DashboardProjectMinAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    previewImageAssetId?: true
    isDeleted?: true
    isPublished?: true
    marketplaceApprovalStatus?: true
  }

  export type DashboardProjectMaxAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    previewImageAssetId?: true
    isDeleted?: true
    isPublished?: true
    marketplaceApprovalStatus?: true
  }

  export type DashboardProjectCountAggregateInputType = {
    id?: true
    createdAt?: true
    title?: true
    domain?: true
    userId?: true
    previewImageAssetId?: true
    isDeleted?: true
    isPublished?: true
    marketplaceApprovalStatus?: true
    _all?: true
  }

  export type DashboardProjectAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which DashboardProject to aggregate.
     */
    where?: DashboardProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DashboardProjects to fetch.
     */
    orderBy?: DashboardProjectOrderByWithRelationInput | DashboardProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DashboardProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DashboardProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DashboardProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned DashboardProjects
    **/
    _count?: true | DashboardProjectCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DashboardProjectMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DashboardProjectMaxAggregateInputType
  }

  export type GetDashboardProjectAggregateType<T extends DashboardProjectAggregateArgs> = {
        [P in keyof T & keyof AggregateDashboardProject]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDashboardProject[P]>
      : GetScalarType<T[P], AggregateDashboardProject[P]>
  }




  export type DashboardProjectGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DashboardProjectWhereInput
    orderBy?: DashboardProjectOrderByWithAggregationInput | DashboardProjectOrderByWithAggregationInput[]
    by: DashboardProjectScalarFieldEnum[] | DashboardProjectScalarFieldEnum
    having?: DashboardProjectScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DashboardProjectCountAggregateInputType | true
    _min?: DashboardProjectMinAggregateInputType
    _max?: DashboardProjectMaxAggregateInputType
  }

  export type DashboardProjectGroupByOutputType = {
    id: string
    createdAt: Date
    title: string
    domain: string
    userId: string | null
    previewImageAssetId: string | null
    isDeleted: boolean
    isPublished: boolean
    marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus
    _count: DashboardProjectCountAggregateOutputType | null
    _min: DashboardProjectMinAggregateOutputType | null
    _max: DashboardProjectMaxAggregateOutputType | null
  }

  type GetDashboardProjectGroupByPayload<T extends DashboardProjectGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DashboardProjectGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DashboardProjectGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DashboardProjectGroupByOutputType[P]>
            : GetScalarType<T[P], DashboardProjectGroupByOutputType[P]>
        }
      >
    >


  export type DashboardProjectSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    title?: boolean
    domain?: boolean
    userId?: boolean
    previewImageAssetId?: boolean
    isDeleted?: boolean
    isPublished?: boolean
    marketplaceApprovalStatus?: boolean
    previewImageAsset?: boolean | DashboardProject$previewImageAssetArgs<ExtArgs>
  }, ExtArgs["result"]["dashboardProject"]>

  export type DashboardProjectSelectScalar = {
    id?: boolean
    createdAt?: boolean
    title?: boolean
    domain?: boolean
    userId?: boolean
    previewImageAssetId?: boolean
    isDeleted?: boolean
    isPublished?: boolean
    marketplaceApprovalStatus?: boolean
  }

  export type DashboardProjectInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    previewImageAsset?: boolean | DashboardProject$previewImageAssetArgs<ExtArgs>
  }


  export type $DashboardProjectPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "DashboardProject"
    objects: {
      previewImageAsset: Prisma.$AssetPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      title: string
      domain: string
      userId: string | null
      previewImageAssetId: string | null
      isDeleted: boolean
      isPublished: boolean
      marketplaceApprovalStatus: $Enums.MarketplaceApprovalStatus
    }, ExtArgs["result"]["dashboardProject"]>
    composites: {}
  }


  type DashboardProjectGetPayload<S extends boolean | null | undefined | DashboardProjectDefaultArgs> = $Result.GetResult<Prisma.$DashboardProjectPayload, S>

  type DashboardProjectCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<DashboardProjectFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: DashboardProjectCountAggregateInputType | true
    }

  export interface DashboardProjectDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['DashboardProject'], meta: { name: 'DashboardProject' } }
    /**
     * Find zero or one DashboardProject that matches the filter.
     * @param {DashboardProjectFindUniqueArgs} args - Arguments to find a DashboardProject
     * @example
     * // Get one DashboardProject
     * const dashboardProject = await prisma.dashboardProject.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends DashboardProjectFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectFindUniqueArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one DashboardProject that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {DashboardProjectFindUniqueOrThrowArgs} args - Arguments to find a DashboardProject
     * @example
     * // Get one DashboardProject
     * const dashboardProject = await prisma.dashboardProject.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends DashboardProjectFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first DashboardProject that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectFindFirstArgs} args - Arguments to find a DashboardProject
     * @example
     * // Get one DashboardProject
     * const dashboardProject = await prisma.dashboardProject.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends DashboardProjectFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectFindFirstArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first DashboardProject that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectFindFirstOrThrowArgs} args - Arguments to find a DashboardProject
     * @example
     * // Get one DashboardProject
     * const dashboardProject = await prisma.dashboardProject.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends DashboardProjectFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more DashboardProjects that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all DashboardProjects
     * const dashboardProjects = await prisma.dashboardProject.findMany()
     * 
     * // Get first 10 DashboardProjects
     * const dashboardProjects = await prisma.dashboardProject.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const dashboardProjectWithIdOnly = await prisma.dashboardProject.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends DashboardProjectFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a DashboardProject.
     * @param {DashboardProjectCreateArgs} args - Arguments to create a DashboardProject.
     * @example
     * // Create one DashboardProject
     * const DashboardProject = await prisma.dashboardProject.create({
     *   data: {
     *     // ... data to create a DashboardProject
     *   }
     * })
     * 
    **/
    create<T extends DashboardProjectCreateArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectCreateArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many DashboardProjects.
     *     @param {DashboardProjectCreateManyArgs} args - Arguments to create many DashboardProjects.
     *     @example
     *     // Create many DashboardProjects
     *     const dashboardProject = await prisma.dashboardProject.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends DashboardProjectCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a DashboardProject.
     * @param {DashboardProjectDeleteArgs} args - Arguments to delete one DashboardProject.
     * @example
     * // Delete one DashboardProject
     * const DashboardProject = await prisma.dashboardProject.delete({
     *   where: {
     *     // ... filter to delete one DashboardProject
     *   }
     * })
     * 
    **/
    delete<T extends DashboardProjectDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectDeleteArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one DashboardProject.
     * @param {DashboardProjectUpdateArgs} args - Arguments to update one DashboardProject.
     * @example
     * // Update one DashboardProject
     * const dashboardProject = await prisma.dashboardProject.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends DashboardProjectUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectUpdateArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more DashboardProjects.
     * @param {DashboardProjectDeleteManyArgs} args - Arguments to filter DashboardProjects to delete.
     * @example
     * // Delete a few DashboardProjects
     * const { count } = await prisma.dashboardProject.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends DashboardProjectDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DashboardProjectDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more DashboardProjects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many DashboardProjects
     * const dashboardProject = await prisma.dashboardProject.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends DashboardProjectUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one DashboardProject.
     * @param {DashboardProjectUpsertArgs} args - Arguments to update or create a DashboardProject.
     * @example
     * // Update or create a DashboardProject
     * const dashboardProject = await prisma.dashboardProject.upsert({
     *   create: {
     *     // ... data to create a DashboardProject
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the DashboardProject we want to update
     *   }
     * })
    **/
    upsert<T extends DashboardProjectUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, DashboardProjectUpsertArgs<ExtArgs>>
    ): Prisma__DashboardProjectClient<$Result.GetResult<Prisma.$DashboardProjectPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of DashboardProjects.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectCountArgs} args - Arguments to filter DashboardProjects to count.
     * @example
     * // Count the number of DashboardProjects
     * const count = await prisma.dashboardProject.count({
     *   where: {
     *     // ... the filter for the DashboardProjects we want to count
     *   }
     * })
    **/
    count<T extends DashboardProjectCountArgs>(
      args?: Subset<T, DashboardProjectCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DashboardProjectCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a DashboardProject.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DashboardProjectAggregateArgs>(args: Subset<T, DashboardProjectAggregateArgs>): Prisma.PrismaPromise<GetDashboardProjectAggregateType<T>>

    /**
     * Group by DashboardProject.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DashboardProjectGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DashboardProjectGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DashboardProjectGroupByArgs['orderBy'] }
        : { orderBy?: DashboardProjectGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DashboardProjectGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDashboardProjectGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the DashboardProject model
   */
  readonly fields: DashboardProjectFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for DashboardProject.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DashboardProjectClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';

    previewImageAsset<T extends DashboardProject$previewImageAssetArgs<ExtArgs> = {}>(args?: Subset<T, DashboardProject$previewImageAssetArgs<ExtArgs>>): Prisma__AssetClient<$Result.GetResult<Prisma.$AssetPayload<ExtArgs>, T, 'findUniqueOrThrow'> | null, null, ExtArgs>;

    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the DashboardProject model
   */ 
  interface DashboardProjectFieldRefs {
    readonly id: FieldRef<"DashboardProject", 'String'>
    readonly createdAt: FieldRef<"DashboardProject", 'DateTime'>
    readonly title: FieldRef<"DashboardProject", 'String'>
    readonly domain: FieldRef<"DashboardProject", 'String'>
    readonly userId: FieldRef<"DashboardProject", 'String'>
    readonly previewImageAssetId: FieldRef<"DashboardProject", 'String'>
    readonly isDeleted: FieldRef<"DashboardProject", 'Boolean'>
    readonly isPublished: FieldRef<"DashboardProject", 'Boolean'>
    readonly marketplaceApprovalStatus: FieldRef<"DashboardProject", 'MarketplaceApprovalStatus'>
  }
    

  // Custom InputTypes

  /**
   * DashboardProject findUnique
   */
  export type DashboardProjectFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter, which DashboardProject to fetch.
     */
    where: DashboardProjectWhereUniqueInput
  }


  /**
   * DashboardProject findUniqueOrThrow
   */
  export type DashboardProjectFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter, which DashboardProject to fetch.
     */
    where: DashboardProjectWhereUniqueInput
  }


  /**
   * DashboardProject findFirst
   */
  export type DashboardProjectFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter, which DashboardProject to fetch.
     */
    where?: DashboardProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DashboardProjects to fetch.
     */
    orderBy?: DashboardProjectOrderByWithRelationInput | DashboardProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for DashboardProjects.
     */
    cursor?: DashboardProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DashboardProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DashboardProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of DashboardProjects.
     */
    distinct?: DashboardProjectScalarFieldEnum | DashboardProjectScalarFieldEnum[]
  }


  /**
   * DashboardProject findFirstOrThrow
   */
  export type DashboardProjectFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter, which DashboardProject to fetch.
     */
    where?: DashboardProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DashboardProjects to fetch.
     */
    orderBy?: DashboardProjectOrderByWithRelationInput | DashboardProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for DashboardProjects.
     */
    cursor?: DashboardProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DashboardProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DashboardProjects.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of DashboardProjects.
     */
    distinct?: DashboardProjectScalarFieldEnum | DashboardProjectScalarFieldEnum[]
  }


  /**
   * DashboardProject findMany
   */
  export type DashboardProjectFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter, which DashboardProjects to fetch.
     */
    where?: DashboardProjectWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DashboardProjects to fetch.
     */
    orderBy?: DashboardProjectOrderByWithRelationInput | DashboardProjectOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing DashboardProjects.
     */
    cursor?: DashboardProjectWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DashboardProjects from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DashboardProjects.
     */
    skip?: number
    distinct?: DashboardProjectScalarFieldEnum | DashboardProjectScalarFieldEnum[]
  }


  /**
   * DashboardProject create
   */
  export type DashboardProjectCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * The data needed to create a DashboardProject.
     */
    data: XOR<DashboardProjectCreateInput, DashboardProjectUncheckedCreateInput>
  }


  /**
   * DashboardProject createMany
   */
  export type DashboardProjectCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many DashboardProjects.
     */
    data: DashboardProjectCreateManyInput | DashboardProjectCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * DashboardProject update
   */
  export type DashboardProjectUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * The data needed to update a DashboardProject.
     */
    data: XOR<DashboardProjectUpdateInput, DashboardProjectUncheckedUpdateInput>
    /**
     * Choose, which DashboardProject to update.
     */
    where: DashboardProjectWhereUniqueInput
  }


  /**
   * DashboardProject updateMany
   */
  export type DashboardProjectUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update DashboardProjects.
     */
    data: XOR<DashboardProjectUpdateManyMutationInput, DashboardProjectUncheckedUpdateManyInput>
    /**
     * Filter which DashboardProjects to update
     */
    where?: DashboardProjectWhereInput
  }


  /**
   * DashboardProject upsert
   */
  export type DashboardProjectUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * The filter to search for the DashboardProject to update in case it exists.
     */
    where: DashboardProjectWhereUniqueInput
    /**
     * In case the DashboardProject found by the `where` argument doesn't exist, create a new DashboardProject with this data.
     */
    create: XOR<DashboardProjectCreateInput, DashboardProjectUncheckedCreateInput>
    /**
     * In case the DashboardProject was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DashboardProjectUpdateInput, DashboardProjectUncheckedUpdateInput>
  }


  /**
   * DashboardProject delete
   */
  export type DashboardProjectDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
    /**
     * Filter which DashboardProject to delete.
     */
    where: DashboardProjectWhereUniqueInput
  }


  /**
   * DashboardProject deleteMany
   */
  export type DashboardProjectDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which DashboardProjects to delete
     */
    where?: DashboardProjectWhereInput
  }


  /**
   * DashboardProject.previewImageAsset
   */
  export type DashboardProject$previewImageAssetArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asset
     */
    select?: AssetSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: AssetInclude<ExtArgs> | null
    where?: AssetWhereInput
  }


  /**
   * DashboardProject without action
   */
  export type DashboardProjectDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DashboardProject
     */
    select?: DashboardProjectSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: DashboardProjectInclude<ExtArgs> | null
  }



  /**
   * Model ApprovedMarketplaceProduct
   */

  export type AggregateApprovedMarketplaceProduct = {
    _count: ApprovedMarketplaceProductCountAggregateOutputType | null
    _min: ApprovedMarketplaceProductMinAggregateOutputType | null
    _max: ApprovedMarketplaceProductMaxAggregateOutputType | null
  }

  export type ApprovedMarketplaceProductMinAggregateOutputType = {
    projectId: string | null
    marketplaceProduct: string | null
    authorizationToken: string | null
  }

  export type ApprovedMarketplaceProductMaxAggregateOutputType = {
    projectId: string | null
    marketplaceProduct: string | null
    authorizationToken: string | null
  }

  export type ApprovedMarketplaceProductCountAggregateOutputType = {
    projectId: number
    marketplaceProduct: number
    authorizationToken: number
    _all: number
  }


  export type ApprovedMarketplaceProductMinAggregateInputType = {
    projectId?: true
    marketplaceProduct?: true
    authorizationToken?: true
  }

  export type ApprovedMarketplaceProductMaxAggregateInputType = {
    projectId?: true
    marketplaceProduct?: true
    authorizationToken?: true
  }

  export type ApprovedMarketplaceProductCountAggregateInputType = {
    projectId?: true
    marketplaceProduct?: true
    authorizationToken?: true
    _all?: true
  }

  export type ApprovedMarketplaceProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ApprovedMarketplaceProduct to aggregate.
     */
    where?: ApprovedMarketplaceProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ApprovedMarketplaceProducts to fetch.
     */
    orderBy?: ApprovedMarketplaceProductOrderByWithRelationInput | ApprovedMarketplaceProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ApprovedMarketplaceProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ApprovedMarketplaceProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ApprovedMarketplaceProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ApprovedMarketplaceProducts
    **/
    _count?: true | ApprovedMarketplaceProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ApprovedMarketplaceProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ApprovedMarketplaceProductMaxAggregateInputType
  }

  export type GetApprovedMarketplaceProductAggregateType<T extends ApprovedMarketplaceProductAggregateArgs> = {
        [P in keyof T & keyof AggregateApprovedMarketplaceProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateApprovedMarketplaceProduct[P]>
      : GetScalarType<T[P], AggregateApprovedMarketplaceProduct[P]>
  }




  export type ApprovedMarketplaceProductGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ApprovedMarketplaceProductWhereInput
    orderBy?: ApprovedMarketplaceProductOrderByWithAggregationInput | ApprovedMarketplaceProductOrderByWithAggregationInput[]
    by: ApprovedMarketplaceProductScalarFieldEnum[] | ApprovedMarketplaceProductScalarFieldEnum
    having?: ApprovedMarketplaceProductScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ApprovedMarketplaceProductCountAggregateInputType | true
    _min?: ApprovedMarketplaceProductMinAggregateInputType
    _max?: ApprovedMarketplaceProductMaxAggregateInputType
  }

  export type ApprovedMarketplaceProductGroupByOutputType = {
    projectId: string
    marketplaceProduct: string
    authorizationToken: string | null
    _count: ApprovedMarketplaceProductCountAggregateOutputType | null
    _min: ApprovedMarketplaceProductMinAggregateOutputType | null
    _max: ApprovedMarketplaceProductMaxAggregateOutputType | null
  }

  type GetApprovedMarketplaceProductGroupByPayload<T extends ApprovedMarketplaceProductGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ApprovedMarketplaceProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ApprovedMarketplaceProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ApprovedMarketplaceProductGroupByOutputType[P]>
            : GetScalarType<T[P], ApprovedMarketplaceProductGroupByOutputType[P]>
        }
      >
    >


  export type ApprovedMarketplaceProductSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    projectId?: boolean
    marketplaceProduct?: boolean
    authorizationToken?: boolean
  }, ExtArgs["result"]["approvedMarketplaceProduct"]>

  export type ApprovedMarketplaceProductSelectScalar = {
    projectId?: boolean
    marketplaceProduct?: boolean
    authorizationToken?: boolean
  }


  export type $ApprovedMarketplaceProductPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ApprovedMarketplaceProduct"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      projectId: string
      marketplaceProduct: string
      authorizationToken: string | null
    }, ExtArgs["result"]["approvedMarketplaceProduct"]>
    composites: {}
  }


  type ApprovedMarketplaceProductGetPayload<S extends boolean | null | undefined | ApprovedMarketplaceProductDefaultArgs> = $Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload, S>

  type ApprovedMarketplaceProductCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<ApprovedMarketplaceProductFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: ApprovedMarketplaceProductCountAggregateInputType | true
    }

  export interface ApprovedMarketplaceProductDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ApprovedMarketplaceProduct'], meta: { name: 'ApprovedMarketplaceProduct' } }
    /**
     * Find zero or one ApprovedMarketplaceProduct that matches the filter.
     * @param {ApprovedMarketplaceProductFindUniqueArgs} args - Arguments to find a ApprovedMarketplaceProduct
     * @example
     * // Get one ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ApprovedMarketplaceProductFindUniqueArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductFindUniqueArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'findUnique'> | null, null, ExtArgs>

    /**
     * Find one ApprovedMarketplaceProduct that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ApprovedMarketplaceProductFindUniqueOrThrowArgs} args - Arguments to find a ApprovedMarketplaceProduct
     * @example
     * // Get one ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ApprovedMarketplaceProductFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'findUniqueOrThrow'>, never, ExtArgs>

    /**
     * Find the first ApprovedMarketplaceProduct that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductFindFirstArgs} args - Arguments to find a ApprovedMarketplaceProduct
     * @example
     * // Get one ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ApprovedMarketplaceProductFindFirstArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductFindFirstArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'findFirst'> | null, null, ExtArgs>

    /**
     * Find the first ApprovedMarketplaceProduct that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductFindFirstOrThrowArgs} args - Arguments to find a ApprovedMarketplaceProduct
     * @example
     * // Get one ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ApprovedMarketplaceProductFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'findFirstOrThrow'>, never, ExtArgs>

    /**
     * Find zero or more ApprovedMarketplaceProducts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ApprovedMarketplaceProducts
     * const approvedMarketplaceProducts = await prisma.approvedMarketplaceProduct.findMany()
     * 
     * // Get first 10 ApprovedMarketplaceProducts
     * const approvedMarketplaceProducts = await prisma.approvedMarketplaceProduct.findMany({ take: 10 })
     * 
     * // Only select the `projectId`
     * const approvedMarketplaceProductWithProjectIdOnly = await prisma.approvedMarketplaceProduct.findMany({ select: { projectId: true } })
     * 
    **/
    findMany<T extends ApprovedMarketplaceProductFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'findMany'>>

    /**
     * Create a ApprovedMarketplaceProduct.
     * @param {ApprovedMarketplaceProductCreateArgs} args - Arguments to create a ApprovedMarketplaceProduct.
     * @example
     * // Create one ApprovedMarketplaceProduct
     * const ApprovedMarketplaceProduct = await prisma.approvedMarketplaceProduct.create({
     *   data: {
     *     // ... data to create a ApprovedMarketplaceProduct
     *   }
     * })
     * 
    **/
    create<T extends ApprovedMarketplaceProductCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductCreateArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'create'>, never, ExtArgs>

    /**
     * Create many ApprovedMarketplaceProducts.
     *     @param {ApprovedMarketplaceProductCreateManyArgs} args - Arguments to create many ApprovedMarketplaceProducts.
     *     @example
     *     // Create many ApprovedMarketplaceProducts
     *     const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ApprovedMarketplaceProductCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ApprovedMarketplaceProduct.
     * @param {ApprovedMarketplaceProductDeleteArgs} args - Arguments to delete one ApprovedMarketplaceProduct.
     * @example
     * // Delete one ApprovedMarketplaceProduct
     * const ApprovedMarketplaceProduct = await prisma.approvedMarketplaceProduct.delete({
     *   where: {
     *     // ... filter to delete one ApprovedMarketplaceProduct
     *   }
     * })
     * 
    **/
    delete<T extends ApprovedMarketplaceProductDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductDeleteArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'delete'>, never, ExtArgs>

    /**
     * Update one ApprovedMarketplaceProduct.
     * @param {ApprovedMarketplaceProductUpdateArgs} args - Arguments to update one ApprovedMarketplaceProduct.
     * @example
     * // Update one ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ApprovedMarketplaceProductUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductUpdateArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'update'>, never, ExtArgs>

    /**
     * Delete zero or more ApprovedMarketplaceProducts.
     * @param {ApprovedMarketplaceProductDeleteManyArgs} args - Arguments to filter ApprovedMarketplaceProducts to delete.
     * @example
     * // Delete a few ApprovedMarketplaceProducts
     * const { count } = await prisma.approvedMarketplaceProduct.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ApprovedMarketplaceProductDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ApprovedMarketplaceProductDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ApprovedMarketplaceProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ApprovedMarketplaceProducts
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ApprovedMarketplaceProductUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ApprovedMarketplaceProduct.
     * @param {ApprovedMarketplaceProductUpsertArgs} args - Arguments to update or create a ApprovedMarketplaceProduct.
     * @example
     * // Update or create a ApprovedMarketplaceProduct
     * const approvedMarketplaceProduct = await prisma.approvedMarketplaceProduct.upsert({
     *   create: {
     *     // ... data to create a ApprovedMarketplaceProduct
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ApprovedMarketplaceProduct we want to update
     *   }
     * })
    **/
    upsert<T extends ApprovedMarketplaceProductUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ApprovedMarketplaceProductUpsertArgs<ExtArgs>>
    ): Prisma__ApprovedMarketplaceProductClient<$Result.GetResult<Prisma.$ApprovedMarketplaceProductPayload<ExtArgs>, T, 'upsert'>, never, ExtArgs>

    /**
     * Count the number of ApprovedMarketplaceProducts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductCountArgs} args - Arguments to filter ApprovedMarketplaceProducts to count.
     * @example
     * // Count the number of ApprovedMarketplaceProducts
     * const count = await prisma.approvedMarketplaceProduct.count({
     *   where: {
     *     // ... the filter for the ApprovedMarketplaceProducts we want to count
     *   }
     * })
    **/
    count<T extends ApprovedMarketplaceProductCountArgs>(
      args?: Subset<T, ApprovedMarketplaceProductCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ApprovedMarketplaceProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ApprovedMarketplaceProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ApprovedMarketplaceProductAggregateArgs>(args: Subset<T, ApprovedMarketplaceProductAggregateArgs>): Prisma.PrismaPromise<GetApprovedMarketplaceProductAggregateType<T>>

    /**
     * Group by ApprovedMarketplaceProduct.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovedMarketplaceProductGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ApprovedMarketplaceProductGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ApprovedMarketplaceProductGroupByArgs['orderBy'] }
        : { orderBy?: ApprovedMarketplaceProductGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ApprovedMarketplaceProductGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetApprovedMarketplaceProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ApprovedMarketplaceProduct model
   */
  readonly fields: ApprovedMarketplaceProductFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ApprovedMarketplaceProduct.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ApprovedMarketplaceProductClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: 'PrismaPromise';


    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>;
  }



  /**
   * Fields of the ApprovedMarketplaceProduct model
   */ 
  interface ApprovedMarketplaceProductFieldRefs {
    readonly projectId: FieldRef<"ApprovedMarketplaceProduct", 'String'>
    readonly marketplaceProduct: FieldRef<"ApprovedMarketplaceProduct", 'String'>
    readonly authorizationToken: FieldRef<"ApprovedMarketplaceProduct", 'String'>
  }
    

  // Custom InputTypes

  /**
   * ApprovedMarketplaceProduct findUnique
   */
  export type ApprovedMarketplaceProductFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter, which ApprovedMarketplaceProduct to fetch.
     */
    where: ApprovedMarketplaceProductWhereUniqueInput
  }


  /**
   * ApprovedMarketplaceProduct findUniqueOrThrow
   */
  export type ApprovedMarketplaceProductFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter, which ApprovedMarketplaceProduct to fetch.
     */
    where: ApprovedMarketplaceProductWhereUniqueInput
  }


  /**
   * ApprovedMarketplaceProduct findFirst
   */
  export type ApprovedMarketplaceProductFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter, which ApprovedMarketplaceProduct to fetch.
     */
    where?: ApprovedMarketplaceProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ApprovedMarketplaceProducts to fetch.
     */
    orderBy?: ApprovedMarketplaceProductOrderByWithRelationInput | ApprovedMarketplaceProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ApprovedMarketplaceProducts.
     */
    cursor?: ApprovedMarketplaceProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ApprovedMarketplaceProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ApprovedMarketplaceProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ApprovedMarketplaceProducts.
     */
    distinct?: ApprovedMarketplaceProductScalarFieldEnum | ApprovedMarketplaceProductScalarFieldEnum[]
  }


  /**
   * ApprovedMarketplaceProduct findFirstOrThrow
   */
  export type ApprovedMarketplaceProductFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter, which ApprovedMarketplaceProduct to fetch.
     */
    where?: ApprovedMarketplaceProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ApprovedMarketplaceProducts to fetch.
     */
    orderBy?: ApprovedMarketplaceProductOrderByWithRelationInput | ApprovedMarketplaceProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ApprovedMarketplaceProducts.
     */
    cursor?: ApprovedMarketplaceProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ApprovedMarketplaceProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ApprovedMarketplaceProducts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ApprovedMarketplaceProducts.
     */
    distinct?: ApprovedMarketplaceProductScalarFieldEnum | ApprovedMarketplaceProductScalarFieldEnum[]
  }


  /**
   * ApprovedMarketplaceProduct findMany
   */
  export type ApprovedMarketplaceProductFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter, which ApprovedMarketplaceProducts to fetch.
     */
    where?: ApprovedMarketplaceProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ApprovedMarketplaceProducts to fetch.
     */
    orderBy?: ApprovedMarketplaceProductOrderByWithRelationInput | ApprovedMarketplaceProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ApprovedMarketplaceProducts.
     */
    cursor?: ApprovedMarketplaceProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ApprovedMarketplaceProducts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ApprovedMarketplaceProducts.
     */
    skip?: number
    distinct?: ApprovedMarketplaceProductScalarFieldEnum | ApprovedMarketplaceProductScalarFieldEnum[]
  }


  /**
   * ApprovedMarketplaceProduct create
   */
  export type ApprovedMarketplaceProductCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * The data needed to create a ApprovedMarketplaceProduct.
     */
    data: XOR<ApprovedMarketplaceProductCreateInput, ApprovedMarketplaceProductUncheckedCreateInput>
  }


  /**
   * ApprovedMarketplaceProduct createMany
   */
  export type ApprovedMarketplaceProductCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ApprovedMarketplaceProducts.
     */
    data: ApprovedMarketplaceProductCreateManyInput | ApprovedMarketplaceProductCreateManyInput[]
    skipDuplicates?: boolean
  }


  /**
   * ApprovedMarketplaceProduct update
   */
  export type ApprovedMarketplaceProductUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * The data needed to update a ApprovedMarketplaceProduct.
     */
    data: XOR<ApprovedMarketplaceProductUpdateInput, ApprovedMarketplaceProductUncheckedUpdateInput>
    /**
     * Choose, which ApprovedMarketplaceProduct to update.
     */
    where: ApprovedMarketplaceProductWhereUniqueInput
  }


  /**
   * ApprovedMarketplaceProduct updateMany
   */
  export type ApprovedMarketplaceProductUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ApprovedMarketplaceProducts.
     */
    data: XOR<ApprovedMarketplaceProductUpdateManyMutationInput, ApprovedMarketplaceProductUncheckedUpdateManyInput>
    /**
     * Filter which ApprovedMarketplaceProducts to update
     */
    where?: ApprovedMarketplaceProductWhereInput
  }


  /**
   * ApprovedMarketplaceProduct upsert
   */
  export type ApprovedMarketplaceProductUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * The filter to search for the ApprovedMarketplaceProduct to update in case it exists.
     */
    where: ApprovedMarketplaceProductWhereUniqueInput
    /**
     * In case the ApprovedMarketplaceProduct found by the `where` argument doesn't exist, create a new ApprovedMarketplaceProduct with this data.
     */
    create: XOR<ApprovedMarketplaceProductCreateInput, ApprovedMarketplaceProductUncheckedCreateInput>
    /**
     * In case the ApprovedMarketplaceProduct was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ApprovedMarketplaceProductUpdateInput, ApprovedMarketplaceProductUncheckedUpdateInput>
  }


  /**
   * ApprovedMarketplaceProduct delete
   */
  export type ApprovedMarketplaceProductDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
    /**
     * Filter which ApprovedMarketplaceProduct to delete.
     */
    where: ApprovedMarketplaceProductWhereUniqueInput
  }


  /**
   * ApprovedMarketplaceProduct deleteMany
   */
  export type ApprovedMarketplaceProductDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ApprovedMarketplaceProducts to delete
     */
    where?: ApprovedMarketplaceProductWhereInput
  }


  /**
   * ApprovedMarketplaceProduct without action
   */
  export type ApprovedMarketplaceProductDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ApprovedMarketplaceProduct
     */
    select?: ApprovedMarketplaceProductSelect<ExtArgs> | null
  }



  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const TeamScalarFieldEnum: {
    id: 'id'
  };

  export type TeamScalarFieldEnum = (typeof TeamScalarFieldEnum)[keyof typeof TeamScalarFieldEnum]


  export const FileScalarFieldEnum: {
    name: 'name',
    format: 'format',
    size: 'size',
    description: 'description',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    meta: 'meta',
    status: 'status',
    isDeleted: 'isDeleted',
    uploaderProjectId: 'uploaderProjectId'
  };

  export type FileScalarFieldEnum = (typeof FileScalarFieldEnum)[keyof typeof FileScalarFieldEnum]


  export const AssetScalarFieldEnum: {
    id: 'id',
    projectId: 'projectId',
    name: 'name',
    filename: 'filename',
    description: 'description'
  };

  export type AssetScalarFieldEnum = (typeof AssetScalarFieldEnum)[keyof typeof AssetScalarFieldEnum]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    provider: 'provider',
    image: 'image',
    username: 'username',
    createdAt: 'createdAt',
    teamId: 'teamId'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const ClientReferencesScalarFieldEnum: {
    reference: 'reference',
    service: 'service',
    createdAt: 'createdAt',
    userId: 'userId'
  };

  export type ClientReferencesScalarFieldEnum = (typeof ClientReferencesScalarFieldEnum)[keyof typeof ClientReferencesScalarFieldEnum]


  export const ProductScalarFieldEnum: {
    id: 'id',
    name: 'name',
    description: 'description',
    features: 'features',
    images: 'images',
    meta: 'meta',
    createdAt: 'createdAt'
  };

  export type ProductScalarFieldEnum = (typeof ProductScalarFieldEnum)[keyof typeof ProductScalarFieldEnum]


  export const TransactionLogScalarFieldEnum: {
    eventId: 'eventId',
    userId: 'userId',
    productId: 'productId',
    createdAt: 'createdAt',
    eventData: 'eventData',
    eventType: 'eventType',
    eventCreated: 'eventCreated',
    status: 'status',
    customerId: 'customerId',
    customerEmail: 'customerEmail',
    subscriptionId: 'subscriptionId',
    paymentIntent: 'paymentIntent'
  };

  export type TransactionLogScalarFieldEnum = (typeof TransactionLogScalarFieldEnum)[keyof typeof TransactionLogScalarFieldEnum]


  export const ProjectScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    title: 'title',
    domain: 'domain',
    userId: 'userId',
    isDeleted: 'isDeleted',
    previewImageAssetId: 'previewImageAssetId',
    marketplaceApprovalStatus: 'marketplaceApprovalStatus'
  };

  export type ProjectScalarFieldEnum = (typeof ProjectScalarFieldEnum)[keyof typeof ProjectScalarFieldEnum]


  export const BuildScalarFieldEnum: {
    id: 'id',
    version: 'version',
    lastTransactionId: 'lastTransactionId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    pages: 'pages',
    projectId: 'projectId',
    breakpoints: 'breakpoints',
    styles: 'styles',
    styleSources: 'styleSources',
    styleSourceSelections: 'styleSourceSelections',
    props: 'props',
    dataSources: 'dataSources',
    resources: 'resources',
    instances: 'instances',
    marketplaceProduct: 'marketplaceProduct',
    deployment: 'deployment',
    publishStatus: 'publishStatus'
  };

  export type BuildScalarFieldEnum = (typeof BuildScalarFieldEnum)[keyof typeof BuildScalarFieldEnum]


  export const AuthorizationTokenScalarFieldEnum: {
    token: 'token',
    projectId: 'projectId',
    name: 'name',
    relation: 'relation',
    createdAt: 'createdAt',
    canClone: 'canClone',
    canCopy: 'canCopy'
  };

  export type AuthorizationTokenScalarFieldEnum = (typeof AuthorizationTokenScalarFieldEnum)[keyof typeof AuthorizationTokenScalarFieldEnum]


  export const DomainScalarFieldEnum: {
    id: 'id',
    domain: 'domain',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    txtRecord: 'txtRecord',
    status: 'status',
    error: 'error'
  };

  export type DomainScalarFieldEnum = (typeof DomainScalarFieldEnum)[keyof typeof DomainScalarFieldEnum]


  export const ProjectDomainScalarFieldEnum: {
    projectId: 'projectId',
    domainId: 'domainId',
    createdAt: 'createdAt',
    txtRecord: 'txtRecord',
    cname: 'cname'
  };

  export type ProjectDomainScalarFieldEnum = (typeof ProjectDomainScalarFieldEnum)[keyof typeof ProjectDomainScalarFieldEnum]


  export const UserProductScalarFieldEnum: {
    userId: 'userId',
    productId: 'productId',
    subscriptionId: 'subscriptionId',
    customerId: 'customerId',
    customerEmail: 'customerEmail'
  };

  export type UserProductScalarFieldEnum = (typeof UserProductScalarFieldEnum)[keyof typeof UserProductScalarFieldEnum]


  export const LatestStaticBuildPerProjectScalarFieldEnum: {
    buildId: 'buildId',
    projectId: 'projectId',
    publishStatus: 'publishStatus',
    updatedAt: 'updatedAt'
  };

  export type LatestStaticBuildPerProjectScalarFieldEnum = (typeof LatestStaticBuildPerProjectScalarFieldEnum)[keyof typeof LatestStaticBuildPerProjectScalarFieldEnum]


  export const DashboardProjectScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    title: 'title',
    domain: 'domain',
    userId: 'userId',
    previewImageAssetId: 'previewImageAssetId',
    isDeleted: 'isDeleted',
    isPublished: 'isPublished',
    marketplaceApprovalStatus: 'marketplaceApprovalStatus'
  };

  export type DashboardProjectScalarFieldEnum = (typeof DashboardProjectScalarFieldEnum)[keyof typeof DashboardProjectScalarFieldEnum]


  export const ApprovedMarketplaceProductScalarFieldEnum: {
    projectId: 'projectId',
    marketplaceProduct: 'marketplaceProduct',
    authorizationToken: 'authorizationToken'
  };

  export type ApprovedMarketplaceProductScalarFieldEnum = (typeof ApprovedMarketplaceProductScalarFieldEnum)[keyof typeof ApprovedMarketplaceProductScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references 
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'UploadStatus'
   */
  export type EnumUploadStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'UploadStatus'>
    


  /**
   * Reference to a field of type 'UploadStatus[]'
   */
  export type ListEnumUploadStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'UploadStatus[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'MarketplaceApprovalStatus'
   */
  export type EnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MarketplaceApprovalStatus'>
    


  /**
   * Reference to a field of type 'MarketplaceApprovalStatus[]'
   */
  export type ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MarketplaceApprovalStatus[]'>
    


  /**
   * Reference to a field of type 'PublishStatus'
   */
  export type EnumPublishStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PublishStatus'>
    


  /**
   * Reference to a field of type 'PublishStatus[]'
   */
  export type ListEnumPublishStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PublishStatus[]'>
    


  /**
   * Reference to a field of type 'AuthorizationRelation'
   */
  export type EnumAuthorizationRelationFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'AuthorizationRelation'>
    


  /**
   * Reference to a field of type 'AuthorizationRelation[]'
   */
  export type ListEnumAuthorizationRelationFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'AuthorizationRelation[]'>
    


  /**
   * Reference to a field of type 'DomainStatus'
   */
  export type EnumDomainStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DomainStatus'>
    


  /**
   * Reference to a field of type 'DomainStatus[]'
   */
  export type ListEnumDomainStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DomainStatus[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type TeamWhereInput = {
    AND?: TeamWhereInput | TeamWhereInput[]
    OR?: TeamWhereInput[]
    NOT?: TeamWhereInput | TeamWhereInput[]
    id?: StringFilter<"Team"> | string
    users?: UserListRelationFilter
  }

  export type TeamOrderByWithRelationInput = {
    id?: SortOrder
    users?: UserOrderByRelationAggregateInput
  }

  export type TeamWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TeamWhereInput | TeamWhereInput[]
    OR?: TeamWhereInput[]
    NOT?: TeamWhereInput | TeamWhereInput[]
    users?: UserListRelationFilter
  }, "id">

  export type TeamOrderByWithAggregationInput = {
    id?: SortOrder
    _count?: TeamCountOrderByAggregateInput
    _max?: TeamMaxOrderByAggregateInput
    _min?: TeamMinOrderByAggregateInput
  }

  export type TeamScalarWhereWithAggregatesInput = {
    AND?: TeamScalarWhereWithAggregatesInput | TeamScalarWhereWithAggregatesInput[]
    OR?: TeamScalarWhereWithAggregatesInput[]
    NOT?: TeamScalarWhereWithAggregatesInput | TeamScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Team"> | string
  }

  export type FileWhereInput = {
    AND?: FileWhereInput | FileWhereInput[]
    OR?: FileWhereInput[]
    NOT?: FileWhereInput | FileWhereInput[]
    name?: StringFilter<"File"> | string
    format?: StringFilter<"File"> | string
    size?: IntFilter<"File"> | number
    description?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    updatedAt?: DateTimeFilter<"File"> | Date | string
    meta?: StringFilter<"File"> | string
    status?: EnumUploadStatusFilter<"File"> | $Enums.UploadStatus
    isDeleted?: BoolFilter<"File"> | boolean
    uploaderProjectId?: StringNullableFilter<"File"> | string | null
    uploaderProject?: XOR<ProjectNullableRelationFilter, ProjectWhereInput> | null
    assets?: AssetListRelationFilter
  }

  export type FileOrderByWithRelationInput = {
    name?: SortOrder
    format?: SortOrder
    size?: SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meta?: SortOrder
    status?: SortOrder
    isDeleted?: SortOrder
    uploaderProjectId?: SortOrderInput | SortOrder
    uploaderProject?: ProjectOrderByWithRelationInput
    assets?: AssetOrderByRelationAggregateInput
  }

  export type FileWhereUniqueInput = Prisma.AtLeast<{
    name?: string
    AND?: FileWhereInput | FileWhereInput[]
    OR?: FileWhereInput[]
    NOT?: FileWhereInput | FileWhereInput[]
    format?: StringFilter<"File"> | string
    size?: IntFilter<"File"> | number
    description?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    updatedAt?: DateTimeFilter<"File"> | Date | string
    meta?: StringFilter<"File"> | string
    status?: EnumUploadStatusFilter<"File"> | $Enums.UploadStatus
    isDeleted?: BoolFilter<"File"> | boolean
    uploaderProjectId?: StringNullableFilter<"File"> | string | null
    uploaderProject?: XOR<ProjectNullableRelationFilter, ProjectWhereInput> | null
    assets?: AssetListRelationFilter
  }, "name">

  export type FileOrderByWithAggregationInput = {
    name?: SortOrder
    format?: SortOrder
    size?: SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meta?: SortOrder
    status?: SortOrder
    isDeleted?: SortOrder
    uploaderProjectId?: SortOrderInput | SortOrder
    _count?: FileCountOrderByAggregateInput
    _avg?: FileAvgOrderByAggregateInput
    _max?: FileMaxOrderByAggregateInput
    _min?: FileMinOrderByAggregateInput
    _sum?: FileSumOrderByAggregateInput
  }

  export type FileScalarWhereWithAggregatesInput = {
    AND?: FileScalarWhereWithAggregatesInput | FileScalarWhereWithAggregatesInput[]
    OR?: FileScalarWhereWithAggregatesInput[]
    NOT?: FileScalarWhereWithAggregatesInput | FileScalarWhereWithAggregatesInput[]
    name?: StringWithAggregatesFilter<"File"> | string
    format?: StringWithAggregatesFilter<"File"> | string
    size?: IntWithAggregatesFilter<"File"> | number
    description?: StringNullableWithAggregatesFilter<"File"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"File"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"File"> | Date | string
    meta?: StringWithAggregatesFilter<"File"> | string
    status?: EnumUploadStatusWithAggregatesFilter<"File"> | $Enums.UploadStatus
    isDeleted?: BoolWithAggregatesFilter<"File"> | boolean
    uploaderProjectId?: StringNullableWithAggregatesFilter<"File"> | string | null
  }

  export type AssetWhereInput = {
    AND?: AssetWhereInput | AssetWhereInput[]
    OR?: AssetWhereInput[]
    NOT?: AssetWhereInput | AssetWhereInput[]
    id?: StringFilter<"Asset"> | string
    projectId?: StringFilter<"Asset"> | string
    name?: StringFilter<"Asset"> | string
    filename?: StringNullableFilter<"Asset"> | string | null
    description?: StringNullableFilter<"Asset"> | string | null
    file?: XOR<FileRelationFilter, FileWhereInput>
    Project?: ProjectListRelationFilter
    DashboardProject?: DashboardProjectListRelationFilter
  }

  export type AssetOrderByWithRelationInput = {
    id?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    filename?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    file?: FileOrderByWithRelationInput
    Project?: ProjectOrderByRelationAggregateInput
    DashboardProject?: DashboardProjectOrderByRelationAggregateInput
  }

  export type AssetWhereUniqueInput = Prisma.AtLeast<{
    id_projectId?: AssetIdProjectIdCompoundUniqueInput
    AND?: AssetWhereInput | AssetWhereInput[]
    OR?: AssetWhereInput[]
    NOT?: AssetWhereInput | AssetWhereInput[]
    id?: StringFilter<"Asset"> | string
    projectId?: StringFilter<"Asset"> | string
    name?: StringFilter<"Asset"> | string
    filename?: StringNullableFilter<"Asset"> | string | null
    description?: StringNullableFilter<"Asset"> | string | null
    file?: XOR<FileRelationFilter, FileWhereInput>
    Project?: ProjectListRelationFilter
    DashboardProject?: DashboardProjectListRelationFilter
  }, "id_projectId">

  export type AssetOrderByWithAggregationInput = {
    id?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    filename?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    _count?: AssetCountOrderByAggregateInput
    _max?: AssetMaxOrderByAggregateInput
    _min?: AssetMinOrderByAggregateInput
  }

  export type AssetScalarWhereWithAggregatesInput = {
    AND?: AssetScalarWhereWithAggregatesInput | AssetScalarWhereWithAggregatesInput[]
    OR?: AssetScalarWhereWithAggregatesInput[]
    NOT?: AssetScalarWhereWithAggregatesInput | AssetScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Asset"> | string
    projectId?: StringWithAggregatesFilter<"Asset"> | string
    name?: StringWithAggregatesFilter<"Asset"> | string
    filename?: StringNullableWithAggregatesFilter<"Asset"> | string | null
    description?: StringNullableWithAggregatesFilter<"Asset"> | string | null
  }

  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringNullableFilter<"User"> | string | null
    provider?: StringNullableFilter<"User"> | string | null
    image?: StringNullableFilter<"User"> | string | null
    username?: StringNullableFilter<"User"> | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    teamId?: StringNullableFilter<"User"> | string | null
    team?: XOR<TeamNullableRelationFilter, TeamWhereInput> | null
    projects?: ProjectListRelationFilter
    clientReferences?: ClientReferencesListRelationFilter
    checkout?: TransactionLogListRelationFilter
    products?: UserProductListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrderInput | SortOrder
    provider?: SortOrderInput | SortOrder
    image?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    teamId?: SortOrderInput | SortOrder
    team?: TeamOrderByWithRelationInput
    projects?: ProjectOrderByRelationAggregateInput
    clientReferences?: ClientReferencesOrderByRelationAggregateInput
    checkout?: TransactionLogOrderByRelationAggregateInput
    products?: UserProductOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    provider?: StringNullableFilter<"User"> | string | null
    image?: StringNullableFilter<"User"> | string | null
    username?: StringNullableFilter<"User"> | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    teamId?: StringNullableFilter<"User"> | string | null
    team?: XOR<TeamNullableRelationFilter, TeamWhereInput> | null
    projects?: ProjectListRelationFilter
    clientReferences?: ClientReferencesListRelationFilter
    checkout?: TransactionLogListRelationFilter
    products?: UserProductListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrderInput | SortOrder
    provider?: SortOrderInput | SortOrder
    image?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    teamId?: SortOrderInput | SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    email?: StringNullableWithAggregatesFilter<"User"> | string | null
    provider?: StringNullableWithAggregatesFilter<"User"> | string | null
    image?: StringNullableWithAggregatesFilter<"User"> | string | null
    username?: StringNullableWithAggregatesFilter<"User"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    teamId?: StringNullableWithAggregatesFilter<"User"> | string | null
  }

  export type ClientReferencesWhereInput = {
    AND?: ClientReferencesWhereInput | ClientReferencesWhereInput[]
    OR?: ClientReferencesWhereInput[]
    NOT?: ClientReferencesWhereInput | ClientReferencesWhereInput[]
    reference?: StringFilter<"ClientReferences"> | string
    service?: StringFilter<"ClientReferences"> | string
    createdAt?: DateTimeFilter<"ClientReferences"> | Date | string
    userId?: StringFilter<"ClientReferences"> | string
    user?: XOR<UserRelationFilter, UserWhereInput>
  }

  export type ClientReferencesOrderByWithRelationInput = {
    reference?: SortOrder
    service?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type ClientReferencesWhereUniqueInput = Prisma.AtLeast<{
    reference_service?: ClientReferencesReferenceServiceCompoundUniqueInput
    userId_service?: ClientReferencesUserIdServiceCompoundUniqueInput
    AND?: ClientReferencesWhereInput | ClientReferencesWhereInput[]
    OR?: ClientReferencesWhereInput[]
    NOT?: ClientReferencesWhereInput | ClientReferencesWhereInput[]
    reference?: StringFilter<"ClientReferences"> | string
    service?: StringFilter<"ClientReferences"> | string
    createdAt?: DateTimeFilter<"ClientReferences"> | Date | string
    userId?: StringFilter<"ClientReferences"> | string
    user?: XOR<UserRelationFilter, UserWhereInput>
  }, "userId_service" | "reference_service">

  export type ClientReferencesOrderByWithAggregationInput = {
    reference?: SortOrder
    service?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    _count?: ClientReferencesCountOrderByAggregateInput
    _max?: ClientReferencesMaxOrderByAggregateInput
    _min?: ClientReferencesMinOrderByAggregateInput
  }

  export type ClientReferencesScalarWhereWithAggregatesInput = {
    AND?: ClientReferencesScalarWhereWithAggregatesInput | ClientReferencesScalarWhereWithAggregatesInput[]
    OR?: ClientReferencesScalarWhereWithAggregatesInput[]
    NOT?: ClientReferencesScalarWhereWithAggregatesInput | ClientReferencesScalarWhereWithAggregatesInput[]
    reference?: StringWithAggregatesFilter<"ClientReferences"> | string
    service?: StringWithAggregatesFilter<"ClientReferences"> | string
    createdAt?: DateTimeWithAggregatesFilter<"ClientReferences"> | Date | string
    userId?: StringWithAggregatesFilter<"ClientReferences"> | string
  }

  export type ProductWhereInput = {
    AND?: ProductWhereInput | ProductWhereInput[]
    OR?: ProductWhereInput[]
    NOT?: ProductWhereInput | ProductWhereInput[]
    id?: StringFilter<"Product"> | string
    name?: StringFilter<"Product"> | string
    description?: StringNullableFilter<"Product"> | string | null
    features?: StringNullableListFilter<"Product">
    images?: StringNullableListFilter<"Product">
    meta?: JsonFilter<"Product">
    createdAt?: DateTimeFilter<"Product"> | Date | string
    checkout?: TransactionLogListRelationFilter
    userProducts?: UserProductListRelationFilter
  }

  export type ProductOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    features?: SortOrder
    images?: SortOrder
    meta?: SortOrder
    createdAt?: SortOrder
    checkout?: TransactionLogOrderByRelationAggregateInput
    userProducts?: UserProductOrderByRelationAggregateInput
  }

  export type ProductWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ProductWhereInput | ProductWhereInput[]
    OR?: ProductWhereInput[]
    NOT?: ProductWhereInput | ProductWhereInput[]
    name?: StringFilter<"Product"> | string
    description?: StringNullableFilter<"Product"> | string | null
    features?: StringNullableListFilter<"Product">
    images?: StringNullableListFilter<"Product">
    meta?: JsonFilter<"Product">
    createdAt?: DateTimeFilter<"Product"> | Date | string
    checkout?: TransactionLogListRelationFilter
    userProducts?: UserProductListRelationFilter
  }, "id">

  export type ProductOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    features?: SortOrder
    images?: SortOrder
    meta?: SortOrder
    createdAt?: SortOrder
    _count?: ProductCountOrderByAggregateInput
    _max?: ProductMaxOrderByAggregateInput
    _min?: ProductMinOrderByAggregateInput
  }

  export type ProductScalarWhereWithAggregatesInput = {
    AND?: ProductScalarWhereWithAggregatesInput | ProductScalarWhereWithAggregatesInput[]
    OR?: ProductScalarWhereWithAggregatesInput[]
    NOT?: ProductScalarWhereWithAggregatesInput | ProductScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Product"> | string
    name?: StringWithAggregatesFilter<"Product"> | string
    description?: StringNullableWithAggregatesFilter<"Product"> | string | null
    features?: StringNullableListFilter<"Product">
    images?: StringNullableListFilter<"Product">
    meta?: JsonWithAggregatesFilter<"Product">
    createdAt?: DateTimeWithAggregatesFilter<"Product"> | Date | string
  }

  export type TransactionLogWhereInput = {
    AND?: TransactionLogWhereInput | TransactionLogWhereInput[]
    OR?: TransactionLogWhereInput[]
    NOT?: TransactionLogWhereInput | TransactionLogWhereInput[]
    eventId?: StringFilter<"TransactionLog"> | string
    userId?: StringNullableFilter<"TransactionLog"> | string | null
    productId?: StringNullableFilter<"TransactionLog"> | string | null
    createdAt?: DateTimeFilter<"TransactionLog"> | Date | string
    eventData?: JsonNullableFilter<"TransactionLog">
    eventType?: StringNullableFilter<"TransactionLog"> | string | null
    eventCreated?: IntNullableFilter<"TransactionLog"> | number | null
    status?: StringNullableFilter<"TransactionLog"> | string | null
    customerId?: StringNullableFilter<"TransactionLog"> | string | null
    customerEmail?: StringNullableFilter<"TransactionLog"> | string | null
    subscriptionId?: StringNullableFilter<"TransactionLog"> | string | null
    paymentIntent?: StringNullableFilter<"TransactionLog"> | string | null
    user?: XOR<UserNullableRelationFilter, UserWhereInput> | null
    product?: XOR<ProductNullableRelationFilter, ProductWhereInput> | null
  }

  export type TransactionLogOrderByWithRelationInput = {
    eventId?: SortOrder
    userId?: SortOrderInput | SortOrder
    productId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    eventData?: SortOrderInput | SortOrder
    eventType?: SortOrderInput | SortOrder
    eventCreated?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    customerId?: SortOrderInput | SortOrder
    customerEmail?: SortOrderInput | SortOrder
    subscriptionId?: SortOrderInput | SortOrder
    paymentIntent?: SortOrderInput | SortOrder
    user?: UserOrderByWithRelationInput
    product?: ProductOrderByWithRelationInput
  }

  export type TransactionLogWhereUniqueInput = Prisma.AtLeast<{
    eventId?: string
    eventId_productId?: TransactionLogEventIdProductIdCompoundUniqueInput
    AND?: TransactionLogWhereInput | TransactionLogWhereInput[]
    OR?: TransactionLogWhereInput[]
    NOT?: TransactionLogWhereInput | TransactionLogWhereInput[]
    userId?: StringNullableFilter<"TransactionLog"> | string | null
    productId?: StringNullableFilter<"TransactionLog"> | string | null
    createdAt?: DateTimeFilter<"TransactionLog"> | Date | string
    eventData?: JsonNullableFilter<"TransactionLog">
    eventType?: StringNullableFilter<"TransactionLog"> | string | null
    eventCreated?: IntNullableFilter<"TransactionLog"> | number | null
    status?: StringNullableFilter<"TransactionLog"> | string | null
    customerId?: StringNullableFilter<"TransactionLog"> | string | null
    customerEmail?: StringNullableFilter<"TransactionLog"> | string | null
    subscriptionId?: StringNullableFilter<"TransactionLog"> | string | null
    paymentIntent?: StringNullableFilter<"TransactionLog"> | string | null
    user?: XOR<UserNullableRelationFilter, UserWhereInput> | null
    product?: XOR<ProductNullableRelationFilter, ProductWhereInput> | null
  }, "eventId" | "eventId_productId">

  export type TransactionLogOrderByWithAggregationInput = {
    eventId?: SortOrder
    userId?: SortOrderInput | SortOrder
    productId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    eventData?: SortOrderInput | SortOrder
    eventType?: SortOrderInput | SortOrder
    eventCreated?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    customerId?: SortOrderInput | SortOrder
    customerEmail?: SortOrderInput | SortOrder
    subscriptionId?: SortOrderInput | SortOrder
    paymentIntent?: SortOrderInput | SortOrder
    _count?: TransactionLogCountOrderByAggregateInput
    _avg?: TransactionLogAvgOrderByAggregateInput
    _max?: TransactionLogMaxOrderByAggregateInput
    _min?: TransactionLogMinOrderByAggregateInput
    _sum?: TransactionLogSumOrderByAggregateInput
  }

  export type TransactionLogScalarWhereWithAggregatesInput = {
    AND?: TransactionLogScalarWhereWithAggregatesInput | TransactionLogScalarWhereWithAggregatesInput[]
    OR?: TransactionLogScalarWhereWithAggregatesInput[]
    NOT?: TransactionLogScalarWhereWithAggregatesInput | TransactionLogScalarWhereWithAggregatesInput[]
    eventId?: StringWithAggregatesFilter<"TransactionLog"> | string
    userId?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    productId?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"TransactionLog"> | Date | string
    eventData?: JsonNullableWithAggregatesFilter<"TransactionLog">
    eventType?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    eventCreated?: IntNullableWithAggregatesFilter<"TransactionLog"> | number | null
    status?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    customerId?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    customerEmail?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    subscriptionId?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
    paymentIntent?: StringNullableWithAggregatesFilter<"TransactionLog"> | string | null
  }

  export type ProjectWhereInput = {
    AND?: ProjectWhereInput | ProjectWhereInput[]
    OR?: ProjectWhereInput[]
    NOT?: ProjectWhereInput | ProjectWhereInput[]
    id?: StringFilter<"Project"> | string
    createdAt?: DateTimeFilter<"Project"> | Date | string
    title?: StringFilter<"Project"> | string
    domain?: StringFilter<"Project"> | string
    userId?: StringNullableFilter<"Project"> | string | null
    isDeleted?: BoolFilter<"Project"> | boolean
    previewImageAssetId?: StringNullableFilter<"Project"> | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"Project"> | $Enums.MarketplaceApprovalStatus
    user?: XOR<UserNullableRelationFilter, UserWhereInput> | null
    build?: BuildListRelationFilter
    files?: FileListRelationFilter
    projectDomain?: ProjectDomainListRelationFilter
    authorizationToken?: AuthorizationTokenListRelationFilter
    previewImageAsset?: XOR<AssetNullableRelationFilter, AssetWhereInput> | null
    latestStaticBuild?: XOR<LatestStaticBuildPerProjectNullableRelationFilter, LatestStaticBuildPerProjectWhereInput> | null
  }

  export type ProjectOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
    previewImageAssetId?: SortOrderInput | SortOrder
    marketplaceApprovalStatus?: SortOrder
    user?: UserOrderByWithRelationInput
    build?: BuildOrderByRelationAggregateInput
    files?: FileOrderByRelationAggregateInput
    projectDomain?: ProjectDomainOrderByRelationAggregateInput
    authorizationToken?: AuthorizationTokenOrderByRelationAggregateInput
    previewImageAsset?: AssetOrderByWithRelationInput
    latestStaticBuild?: LatestStaticBuildPerProjectOrderByWithRelationInput
  }

  export type ProjectWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    domain?: string
    id_isDeleted?: ProjectIdIsDeletedCompoundUniqueInput
    domain_isDeleted?: ProjectDomainIsDeletedCompoundUniqueInput
    id_domain?: ProjectIdDomainCompoundUniqueInput
    AND?: ProjectWhereInput | ProjectWhereInput[]
    OR?: ProjectWhereInput[]
    NOT?: ProjectWhereInput | ProjectWhereInput[]
    createdAt?: DateTimeFilter<"Project"> | Date | string
    title?: StringFilter<"Project"> | string
    userId?: StringNullableFilter<"Project"> | string | null
    isDeleted?: BoolFilter<"Project"> | boolean
    previewImageAssetId?: StringNullableFilter<"Project"> | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"Project"> | $Enums.MarketplaceApprovalStatus
    user?: XOR<UserNullableRelationFilter, UserWhereInput> | null
    build?: BuildListRelationFilter
    files?: FileListRelationFilter
    projectDomain?: ProjectDomainListRelationFilter
    authorizationToken?: AuthorizationTokenListRelationFilter
    previewImageAsset?: XOR<AssetNullableRelationFilter, AssetWhereInput> | null
    latestStaticBuild?: XOR<LatestStaticBuildPerProjectNullableRelationFilter, LatestStaticBuildPerProjectWhereInput> | null
  }, "id" | "domain" | "id_isDeleted" | "domain_isDeleted" | "id_domain">

  export type ProjectOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
    previewImageAssetId?: SortOrderInput | SortOrder
    marketplaceApprovalStatus?: SortOrder
    _count?: ProjectCountOrderByAggregateInput
    _max?: ProjectMaxOrderByAggregateInput
    _min?: ProjectMinOrderByAggregateInput
  }

  export type ProjectScalarWhereWithAggregatesInput = {
    AND?: ProjectScalarWhereWithAggregatesInput | ProjectScalarWhereWithAggregatesInput[]
    OR?: ProjectScalarWhereWithAggregatesInput[]
    NOT?: ProjectScalarWhereWithAggregatesInput | ProjectScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Project"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Project"> | Date | string
    title?: StringWithAggregatesFilter<"Project"> | string
    domain?: StringWithAggregatesFilter<"Project"> | string
    userId?: StringNullableWithAggregatesFilter<"Project"> | string | null
    isDeleted?: BoolWithAggregatesFilter<"Project"> | boolean
    previewImageAssetId?: StringNullableWithAggregatesFilter<"Project"> | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusWithAggregatesFilter<"Project"> | $Enums.MarketplaceApprovalStatus
  }

  export type BuildWhereInput = {
    AND?: BuildWhereInput | BuildWhereInput[]
    OR?: BuildWhereInput[]
    NOT?: BuildWhereInput | BuildWhereInput[]
    id?: StringFilter<"Build"> | string
    version?: IntFilter<"Build"> | number
    lastTransactionId?: StringNullableFilter<"Build"> | string | null
    createdAt?: DateTimeFilter<"Build"> | Date | string
    updatedAt?: DateTimeFilter<"Build"> | Date | string
    pages?: StringFilter<"Build"> | string
    projectId?: StringFilter<"Build"> | string
    breakpoints?: StringFilter<"Build"> | string
    styles?: StringFilter<"Build"> | string
    styleSources?: StringFilter<"Build"> | string
    styleSourceSelections?: StringFilter<"Build"> | string
    props?: StringFilter<"Build"> | string
    dataSources?: StringFilter<"Build"> | string
    resources?: StringFilter<"Build"> | string
    instances?: StringFilter<"Build"> | string
    marketplaceProduct?: StringFilter<"Build"> | string
    deployment?: StringNullableFilter<"Build"> | string | null
    publishStatus?: EnumPublishStatusFilter<"Build"> | $Enums.PublishStatus
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
    latestStaticBuildPerProject?: XOR<LatestStaticBuildPerProjectNullableRelationFilter, LatestStaticBuildPerProjectWhereInput> | null
  }

  export type BuildOrderByWithRelationInput = {
    id?: SortOrder
    version?: SortOrder
    lastTransactionId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    pages?: SortOrder
    projectId?: SortOrder
    breakpoints?: SortOrder
    styles?: SortOrder
    styleSources?: SortOrder
    styleSourceSelections?: SortOrder
    props?: SortOrder
    dataSources?: SortOrder
    resources?: SortOrder
    instances?: SortOrder
    marketplaceProduct?: SortOrder
    deployment?: SortOrderInput | SortOrder
    publishStatus?: SortOrder
    project?: ProjectOrderByWithRelationInput
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectOrderByWithRelationInput
  }

  export type BuildWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    id_projectId?: BuildIdProjectIdCompoundUniqueInput
    AND?: BuildWhereInput | BuildWhereInput[]
    OR?: BuildWhereInput[]
    NOT?: BuildWhereInput | BuildWhereInput[]
    version?: IntFilter<"Build"> | number
    lastTransactionId?: StringNullableFilter<"Build"> | string | null
    createdAt?: DateTimeFilter<"Build"> | Date | string
    updatedAt?: DateTimeFilter<"Build"> | Date | string
    pages?: StringFilter<"Build"> | string
    projectId?: StringFilter<"Build"> | string
    breakpoints?: StringFilter<"Build"> | string
    styles?: StringFilter<"Build"> | string
    styleSources?: StringFilter<"Build"> | string
    styleSourceSelections?: StringFilter<"Build"> | string
    props?: StringFilter<"Build"> | string
    dataSources?: StringFilter<"Build"> | string
    resources?: StringFilter<"Build"> | string
    instances?: StringFilter<"Build"> | string
    marketplaceProduct?: StringFilter<"Build"> | string
    deployment?: StringNullableFilter<"Build"> | string | null
    publishStatus?: EnumPublishStatusFilter<"Build"> | $Enums.PublishStatus
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
    latestStaticBuildPerProject?: XOR<LatestStaticBuildPerProjectNullableRelationFilter, LatestStaticBuildPerProjectWhereInput> | null
  }, "id_projectId" | "id">

  export type BuildOrderByWithAggregationInput = {
    id?: SortOrder
    version?: SortOrder
    lastTransactionId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    pages?: SortOrder
    projectId?: SortOrder
    breakpoints?: SortOrder
    styles?: SortOrder
    styleSources?: SortOrder
    styleSourceSelections?: SortOrder
    props?: SortOrder
    dataSources?: SortOrder
    resources?: SortOrder
    instances?: SortOrder
    marketplaceProduct?: SortOrder
    deployment?: SortOrderInput | SortOrder
    publishStatus?: SortOrder
    _count?: BuildCountOrderByAggregateInput
    _avg?: BuildAvgOrderByAggregateInput
    _max?: BuildMaxOrderByAggregateInput
    _min?: BuildMinOrderByAggregateInput
    _sum?: BuildSumOrderByAggregateInput
  }

  export type BuildScalarWhereWithAggregatesInput = {
    AND?: BuildScalarWhereWithAggregatesInput | BuildScalarWhereWithAggregatesInput[]
    OR?: BuildScalarWhereWithAggregatesInput[]
    NOT?: BuildScalarWhereWithAggregatesInput | BuildScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Build"> | string
    version?: IntWithAggregatesFilter<"Build"> | number
    lastTransactionId?: StringNullableWithAggregatesFilter<"Build"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Build"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Build"> | Date | string
    pages?: StringWithAggregatesFilter<"Build"> | string
    projectId?: StringWithAggregatesFilter<"Build"> | string
    breakpoints?: StringWithAggregatesFilter<"Build"> | string
    styles?: StringWithAggregatesFilter<"Build"> | string
    styleSources?: StringWithAggregatesFilter<"Build"> | string
    styleSourceSelections?: StringWithAggregatesFilter<"Build"> | string
    props?: StringWithAggregatesFilter<"Build"> | string
    dataSources?: StringWithAggregatesFilter<"Build"> | string
    resources?: StringWithAggregatesFilter<"Build"> | string
    instances?: StringWithAggregatesFilter<"Build"> | string
    marketplaceProduct?: StringWithAggregatesFilter<"Build"> | string
    deployment?: StringNullableWithAggregatesFilter<"Build"> | string | null
    publishStatus?: EnumPublishStatusWithAggregatesFilter<"Build"> | $Enums.PublishStatus
  }

  export type AuthorizationTokenWhereInput = {
    AND?: AuthorizationTokenWhereInput | AuthorizationTokenWhereInput[]
    OR?: AuthorizationTokenWhereInput[]
    NOT?: AuthorizationTokenWhereInput | AuthorizationTokenWhereInput[]
    token?: StringFilter<"AuthorizationToken"> | string
    projectId?: StringFilter<"AuthorizationToken"> | string
    name?: StringFilter<"AuthorizationToken"> | string
    relation?: EnumAuthorizationRelationFilter<"AuthorizationToken"> | $Enums.AuthorizationRelation
    createdAt?: DateTimeFilter<"AuthorizationToken"> | Date | string
    canClone?: BoolFilter<"AuthorizationToken"> | boolean
    canCopy?: BoolFilter<"AuthorizationToken"> | boolean
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
  }

  export type AuthorizationTokenOrderByWithRelationInput = {
    token?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    relation?: SortOrder
    createdAt?: SortOrder
    canClone?: SortOrder
    canCopy?: SortOrder
    project?: ProjectOrderByWithRelationInput
  }

  export type AuthorizationTokenWhereUniqueInput = Prisma.AtLeast<{
    token?: string
    token_projectId?: AuthorizationTokenTokenProjectIdCompoundUniqueInput
    AND?: AuthorizationTokenWhereInput | AuthorizationTokenWhereInput[]
    OR?: AuthorizationTokenWhereInput[]
    NOT?: AuthorizationTokenWhereInput | AuthorizationTokenWhereInput[]
    projectId?: StringFilter<"AuthorizationToken"> | string
    name?: StringFilter<"AuthorizationToken"> | string
    relation?: EnumAuthorizationRelationFilter<"AuthorizationToken"> | $Enums.AuthorizationRelation
    createdAt?: DateTimeFilter<"AuthorizationToken"> | Date | string
    canClone?: BoolFilter<"AuthorizationToken"> | boolean
    canCopy?: BoolFilter<"AuthorizationToken"> | boolean
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
  }, "token_projectId" | "token">

  export type AuthorizationTokenOrderByWithAggregationInput = {
    token?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    relation?: SortOrder
    createdAt?: SortOrder
    canClone?: SortOrder
    canCopy?: SortOrder
    _count?: AuthorizationTokenCountOrderByAggregateInput
    _max?: AuthorizationTokenMaxOrderByAggregateInput
    _min?: AuthorizationTokenMinOrderByAggregateInput
  }

  export type AuthorizationTokenScalarWhereWithAggregatesInput = {
    AND?: AuthorizationTokenScalarWhereWithAggregatesInput | AuthorizationTokenScalarWhereWithAggregatesInput[]
    OR?: AuthorizationTokenScalarWhereWithAggregatesInput[]
    NOT?: AuthorizationTokenScalarWhereWithAggregatesInput | AuthorizationTokenScalarWhereWithAggregatesInput[]
    token?: StringWithAggregatesFilter<"AuthorizationToken"> | string
    projectId?: StringWithAggregatesFilter<"AuthorizationToken"> | string
    name?: StringWithAggregatesFilter<"AuthorizationToken"> | string
    relation?: EnumAuthorizationRelationWithAggregatesFilter<"AuthorizationToken"> | $Enums.AuthorizationRelation
    createdAt?: DateTimeWithAggregatesFilter<"AuthorizationToken"> | Date | string
    canClone?: BoolWithAggregatesFilter<"AuthorizationToken"> | boolean
    canCopy?: BoolWithAggregatesFilter<"AuthorizationToken"> | boolean
  }

  export type DomainWhereInput = {
    AND?: DomainWhereInput | DomainWhereInput[]
    OR?: DomainWhereInput[]
    NOT?: DomainWhereInput | DomainWhereInput[]
    id?: StringFilter<"Domain"> | string
    domain?: StringFilter<"Domain"> | string
    createdAt?: DateTimeFilter<"Domain"> | Date | string
    updatedAt?: DateTimeFilter<"Domain"> | Date | string
    txtRecord?: StringNullableFilter<"Domain"> | string | null
    status?: EnumDomainStatusFilter<"Domain"> | $Enums.DomainStatus
    error?: StringNullableFilter<"Domain"> | string | null
    ProjectDomain?: ProjectDomainListRelationFilter
  }

  export type DomainOrderByWithRelationInput = {
    id?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    txtRecord?: SortOrderInput | SortOrder
    status?: SortOrder
    error?: SortOrderInput | SortOrder
    ProjectDomain?: ProjectDomainOrderByRelationAggregateInput
  }

  export type DomainWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    domain?: string
    AND?: DomainWhereInput | DomainWhereInput[]
    OR?: DomainWhereInput[]
    NOT?: DomainWhereInput | DomainWhereInput[]
    createdAt?: DateTimeFilter<"Domain"> | Date | string
    updatedAt?: DateTimeFilter<"Domain"> | Date | string
    txtRecord?: StringNullableFilter<"Domain"> | string | null
    status?: EnumDomainStatusFilter<"Domain"> | $Enums.DomainStatus
    error?: StringNullableFilter<"Domain"> | string | null
    ProjectDomain?: ProjectDomainListRelationFilter
  }, "id" | "domain">

  export type DomainOrderByWithAggregationInput = {
    id?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    txtRecord?: SortOrderInput | SortOrder
    status?: SortOrder
    error?: SortOrderInput | SortOrder
    _count?: DomainCountOrderByAggregateInput
    _max?: DomainMaxOrderByAggregateInput
    _min?: DomainMinOrderByAggregateInput
  }

  export type DomainScalarWhereWithAggregatesInput = {
    AND?: DomainScalarWhereWithAggregatesInput | DomainScalarWhereWithAggregatesInput[]
    OR?: DomainScalarWhereWithAggregatesInput[]
    NOT?: DomainScalarWhereWithAggregatesInput | DomainScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Domain"> | string
    domain?: StringWithAggregatesFilter<"Domain"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Domain"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Domain"> | Date | string
    txtRecord?: StringNullableWithAggregatesFilter<"Domain"> | string | null
    status?: EnumDomainStatusWithAggregatesFilter<"Domain"> | $Enums.DomainStatus
    error?: StringNullableWithAggregatesFilter<"Domain"> | string | null
  }

  export type ProjectDomainWhereInput = {
    AND?: ProjectDomainWhereInput | ProjectDomainWhereInput[]
    OR?: ProjectDomainWhereInput[]
    NOT?: ProjectDomainWhereInput | ProjectDomainWhereInput[]
    projectId?: StringFilter<"ProjectDomain"> | string
    domainId?: StringFilter<"ProjectDomain"> | string
    createdAt?: DateTimeFilter<"ProjectDomain"> | Date | string
    txtRecord?: StringFilter<"ProjectDomain"> | string
    cname?: StringFilter<"ProjectDomain"> | string
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
    domain?: XOR<DomainRelationFilter, DomainWhereInput>
  }

  export type ProjectDomainOrderByWithRelationInput = {
    projectId?: SortOrder
    domainId?: SortOrder
    createdAt?: SortOrder
    txtRecord?: SortOrder
    cname?: SortOrder
    project?: ProjectOrderByWithRelationInput
    domain?: DomainOrderByWithRelationInput
  }

  export type ProjectDomainWhereUniqueInput = Prisma.AtLeast<{
    txtRecord?: string
    projectId_domainId?: ProjectDomainProjectIdDomainIdCompoundUniqueInput
    AND?: ProjectDomainWhereInput | ProjectDomainWhereInput[]
    OR?: ProjectDomainWhereInput[]
    NOT?: ProjectDomainWhereInput | ProjectDomainWhereInput[]
    projectId?: StringFilter<"ProjectDomain"> | string
    domainId?: StringFilter<"ProjectDomain"> | string
    createdAt?: DateTimeFilter<"ProjectDomain"> | Date | string
    cname?: StringFilter<"ProjectDomain"> | string
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
    domain?: XOR<DomainRelationFilter, DomainWhereInput>
  }, "projectId_domainId" | "txtRecord">

  export type ProjectDomainOrderByWithAggregationInput = {
    projectId?: SortOrder
    domainId?: SortOrder
    createdAt?: SortOrder
    txtRecord?: SortOrder
    cname?: SortOrder
    _count?: ProjectDomainCountOrderByAggregateInput
    _max?: ProjectDomainMaxOrderByAggregateInput
    _min?: ProjectDomainMinOrderByAggregateInput
  }

  export type ProjectDomainScalarWhereWithAggregatesInput = {
    AND?: ProjectDomainScalarWhereWithAggregatesInput | ProjectDomainScalarWhereWithAggregatesInput[]
    OR?: ProjectDomainScalarWhereWithAggregatesInput[]
    NOT?: ProjectDomainScalarWhereWithAggregatesInput | ProjectDomainScalarWhereWithAggregatesInput[]
    projectId?: StringWithAggregatesFilter<"ProjectDomain"> | string
    domainId?: StringWithAggregatesFilter<"ProjectDomain"> | string
    createdAt?: DateTimeWithAggregatesFilter<"ProjectDomain"> | Date | string
    txtRecord?: StringWithAggregatesFilter<"ProjectDomain"> | string
    cname?: StringWithAggregatesFilter<"ProjectDomain"> | string
  }

  export type UserProductWhereInput = {
    AND?: UserProductWhereInput | UserProductWhereInput[]
    OR?: UserProductWhereInput[]
    NOT?: UserProductWhereInput | UserProductWhereInput[]
    userId?: StringFilter<"UserProduct"> | string
    productId?: StringFilter<"UserProduct"> | string
    subscriptionId?: StringNullableFilter<"UserProduct"> | string | null
    customerId?: StringNullableFilter<"UserProduct"> | string | null
    customerEmail?: StringNullableFilter<"UserProduct"> | string | null
    user?: XOR<UserRelationFilter, UserWhereInput>
    product?: XOR<ProductRelationFilter, ProductWhereInput>
  }

  export type UserProductOrderByWithRelationInput = {
    userId?: SortOrder
    productId?: SortOrder
    subscriptionId?: SortOrderInput | SortOrder
    customerId?: SortOrderInput | SortOrder
    customerEmail?: SortOrderInput | SortOrder
    user?: UserOrderByWithRelationInput
    product?: ProductOrderByWithRelationInput
  }

  export type UserProductWhereUniqueInput = Prisma.AtLeast<{
    userId_productId?: UserProductUserIdProductIdCompoundUniqueInput
    AND?: UserProductWhereInput | UserProductWhereInput[]
    OR?: UserProductWhereInput[]
    NOT?: UserProductWhereInput | UserProductWhereInput[]
    userId?: StringFilter<"UserProduct"> | string
    productId?: StringFilter<"UserProduct"> | string
    subscriptionId?: StringNullableFilter<"UserProduct"> | string | null
    customerId?: StringNullableFilter<"UserProduct"> | string | null
    customerEmail?: StringNullableFilter<"UserProduct"> | string | null
    user?: XOR<UserRelationFilter, UserWhereInput>
    product?: XOR<ProductRelationFilter, ProductWhereInput>
  }, "userId_productId">

  export type UserProductOrderByWithAggregationInput = {
    userId?: SortOrder
    productId?: SortOrder
    subscriptionId?: SortOrderInput | SortOrder
    customerId?: SortOrderInput | SortOrder
    customerEmail?: SortOrderInput | SortOrder
    _count?: UserProductCountOrderByAggregateInput
    _max?: UserProductMaxOrderByAggregateInput
    _min?: UserProductMinOrderByAggregateInput
  }

  export type UserProductScalarWhereWithAggregatesInput = {
    AND?: UserProductScalarWhereWithAggregatesInput | UserProductScalarWhereWithAggregatesInput[]
    OR?: UserProductScalarWhereWithAggregatesInput[]
    NOT?: UserProductScalarWhereWithAggregatesInput | UserProductScalarWhereWithAggregatesInput[]
    userId?: StringWithAggregatesFilter<"UserProduct"> | string
    productId?: StringWithAggregatesFilter<"UserProduct"> | string
    subscriptionId?: StringNullableWithAggregatesFilter<"UserProduct"> | string | null
    customerId?: StringNullableWithAggregatesFilter<"UserProduct"> | string | null
    customerEmail?: StringNullableWithAggregatesFilter<"UserProduct"> | string | null
  }

  export type LatestStaticBuildPerProjectWhereInput = {
    AND?: LatestStaticBuildPerProjectWhereInput | LatestStaticBuildPerProjectWhereInput[]
    OR?: LatestStaticBuildPerProjectWhereInput[]
    NOT?: LatestStaticBuildPerProjectWhereInput | LatestStaticBuildPerProjectWhereInput[]
    buildId?: StringFilter<"LatestStaticBuildPerProject"> | string
    projectId?: StringFilter<"LatestStaticBuildPerProject"> | string
    publishStatus?: EnumPublishStatusFilter<"LatestStaticBuildPerProject"> | $Enums.PublishStatus
    updatedAt?: DateTimeFilter<"LatestStaticBuildPerProject"> | Date | string
    build?: XOR<BuildRelationFilter, BuildWhereInput>
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
  }

  export type LatestStaticBuildPerProjectOrderByWithRelationInput = {
    buildId?: SortOrder
    projectId?: SortOrder
    publishStatus?: SortOrder
    updatedAt?: SortOrder
    build?: BuildOrderByWithRelationInput
    project?: ProjectOrderByWithRelationInput
  }

  export type LatestStaticBuildPerProjectWhereUniqueInput = Prisma.AtLeast<{
    projectId?: string
    buildId_projectId?: LatestStaticBuildPerProjectBuildIdProjectIdCompoundUniqueInput
    AND?: LatestStaticBuildPerProjectWhereInput | LatestStaticBuildPerProjectWhereInput[]
    OR?: LatestStaticBuildPerProjectWhereInput[]
    NOT?: LatestStaticBuildPerProjectWhereInput | LatestStaticBuildPerProjectWhereInput[]
    buildId?: StringFilter<"LatestStaticBuildPerProject"> | string
    publishStatus?: EnumPublishStatusFilter<"LatestStaticBuildPerProject"> | $Enums.PublishStatus
    updatedAt?: DateTimeFilter<"LatestStaticBuildPerProject"> | Date | string
    build?: XOR<BuildRelationFilter, BuildWhereInput>
    project?: XOR<ProjectRelationFilter, ProjectWhereInput>
  }, "projectId" | "buildId_projectId">

  export type LatestStaticBuildPerProjectOrderByWithAggregationInput = {
    buildId?: SortOrder
    projectId?: SortOrder
    publishStatus?: SortOrder
    updatedAt?: SortOrder
    _count?: LatestStaticBuildPerProjectCountOrderByAggregateInput
    _max?: LatestStaticBuildPerProjectMaxOrderByAggregateInput
    _min?: LatestStaticBuildPerProjectMinOrderByAggregateInput
  }

  export type LatestStaticBuildPerProjectScalarWhereWithAggregatesInput = {
    AND?: LatestStaticBuildPerProjectScalarWhereWithAggregatesInput | LatestStaticBuildPerProjectScalarWhereWithAggregatesInput[]
    OR?: LatestStaticBuildPerProjectScalarWhereWithAggregatesInput[]
    NOT?: LatestStaticBuildPerProjectScalarWhereWithAggregatesInput | LatestStaticBuildPerProjectScalarWhereWithAggregatesInput[]
    buildId?: StringWithAggregatesFilter<"LatestStaticBuildPerProject"> | string
    projectId?: StringWithAggregatesFilter<"LatestStaticBuildPerProject"> | string
    publishStatus?: EnumPublishStatusWithAggregatesFilter<"LatestStaticBuildPerProject"> | $Enums.PublishStatus
    updatedAt?: DateTimeWithAggregatesFilter<"LatestStaticBuildPerProject"> | Date | string
  }

  export type DashboardProjectWhereInput = {
    AND?: DashboardProjectWhereInput | DashboardProjectWhereInput[]
    OR?: DashboardProjectWhereInput[]
    NOT?: DashboardProjectWhereInput | DashboardProjectWhereInput[]
    id?: StringFilter<"DashboardProject"> | string
    createdAt?: DateTimeFilter<"DashboardProject"> | Date | string
    title?: StringFilter<"DashboardProject"> | string
    domain?: StringFilter<"DashboardProject"> | string
    userId?: StringNullableFilter<"DashboardProject"> | string | null
    previewImageAssetId?: StringNullableFilter<"DashboardProject"> | string | null
    isDeleted?: BoolFilter<"DashboardProject"> | boolean
    isPublished?: BoolFilter<"DashboardProject"> | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"DashboardProject"> | $Enums.MarketplaceApprovalStatus
    previewImageAsset?: XOR<AssetNullableRelationFilter, AssetWhereInput> | null
  }

  export type DashboardProjectOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrderInput | SortOrder
    previewImageAssetId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
    isPublished?: SortOrder
    marketplaceApprovalStatus?: SortOrder
    previewImageAsset?: AssetOrderByWithRelationInput
  }

  export type DashboardProjectWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: DashboardProjectWhereInput | DashboardProjectWhereInput[]
    OR?: DashboardProjectWhereInput[]
    NOT?: DashboardProjectWhereInput | DashboardProjectWhereInput[]
    createdAt?: DateTimeFilter<"DashboardProject"> | Date | string
    title?: StringFilter<"DashboardProject"> | string
    domain?: StringFilter<"DashboardProject"> | string
    userId?: StringNullableFilter<"DashboardProject"> | string | null
    previewImageAssetId?: StringNullableFilter<"DashboardProject"> | string | null
    isDeleted?: BoolFilter<"DashboardProject"> | boolean
    isPublished?: BoolFilter<"DashboardProject"> | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"DashboardProject"> | $Enums.MarketplaceApprovalStatus
    previewImageAsset?: XOR<AssetNullableRelationFilter, AssetWhereInput> | null
  }, "id">

  export type DashboardProjectOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrderInput | SortOrder
    previewImageAssetId?: SortOrderInput | SortOrder
    isDeleted?: SortOrder
    isPublished?: SortOrder
    marketplaceApprovalStatus?: SortOrder
    _count?: DashboardProjectCountOrderByAggregateInput
    _max?: DashboardProjectMaxOrderByAggregateInput
    _min?: DashboardProjectMinOrderByAggregateInput
  }

  export type DashboardProjectScalarWhereWithAggregatesInput = {
    AND?: DashboardProjectScalarWhereWithAggregatesInput | DashboardProjectScalarWhereWithAggregatesInput[]
    OR?: DashboardProjectScalarWhereWithAggregatesInput[]
    NOT?: DashboardProjectScalarWhereWithAggregatesInput | DashboardProjectScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"DashboardProject"> | string
    createdAt?: DateTimeWithAggregatesFilter<"DashboardProject"> | Date | string
    title?: StringWithAggregatesFilter<"DashboardProject"> | string
    domain?: StringWithAggregatesFilter<"DashboardProject"> | string
    userId?: StringNullableWithAggregatesFilter<"DashboardProject"> | string | null
    previewImageAssetId?: StringNullableWithAggregatesFilter<"DashboardProject"> | string | null
    isDeleted?: BoolWithAggregatesFilter<"DashboardProject"> | boolean
    isPublished?: BoolWithAggregatesFilter<"DashboardProject"> | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusWithAggregatesFilter<"DashboardProject"> | $Enums.MarketplaceApprovalStatus
  }

  export type ApprovedMarketplaceProductWhereInput = {
    AND?: ApprovedMarketplaceProductWhereInput | ApprovedMarketplaceProductWhereInput[]
    OR?: ApprovedMarketplaceProductWhereInput[]
    NOT?: ApprovedMarketplaceProductWhereInput | ApprovedMarketplaceProductWhereInput[]
    projectId?: StringFilter<"ApprovedMarketplaceProduct"> | string
    marketplaceProduct?: StringFilter<"ApprovedMarketplaceProduct"> | string
    authorizationToken?: StringNullableFilter<"ApprovedMarketplaceProduct"> | string | null
  }

  export type ApprovedMarketplaceProductOrderByWithRelationInput = {
    projectId?: SortOrder
    marketplaceProduct?: SortOrder
    authorizationToken?: SortOrderInput | SortOrder
  }

  export type ApprovedMarketplaceProductWhereUniqueInput = Prisma.AtLeast<{
    projectId?: string
    AND?: ApprovedMarketplaceProductWhereInput | ApprovedMarketplaceProductWhereInput[]
    OR?: ApprovedMarketplaceProductWhereInput[]
    NOT?: ApprovedMarketplaceProductWhereInput | ApprovedMarketplaceProductWhereInput[]
    marketplaceProduct?: StringFilter<"ApprovedMarketplaceProduct"> | string
    authorizationToken?: StringNullableFilter<"ApprovedMarketplaceProduct"> | string | null
  }, "projectId">

  export type ApprovedMarketplaceProductOrderByWithAggregationInput = {
    projectId?: SortOrder
    marketplaceProduct?: SortOrder
    authorizationToken?: SortOrderInput | SortOrder
    _count?: ApprovedMarketplaceProductCountOrderByAggregateInput
    _max?: ApprovedMarketplaceProductMaxOrderByAggregateInput
    _min?: ApprovedMarketplaceProductMinOrderByAggregateInput
  }

  export type ApprovedMarketplaceProductScalarWhereWithAggregatesInput = {
    AND?: ApprovedMarketplaceProductScalarWhereWithAggregatesInput | ApprovedMarketplaceProductScalarWhereWithAggregatesInput[]
    OR?: ApprovedMarketplaceProductScalarWhereWithAggregatesInput[]
    NOT?: ApprovedMarketplaceProductScalarWhereWithAggregatesInput | ApprovedMarketplaceProductScalarWhereWithAggregatesInput[]
    projectId?: StringWithAggregatesFilter<"ApprovedMarketplaceProduct"> | string
    marketplaceProduct?: StringWithAggregatesFilter<"ApprovedMarketplaceProduct"> | string
    authorizationToken?: StringNullableWithAggregatesFilter<"ApprovedMarketplaceProduct"> | string | null
  }

  export type TeamCreateInput = {
    id?: string
    users?: UserCreateNestedManyWithoutTeamInput
  }

  export type TeamUncheckedCreateInput = {
    id?: string
    users?: UserUncheckedCreateNestedManyWithoutTeamInput
  }

  export type TeamUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    users?: UserUpdateManyWithoutTeamNestedInput
  }

  export type TeamUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    users?: UserUncheckedUpdateManyWithoutTeamNestedInput
  }

  export type TeamCreateManyInput = {
    id?: string
  }

  export type TeamUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type TeamUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type FileCreateInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    uploaderProject?: ProjectCreateNestedOneWithoutFilesInput
    assets?: AssetCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    uploaderProjectId?: string | null
    assets?: AssetUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    uploaderProject?: ProjectUpdateOneWithoutFilesNestedInput
    assets?: AssetUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    uploaderProjectId?: NullableStringFieldUpdateOperationsInput | string | null
    assets?: AssetUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileCreateManyInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    uploaderProjectId?: string | null
  }

  export type FileUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type FileUncheckedUpdateManyInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    uploaderProjectId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AssetCreateInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
    file: FileCreateNestedOneWithoutAssetsInput
    Project?: ProjectCreateNestedManyWithoutPreviewImageAssetInput
    DashboardProject?: DashboardProjectCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetUncheckedCreateInput = {
    id?: string
    projectId: string
    name: string
    filename?: string | null
    description?: string | null
    Project?: ProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
    DashboardProject?: DashboardProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    file?: FileUpdateOneRequiredWithoutAssetsNestedInput
    Project?: ProjectUpdateManyWithoutPreviewImageAssetNestedInput
    DashboardProject?: DashboardProjectUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    Project?: ProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
    DashboardProject?: DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetCreateManyInput = {
    id?: string
    projectId: string
    name: string
    filename?: string | null
    description?: string | null
  }

  export type AssetUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AssetUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserCreateInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    team?: TeamCreateNestedOneWithoutUsersInput
    projects?: ProjectCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesCreateNestedManyWithoutUserInput
    checkout?: TransactionLogCreateNestedManyWithoutUserInput
    products?: UserProductCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
    projects?: ProjectUncheckedCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesUncheckedCreateNestedManyWithoutUserInput
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutUserInput
    products?: UserProductUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    team?: TeamUpdateOneWithoutUsersNestedInput
    projects?: ProjectUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUpdateManyWithoutUserNestedInput
    products?: UserProductUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
    projects?: ProjectUncheckedUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUncheckedUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUncheckedUpdateManyWithoutUserNestedInput
    products?: UserProductUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ClientReferencesCreateInput = {
    reference?: string
    service: string
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutClientReferencesInput
  }

  export type ClientReferencesUncheckedCreateInput = {
    reference?: string
    service: string
    createdAt?: Date | string
    userId: string
  }

  export type ClientReferencesUpdateInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutClientReferencesNestedInput
  }

  export type ClientReferencesUncheckedUpdateInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type ClientReferencesCreateManyInput = {
    reference?: string
    service: string
    createdAt?: Date | string
    userId: string
  }

  export type ClientReferencesUpdateManyMutationInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClientReferencesUncheckedUpdateManyInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type ProductCreateInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    checkout?: TransactionLogCreateNestedManyWithoutProductInput
    userProducts?: UserProductCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutProductInput
    userProducts?: UserProductUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    checkout?: TransactionLogUpdateManyWithoutProductNestedInput
    userProducts?: UserProductUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    checkout?: TransactionLogUncheckedUpdateManyWithoutProductNestedInput
    userProducts?: UserProductUncheckedUpdateManyWithoutProductNestedInput
  }

  export type ProductCreateManyInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
  }

  export type ProductUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionLogCreateInput = {
    eventId: string
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
    user?: UserCreateNestedOneWithoutCheckoutInput
    product?: ProductCreateNestedOneWithoutCheckoutInput
  }

  export type TransactionLogUncheckedCreateInput = {
    eventId: string
    userId?: string | null
    productId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type TransactionLogUpdateInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneWithoutCheckoutNestedInput
    product?: ProductUpdateOneWithoutCheckoutNestedInput
  }

  export type TransactionLogUncheckedUpdateInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type TransactionLogCreateManyInput = {
    eventId: string
    userId?: string | null
    productId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type TransactionLogUpdateManyMutationInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type TransactionLogUncheckedUpdateManyInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ProjectCreateInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectUpdateInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type ProjectCreateManyInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type ProjectUpdateManyMutationInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type ProjectUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type BuildCreateInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
    project: ProjectCreateNestedOneWithoutBuildInput
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectCreateNestedOneWithoutBuildInput
  }

  export type BuildUncheckedCreateInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    projectId: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutBuildInput
  }

  export type BuildUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    project?: ProjectUpdateOneRequiredWithoutBuildNestedInput
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUpdateOneWithoutBuildNestedInput
  }

  export type BuildUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutBuildNestedInput
  }

  export type BuildCreateManyInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    projectId: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
  }

  export type BuildUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
  }

  export type BuildUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
  }

  export type AuthorizationTokenCreateInput = {
    token?: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
    project: ProjectCreateNestedOneWithoutAuthorizationTokenInput
  }

  export type AuthorizationTokenUncheckedCreateInput = {
    token?: string
    projectId: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
  }

  export type AuthorizationTokenUpdateInput = {
    token?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
    project?: ProjectUpdateOneRequiredWithoutAuthorizationTokenNestedInput
  }

  export type AuthorizationTokenUncheckedUpdateInput = {
    token?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AuthorizationTokenCreateManyInput = {
    token?: string
    projectId: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
  }

  export type AuthorizationTokenUpdateManyMutationInput = {
    token?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AuthorizationTokenUncheckedUpdateManyInput = {
    token?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type DomainCreateInput = {
    id?: string
    domain: string
    createdAt?: Date | string
    updatedAt?: Date | string
    txtRecord?: string | null
    status?: $Enums.DomainStatus
    error?: string | null
    ProjectDomain?: ProjectDomainCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateInput = {
    id?: string
    domain: string
    createdAt?: Date | string
    updatedAt?: Date | string
    txtRecord?: string | null
    status?: $Enums.DomainStatus
    error?: string | null
    ProjectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
    ProjectDomain?: ProjectDomainUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
    ProjectDomain?: ProjectDomainUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type DomainCreateManyInput = {
    id?: string
    domain: string
    createdAt?: Date | string
    updatedAt?: Date | string
    txtRecord?: string | null
    status?: $Enums.DomainStatus
    error?: string | null
  }

  export type DomainUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ProjectDomainCreateInput = {
    createdAt?: Date | string
    txtRecord?: string
    cname: string
    project: ProjectCreateNestedOneWithoutProjectDomainInput
    domain: DomainCreateNestedOneWithoutProjectDomainInput
  }

  export type ProjectDomainUncheckedCreateInput = {
    projectId: string
    domainId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type ProjectDomainUpdateInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
    project?: ProjectUpdateOneRequiredWithoutProjectDomainNestedInput
    domain?: DomainUpdateOneRequiredWithoutProjectDomainNestedInput
  }

  export type ProjectDomainUncheckedUpdateInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    domainId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type ProjectDomainCreateManyInput = {
    projectId: string
    domainId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type ProjectDomainUpdateManyMutationInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type ProjectDomainUncheckedUpdateManyInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    domainId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type UserProductCreateInput = {
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
    user: UserCreateNestedOneWithoutProductsInput
    product: ProductCreateNestedOneWithoutUserProductsInput
  }

  export type UserProductUncheckedCreateInput = {
    userId: string
    productId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type UserProductUpdateInput = {
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneRequiredWithoutProductsNestedInput
    product?: ProductUpdateOneRequiredWithoutUserProductsNestedInput
  }

  export type UserProductUncheckedUpdateInput = {
    userId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductCreateManyInput = {
    userId: string
    productId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type UserProductUpdateManyMutationInput = {
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductUncheckedUpdateManyInput = {
    userId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type LatestStaticBuildPerProjectCreateInput = {
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
    build: BuildCreateNestedOneWithoutLatestStaticBuildPerProjectInput
    project: ProjectCreateNestedOneWithoutLatestStaticBuildInput
  }

  export type LatestStaticBuildPerProjectUncheckedCreateInput = {
    buildId: string
    projectId: string
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
  }

  export type LatestStaticBuildPerProjectUpdateInput = {
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    build?: BuildUpdateOneRequiredWithoutLatestStaticBuildPerProjectNestedInput
    project?: ProjectUpdateOneRequiredWithoutLatestStaticBuildNestedInput
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateInput = {
    buildId?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LatestStaticBuildPerProjectCreateManyInput = {
    buildId: string
    projectId: string
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
  }

  export type LatestStaticBuildPerProjectUpdateManyMutationInput = {
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateManyInput = {
    buildId?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DashboardProjectCreateInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    previewImageAsset?: AssetCreateNestedOneWithoutDashboardProjectInput
  }

  export type DashboardProjectUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    previewImageAssetId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUpdateInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    previewImageAsset?: AssetUpdateOneWithoutDashboardProjectNestedInput
  }

  export type DashboardProjectUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectCreateManyInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    previewImageAssetId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUpdateManyMutationInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type ApprovedMarketplaceProductCreateInput = {
    projectId: string
    marketplaceProduct: string
    authorizationToken?: string | null
  }

  export type ApprovedMarketplaceProductUncheckedCreateInput = {
    projectId: string
    marketplaceProduct: string
    authorizationToken?: string | null
  }

  export type ApprovedMarketplaceProductUpdateInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    authorizationToken?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ApprovedMarketplaceProductUncheckedUpdateInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    authorizationToken?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ApprovedMarketplaceProductCreateManyInput = {
    projectId: string
    marketplaceProduct: string
    authorizationToken?: string | null
  }

  export type ApprovedMarketplaceProductUpdateManyMutationInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    authorizationToken?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ApprovedMarketplaceProductUncheckedUpdateManyInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    authorizationToken?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type UserListRelationFilter = {
    every?: UserWhereInput
    some?: UserWhereInput
    none?: UserWhereInput
  }

  export type UserOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TeamCountOrderByAggregateInput = {
    id?: SortOrder
  }

  export type TeamMaxOrderByAggregateInput = {
    id?: SortOrder
  }

  export type TeamMinOrderByAggregateInput = {
    id?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EnumUploadStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.UploadStatus | EnumUploadStatusFieldRefInput<$PrismaModel>
    in?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumUploadStatusFilter<$PrismaModel> | $Enums.UploadStatus
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type ProjectNullableRelationFilter = {
    is?: ProjectWhereInput | null
    isNot?: ProjectWhereInput | null
  }

  export type AssetListRelationFilter = {
    every?: AssetWhereInput
    some?: AssetWhereInput
    none?: AssetWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type AssetOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type FileCountOrderByAggregateInput = {
    name?: SortOrder
    format?: SortOrder
    size?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meta?: SortOrder
    status?: SortOrder
    isDeleted?: SortOrder
    uploaderProjectId?: SortOrder
  }

  export type FileAvgOrderByAggregateInput = {
    size?: SortOrder
  }

  export type FileMaxOrderByAggregateInput = {
    name?: SortOrder
    format?: SortOrder
    size?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meta?: SortOrder
    status?: SortOrder
    isDeleted?: SortOrder
    uploaderProjectId?: SortOrder
  }

  export type FileMinOrderByAggregateInput = {
    name?: SortOrder
    format?: SortOrder
    size?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meta?: SortOrder
    status?: SortOrder
    isDeleted?: SortOrder
    uploaderProjectId?: SortOrder
  }

  export type FileSumOrderByAggregateInput = {
    size?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EnumUploadStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UploadStatus | EnumUploadStatusFieldRefInput<$PrismaModel>
    in?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumUploadStatusWithAggregatesFilter<$PrismaModel> | $Enums.UploadStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUploadStatusFilter<$PrismaModel>
    _max?: NestedEnumUploadStatusFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type FileRelationFilter = {
    is?: FileWhereInput
    isNot?: FileWhereInput
  }

  export type ProjectListRelationFilter = {
    every?: ProjectWhereInput
    some?: ProjectWhereInput
    none?: ProjectWhereInput
  }

  export type DashboardProjectListRelationFilter = {
    every?: DashboardProjectWhereInput
    some?: DashboardProjectWhereInput
    none?: DashboardProjectWhereInput
  }

  export type ProjectOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type DashboardProjectOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type AssetIdProjectIdCompoundUniqueInput = {
    id: string
    projectId: string
  }

  export type AssetCountOrderByAggregateInput = {
    id?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    filename?: SortOrder
    description?: SortOrder
  }

  export type AssetMaxOrderByAggregateInput = {
    id?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    filename?: SortOrder
    description?: SortOrder
  }

  export type AssetMinOrderByAggregateInput = {
    id?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    filename?: SortOrder
    description?: SortOrder
  }

  export type TeamNullableRelationFilter = {
    is?: TeamWhereInput | null
    isNot?: TeamWhereInput | null
  }

  export type ClientReferencesListRelationFilter = {
    every?: ClientReferencesWhereInput
    some?: ClientReferencesWhereInput
    none?: ClientReferencesWhereInput
  }

  export type TransactionLogListRelationFilter = {
    every?: TransactionLogWhereInput
    some?: TransactionLogWhereInput
    none?: TransactionLogWhereInput
  }

  export type UserProductListRelationFilter = {
    every?: UserProductWhereInput
    some?: UserProductWhereInput
    none?: UserProductWhereInput
  }

  export type ClientReferencesOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TransactionLogOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserProductOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    provider?: SortOrder
    image?: SortOrder
    username?: SortOrder
    createdAt?: SortOrder
    teamId?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    provider?: SortOrder
    image?: SortOrder
    username?: SortOrder
    createdAt?: SortOrder
    teamId?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    provider?: SortOrder
    image?: SortOrder
    username?: SortOrder
    createdAt?: SortOrder
    teamId?: SortOrder
  }

  export type UserRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type ClientReferencesReferenceServiceCompoundUniqueInput = {
    reference: string
    service: string
  }

  export type ClientReferencesUserIdServiceCompoundUniqueInput = {
    userId: string
    service: string
  }

  export type ClientReferencesCountOrderByAggregateInput = {
    reference?: SortOrder
    service?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
  }

  export type ClientReferencesMaxOrderByAggregateInput = {
    reference?: SortOrder
    service?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
  }

  export type ClientReferencesMinOrderByAggregateInput = {
    reference?: SortOrder
    service?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
  }

  export type StringNullableListFilter<$PrismaModel = never> = {
    equals?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    has?: string | StringFieldRefInput<$PrismaModel> | null
    hasEvery?: string[] | ListStringFieldRefInput<$PrismaModel>
    hasSome?: string[] | ListStringFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }
  export type JsonFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<JsonFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase<$PrismaModel>>, 'path'>>

  export type JsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type ProductCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    features?: SortOrder
    images?: SortOrder
    meta?: SortOrder
    createdAt?: SortOrder
  }

  export type ProductMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
  }

  export type ProductMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
  }
  export type JsonWithAggregatesFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedJsonFilter<$PrismaModel>
    _max?: NestedJsonFilter<$PrismaModel>
  }
  export type JsonNullableFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type UserNullableRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type ProductNullableRelationFilter = {
    is?: ProductWhereInput | null
    isNot?: ProductWhereInput | null
  }

  export type TransactionLogEventIdProductIdCompoundUniqueInput = {
    eventId: string
    productId: string
  }

  export type TransactionLogCountOrderByAggregateInput = {
    eventId?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    eventData?: SortOrder
    eventType?: SortOrder
    eventCreated?: SortOrder
    status?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
    subscriptionId?: SortOrder
    paymentIntent?: SortOrder
  }

  export type TransactionLogAvgOrderByAggregateInput = {
    eventCreated?: SortOrder
  }

  export type TransactionLogMaxOrderByAggregateInput = {
    eventId?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    eventType?: SortOrder
    eventCreated?: SortOrder
    status?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
    subscriptionId?: SortOrder
    paymentIntent?: SortOrder
  }

  export type TransactionLogMinOrderByAggregateInput = {
    eventId?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    eventType?: SortOrder
    eventCreated?: SortOrder
    status?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
    subscriptionId?: SortOrder
    paymentIntent?: SortOrder
  }

  export type TransactionLogSumOrderByAggregateInput = {
    eventCreated?: SortOrder
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type EnumMarketplaceApprovalStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketplaceApprovalStatus | EnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel> | $Enums.MarketplaceApprovalStatus
  }

  export type BuildListRelationFilter = {
    every?: BuildWhereInput
    some?: BuildWhereInput
    none?: BuildWhereInput
  }

  export type FileListRelationFilter = {
    every?: FileWhereInput
    some?: FileWhereInput
    none?: FileWhereInput
  }

  export type ProjectDomainListRelationFilter = {
    every?: ProjectDomainWhereInput
    some?: ProjectDomainWhereInput
    none?: ProjectDomainWhereInput
  }

  export type AuthorizationTokenListRelationFilter = {
    every?: AuthorizationTokenWhereInput
    some?: AuthorizationTokenWhereInput
    none?: AuthorizationTokenWhereInput
  }

  export type AssetNullableRelationFilter = {
    is?: AssetWhereInput | null
    isNot?: AssetWhereInput | null
  }

  export type LatestStaticBuildPerProjectNullableRelationFilter = {
    is?: LatestStaticBuildPerProjectWhereInput | null
    isNot?: LatestStaticBuildPerProjectWhereInput | null
  }

  export type BuildOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type FileOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ProjectDomainOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type AuthorizationTokenOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ProjectIdIsDeletedCompoundUniqueInput = {
    id: string
    isDeleted: boolean
  }

  export type ProjectDomainIsDeletedCompoundUniqueInput = {
    domain: string
    isDeleted: boolean
  }

  export type ProjectIdDomainCompoundUniqueInput = {
    id: string
    domain: string
  }

  export type ProjectCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    isDeleted?: SortOrder
    previewImageAssetId?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type ProjectMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    isDeleted?: SortOrder
    previewImageAssetId?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type ProjectMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    isDeleted?: SortOrder
    previewImageAssetId?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type EnumMarketplaceApprovalStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketplaceApprovalStatus | EnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketplaceApprovalStatusWithAggregatesFilter<$PrismaModel> | $Enums.MarketplaceApprovalStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel>
    _max?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel>
  }

  export type EnumPublishStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PublishStatus | EnumPublishStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPublishStatusFilter<$PrismaModel> | $Enums.PublishStatus
  }

  export type ProjectRelationFilter = {
    is?: ProjectWhereInput
    isNot?: ProjectWhereInput
  }

  export type BuildIdProjectIdCompoundUniqueInput = {
    id: string
    projectId: string
  }

  export type BuildCountOrderByAggregateInput = {
    id?: SortOrder
    version?: SortOrder
    lastTransactionId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    pages?: SortOrder
    projectId?: SortOrder
    breakpoints?: SortOrder
    styles?: SortOrder
    styleSources?: SortOrder
    styleSourceSelections?: SortOrder
    props?: SortOrder
    dataSources?: SortOrder
    resources?: SortOrder
    instances?: SortOrder
    marketplaceProduct?: SortOrder
    deployment?: SortOrder
    publishStatus?: SortOrder
  }

  export type BuildAvgOrderByAggregateInput = {
    version?: SortOrder
  }

  export type BuildMaxOrderByAggregateInput = {
    id?: SortOrder
    version?: SortOrder
    lastTransactionId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    pages?: SortOrder
    projectId?: SortOrder
    breakpoints?: SortOrder
    styles?: SortOrder
    styleSources?: SortOrder
    styleSourceSelections?: SortOrder
    props?: SortOrder
    dataSources?: SortOrder
    resources?: SortOrder
    instances?: SortOrder
    marketplaceProduct?: SortOrder
    deployment?: SortOrder
    publishStatus?: SortOrder
  }

  export type BuildMinOrderByAggregateInput = {
    id?: SortOrder
    version?: SortOrder
    lastTransactionId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    pages?: SortOrder
    projectId?: SortOrder
    breakpoints?: SortOrder
    styles?: SortOrder
    styleSources?: SortOrder
    styleSourceSelections?: SortOrder
    props?: SortOrder
    dataSources?: SortOrder
    resources?: SortOrder
    instances?: SortOrder
    marketplaceProduct?: SortOrder
    deployment?: SortOrder
    publishStatus?: SortOrder
  }

  export type BuildSumOrderByAggregateInput = {
    version?: SortOrder
  }

  export type EnumPublishStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PublishStatus | EnumPublishStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPublishStatusWithAggregatesFilter<$PrismaModel> | $Enums.PublishStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPublishStatusFilter<$PrismaModel>
    _max?: NestedEnumPublishStatusFilter<$PrismaModel>
  }

  export type EnumAuthorizationRelationFilter<$PrismaModel = never> = {
    equals?: $Enums.AuthorizationRelation | EnumAuthorizationRelationFieldRefInput<$PrismaModel>
    in?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    notIn?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    not?: NestedEnumAuthorizationRelationFilter<$PrismaModel> | $Enums.AuthorizationRelation
  }

  export type AuthorizationTokenTokenProjectIdCompoundUniqueInput = {
    token: string
    projectId: string
  }

  export type AuthorizationTokenCountOrderByAggregateInput = {
    token?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    relation?: SortOrder
    createdAt?: SortOrder
    canClone?: SortOrder
    canCopy?: SortOrder
  }

  export type AuthorizationTokenMaxOrderByAggregateInput = {
    token?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    relation?: SortOrder
    createdAt?: SortOrder
    canClone?: SortOrder
    canCopy?: SortOrder
  }

  export type AuthorizationTokenMinOrderByAggregateInput = {
    token?: SortOrder
    projectId?: SortOrder
    name?: SortOrder
    relation?: SortOrder
    createdAt?: SortOrder
    canClone?: SortOrder
    canCopy?: SortOrder
  }

  export type EnumAuthorizationRelationWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.AuthorizationRelation | EnumAuthorizationRelationFieldRefInput<$PrismaModel>
    in?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    notIn?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    not?: NestedEnumAuthorizationRelationWithAggregatesFilter<$PrismaModel> | $Enums.AuthorizationRelation
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumAuthorizationRelationFilter<$PrismaModel>
    _max?: NestedEnumAuthorizationRelationFilter<$PrismaModel>
  }

  export type EnumDomainStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumDomainStatusFilter<$PrismaModel> | $Enums.DomainStatus
  }

  export type DomainCountOrderByAggregateInput = {
    id?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    txtRecord?: SortOrder
    status?: SortOrder
    error?: SortOrder
  }

  export type DomainMaxOrderByAggregateInput = {
    id?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    txtRecord?: SortOrder
    status?: SortOrder
    error?: SortOrder
  }

  export type DomainMinOrderByAggregateInput = {
    id?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    txtRecord?: SortOrder
    status?: SortOrder
    error?: SortOrder
  }

  export type EnumDomainStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel> | $Enums.DomainStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDomainStatusFilter<$PrismaModel>
    _max?: NestedEnumDomainStatusFilter<$PrismaModel>
  }

  export type DomainRelationFilter = {
    is?: DomainWhereInput
    isNot?: DomainWhereInput
  }

  export type ProjectDomainProjectIdDomainIdCompoundUniqueInput = {
    projectId: string
    domainId: string
  }

  export type ProjectDomainCountOrderByAggregateInput = {
    projectId?: SortOrder
    domainId?: SortOrder
    createdAt?: SortOrder
    txtRecord?: SortOrder
    cname?: SortOrder
  }

  export type ProjectDomainMaxOrderByAggregateInput = {
    projectId?: SortOrder
    domainId?: SortOrder
    createdAt?: SortOrder
    txtRecord?: SortOrder
    cname?: SortOrder
  }

  export type ProjectDomainMinOrderByAggregateInput = {
    projectId?: SortOrder
    domainId?: SortOrder
    createdAt?: SortOrder
    txtRecord?: SortOrder
    cname?: SortOrder
  }

  export type ProductRelationFilter = {
    is?: ProductWhereInput
    isNot?: ProductWhereInput
  }

  export type UserProductUserIdProductIdCompoundUniqueInput = {
    userId: string
    productId: string
  }

  export type UserProductCountOrderByAggregateInput = {
    userId?: SortOrder
    productId?: SortOrder
    subscriptionId?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
  }

  export type UserProductMaxOrderByAggregateInput = {
    userId?: SortOrder
    productId?: SortOrder
    subscriptionId?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
  }

  export type UserProductMinOrderByAggregateInput = {
    userId?: SortOrder
    productId?: SortOrder
    subscriptionId?: SortOrder
    customerId?: SortOrder
    customerEmail?: SortOrder
  }

  export type BuildRelationFilter = {
    is?: BuildWhereInput
    isNot?: BuildWhereInput
  }

  export type LatestStaticBuildPerProjectBuildIdProjectIdCompoundUniqueInput = {
    buildId: string
    projectId: string
  }

  export type LatestStaticBuildPerProjectCountOrderByAggregateInput = {
    buildId?: SortOrder
    projectId?: SortOrder
    publishStatus?: SortOrder
    updatedAt?: SortOrder
  }

  export type LatestStaticBuildPerProjectMaxOrderByAggregateInput = {
    buildId?: SortOrder
    projectId?: SortOrder
    publishStatus?: SortOrder
    updatedAt?: SortOrder
  }

  export type LatestStaticBuildPerProjectMinOrderByAggregateInput = {
    buildId?: SortOrder
    projectId?: SortOrder
    publishStatus?: SortOrder
    updatedAt?: SortOrder
  }

  export type DashboardProjectCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    previewImageAssetId?: SortOrder
    isDeleted?: SortOrder
    isPublished?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type DashboardProjectMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    previewImageAssetId?: SortOrder
    isDeleted?: SortOrder
    isPublished?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type DashboardProjectMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    title?: SortOrder
    domain?: SortOrder
    userId?: SortOrder
    previewImageAssetId?: SortOrder
    isDeleted?: SortOrder
    isPublished?: SortOrder
    marketplaceApprovalStatus?: SortOrder
  }

  export type ApprovedMarketplaceProductCountOrderByAggregateInput = {
    projectId?: SortOrder
    marketplaceProduct?: SortOrder
    authorizationToken?: SortOrder
  }

  export type ApprovedMarketplaceProductMaxOrderByAggregateInput = {
    projectId?: SortOrder
    marketplaceProduct?: SortOrder
    authorizationToken?: SortOrder
  }

  export type ApprovedMarketplaceProductMinOrderByAggregateInput = {
    projectId?: SortOrder
    marketplaceProduct?: SortOrder
    authorizationToken?: SortOrder
  }

  export type UserCreateNestedManyWithoutTeamInput = {
    create?: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput> | UserCreateWithoutTeamInput[] | UserUncheckedCreateWithoutTeamInput[]
    connectOrCreate?: UserCreateOrConnectWithoutTeamInput | UserCreateOrConnectWithoutTeamInput[]
    createMany?: UserCreateManyTeamInputEnvelope
    connect?: UserWhereUniqueInput | UserWhereUniqueInput[]
  }

  export type UserUncheckedCreateNestedManyWithoutTeamInput = {
    create?: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput> | UserCreateWithoutTeamInput[] | UserUncheckedCreateWithoutTeamInput[]
    connectOrCreate?: UserCreateOrConnectWithoutTeamInput | UserCreateOrConnectWithoutTeamInput[]
    createMany?: UserCreateManyTeamInputEnvelope
    connect?: UserWhereUniqueInput | UserWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type UserUpdateManyWithoutTeamNestedInput = {
    create?: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput> | UserCreateWithoutTeamInput[] | UserUncheckedCreateWithoutTeamInput[]
    connectOrCreate?: UserCreateOrConnectWithoutTeamInput | UserCreateOrConnectWithoutTeamInput[]
    upsert?: UserUpsertWithWhereUniqueWithoutTeamInput | UserUpsertWithWhereUniqueWithoutTeamInput[]
    createMany?: UserCreateManyTeamInputEnvelope
    set?: UserWhereUniqueInput | UserWhereUniqueInput[]
    disconnect?: UserWhereUniqueInput | UserWhereUniqueInput[]
    delete?: UserWhereUniqueInput | UserWhereUniqueInput[]
    connect?: UserWhereUniqueInput | UserWhereUniqueInput[]
    update?: UserUpdateWithWhereUniqueWithoutTeamInput | UserUpdateWithWhereUniqueWithoutTeamInput[]
    updateMany?: UserUpdateManyWithWhereWithoutTeamInput | UserUpdateManyWithWhereWithoutTeamInput[]
    deleteMany?: UserScalarWhereInput | UserScalarWhereInput[]
  }

  export type UserUncheckedUpdateManyWithoutTeamNestedInput = {
    create?: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput> | UserCreateWithoutTeamInput[] | UserUncheckedCreateWithoutTeamInput[]
    connectOrCreate?: UserCreateOrConnectWithoutTeamInput | UserCreateOrConnectWithoutTeamInput[]
    upsert?: UserUpsertWithWhereUniqueWithoutTeamInput | UserUpsertWithWhereUniqueWithoutTeamInput[]
    createMany?: UserCreateManyTeamInputEnvelope
    set?: UserWhereUniqueInput | UserWhereUniqueInput[]
    disconnect?: UserWhereUniqueInput | UserWhereUniqueInput[]
    delete?: UserWhereUniqueInput | UserWhereUniqueInput[]
    connect?: UserWhereUniqueInput | UserWhereUniqueInput[]
    update?: UserUpdateWithWhereUniqueWithoutTeamInput | UserUpdateWithWhereUniqueWithoutTeamInput[]
    updateMany?: UserUpdateManyWithWhereWithoutTeamInput | UserUpdateManyWithWhereWithoutTeamInput[]
    deleteMany?: UserScalarWhereInput | UserScalarWhereInput[]
  }

  export type ProjectCreateNestedOneWithoutFilesInput = {
    create?: XOR<ProjectCreateWithoutFilesInput, ProjectUncheckedCreateWithoutFilesInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutFilesInput
    connect?: ProjectWhereUniqueInput
  }

  export type AssetCreateNestedManyWithoutFileInput = {
    create?: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput> | AssetCreateWithoutFileInput[] | AssetUncheckedCreateWithoutFileInput[]
    connectOrCreate?: AssetCreateOrConnectWithoutFileInput | AssetCreateOrConnectWithoutFileInput[]
    createMany?: AssetCreateManyFileInputEnvelope
    connect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
  }

  export type AssetUncheckedCreateNestedManyWithoutFileInput = {
    create?: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput> | AssetCreateWithoutFileInput[] | AssetUncheckedCreateWithoutFileInput[]
    connectOrCreate?: AssetCreateOrConnectWithoutFileInput | AssetCreateOrConnectWithoutFileInput[]
    createMany?: AssetCreateManyFileInputEnvelope
    connect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EnumUploadStatusFieldUpdateOperationsInput = {
    set?: $Enums.UploadStatus
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type ProjectUpdateOneWithoutFilesNestedInput = {
    create?: XOR<ProjectCreateWithoutFilesInput, ProjectUncheckedCreateWithoutFilesInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutFilesInput
    upsert?: ProjectUpsertWithoutFilesInput
    disconnect?: ProjectWhereInput | boolean
    delete?: ProjectWhereInput | boolean
    connect?: ProjectWhereUniqueInput
    update?: XOR<XOR<ProjectUpdateToOneWithWhereWithoutFilesInput, ProjectUpdateWithoutFilesInput>, ProjectUncheckedUpdateWithoutFilesInput>
  }

  export type AssetUpdateManyWithoutFileNestedInput = {
    create?: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput> | AssetCreateWithoutFileInput[] | AssetUncheckedCreateWithoutFileInput[]
    connectOrCreate?: AssetCreateOrConnectWithoutFileInput | AssetCreateOrConnectWithoutFileInput[]
    upsert?: AssetUpsertWithWhereUniqueWithoutFileInput | AssetUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: AssetCreateManyFileInputEnvelope
    set?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    disconnect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    delete?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    connect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    update?: AssetUpdateWithWhereUniqueWithoutFileInput | AssetUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: AssetUpdateManyWithWhereWithoutFileInput | AssetUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: AssetScalarWhereInput | AssetScalarWhereInput[]
  }

  export type AssetUncheckedUpdateManyWithoutFileNestedInput = {
    create?: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput> | AssetCreateWithoutFileInput[] | AssetUncheckedCreateWithoutFileInput[]
    connectOrCreate?: AssetCreateOrConnectWithoutFileInput | AssetCreateOrConnectWithoutFileInput[]
    upsert?: AssetUpsertWithWhereUniqueWithoutFileInput | AssetUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: AssetCreateManyFileInputEnvelope
    set?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    disconnect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    delete?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    connect?: AssetWhereUniqueInput | AssetWhereUniqueInput[]
    update?: AssetUpdateWithWhereUniqueWithoutFileInput | AssetUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: AssetUpdateManyWithWhereWithoutFileInput | AssetUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: AssetScalarWhereInput | AssetScalarWhereInput[]
  }

  export type FileCreateNestedOneWithoutAssetsInput = {
    create?: XOR<FileCreateWithoutAssetsInput, FileUncheckedCreateWithoutAssetsInput>
    connectOrCreate?: FileCreateOrConnectWithoutAssetsInput
    connect?: FileWhereUniqueInput
  }

  export type ProjectCreateNestedManyWithoutPreviewImageAssetInput = {
    create?: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput> | ProjectCreateWithoutPreviewImageAssetInput[] | ProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutPreviewImageAssetInput | ProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    createMany?: ProjectCreateManyPreviewImageAssetInputEnvelope
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
  }

  export type DashboardProjectCreateNestedManyWithoutPreviewImageAssetInput = {
    create?: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput> | DashboardProjectCreateWithoutPreviewImageAssetInput[] | DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput | DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    createMany?: DashboardProjectCreateManyPreviewImageAssetInputEnvelope
    connect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
  }

  export type ProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput = {
    create?: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput> | ProjectCreateWithoutPreviewImageAssetInput[] | ProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutPreviewImageAssetInput | ProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    createMany?: ProjectCreateManyPreviewImageAssetInputEnvelope
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
  }

  export type DashboardProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput = {
    create?: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput> | DashboardProjectCreateWithoutPreviewImageAssetInput[] | DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput | DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    createMany?: DashboardProjectCreateManyPreviewImageAssetInputEnvelope
    connect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
  }

  export type FileUpdateOneRequiredWithoutAssetsNestedInput = {
    create?: XOR<FileCreateWithoutAssetsInput, FileUncheckedCreateWithoutAssetsInput>
    connectOrCreate?: FileCreateOrConnectWithoutAssetsInput
    upsert?: FileUpsertWithoutAssetsInput
    connect?: FileWhereUniqueInput
    update?: XOR<XOR<FileUpdateToOneWithWhereWithoutAssetsInput, FileUpdateWithoutAssetsInput>, FileUncheckedUpdateWithoutAssetsInput>
  }

  export type ProjectUpdateManyWithoutPreviewImageAssetNestedInput = {
    create?: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput> | ProjectCreateWithoutPreviewImageAssetInput[] | ProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutPreviewImageAssetInput | ProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    upsert?: ProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput | ProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput[]
    createMany?: ProjectCreateManyPreviewImageAssetInputEnvelope
    set?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    disconnect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    delete?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    update?: ProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput | ProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput[]
    updateMany?: ProjectUpdateManyWithWhereWithoutPreviewImageAssetInput | ProjectUpdateManyWithWhereWithoutPreviewImageAssetInput[]
    deleteMany?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
  }

  export type DashboardProjectUpdateManyWithoutPreviewImageAssetNestedInput = {
    create?: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput> | DashboardProjectCreateWithoutPreviewImageAssetInput[] | DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput | DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    upsert?: DashboardProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput | DashboardProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput[]
    createMany?: DashboardProjectCreateManyPreviewImageAssetInputEnvelope
    set?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    disconnect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    delete?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    connect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    update?: DashboardProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput | DashboardProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput[]
    updateMany?: DashboardProjectUpdateManyWithWhereWithoutPreviewImageAssetInput | DashboardProjectUpdateManyWithWhereWithoutPreviewImageAssetInput[]
    deleteMany?: DashboardProjectScalarWhereInput | DashboardProjectScalarWhereInput[]
  }

  export type ProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput = {
    create?: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput> | ProjectCreateWithoutPreviewImageAssetInput[] | ProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutPreviewImageAssetInput | ProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    upsert?: ProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput | ProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput[]
    createMany?: ProjectCreateManyPreviewImageAssetInputEnvelope
    set?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    disconnect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    delete?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    update?: ProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput | ProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput[]
    updateMany?: ProjectUpdateManyWithWhereWithoutPreviewImageAssetInput | ProjectUpdateManyWithWhereWithoutPreviewImageAssetInput[]
    deleteMany?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
  }

  export type DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput = {
    create?: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput> | DashboardProjectCreateWithoutPreviewImageAssetInput[] | DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput[]
    connectOrCreate?: DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput | DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput[]
    upsert?: DashboardProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput | DashboardProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput[]
    createMany?: DashboardProjectCreateManyPreviewImageAssetInputEnvelope
    set?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    disconnect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    delete?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    connect?: DashboardProjectWhereUniqueInput | DashboardProjectWhereUniqueInput[]
    update?: DashboardProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput | DashboardProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput[]
    updateMany?: DashboardProjectUpdateManyWithWhereWithoutPreviewImageAssetInput | DashboardProjectUpdateManyWithWhereWithoutPreviewImageAssetInput[]
    deleteMany?: DashboardProjectScalarWhereInput | DashboardProjectScalarWhereInput[]
  }

  export type TeamCreateNestedOneWithoutUsersInput = {
    create?: XOR<TeamCreateWithoutUsersInput, TeamUncheckedCreateWithoutUsersInput>
    connectOrCreate?: TeamCreateOrConnectWithoutUsersInput
    connect?: TeamWhereUniqueInput
  }

  export type ProjectCreateNestedManyWithoutUserInput = {
    create?: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput> | ProjectCreateWithoutUserInput[] | ProjectUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutUserInput | ProjectCreateOrConnectWithoutUserInput[]
    createMany?: ProjectCreateManyUserInputEnvelope
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
  }

  export type ClientReferencesCreateNestedManyWithoutUserInput = {
    create?: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput> | ClientReferencesCreateWithoutUserInput[] | ClientReferencesUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ClientReferencesCreateOrConnectWithoutUserInput | ClientReferencesCreateOrConnectWithoutUserInput[]
    createMany?: ClientReferencesCreateManyUserInputEnvelope
    connect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
  }

  export type TransactionLogCreateNestedManyWithoutUserInput = {
    create?: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput> | TransactionLogCreateWithoutUserInput[] | TransactionLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutUserInput | TransactionLogCreateOrConnectWithoutUserInput[]
    createMany?: TransactionLogCreateManyUserInputEnvelope
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
  }

  export type UserProductCreateNestedManyWithoutUserInput = {
    create?: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput> | UserProductCreateWithoutUserInput[] | UserProductUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutUserInput | UserProductCreateOrConnectWithoutUserInput[]
    createMany?: UserProductCreateManyUserInputEnvelope
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
  }

  export type ProjectUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput> | ProjectCreateWithoutUserInput[] | ProjectUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutUserInput | ProjectCreateOrConnectWithoutUserInput[]
    createMany?: ProjectCreateManyUserInputEnvelope
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
  }

  export type ClientReferencesUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput> | ClientReferencesCreateWithoutUserInput[] | ClientReferencesUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ClientReferencesCreateOrConnectWithoutUserInput | ClientReferencesCreateOrConnectWithoutUserInput[]
    createMany?: ClientReferencesCreateManyUserInputEnvelope
    connect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
  }

  export type TransactionLogUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput> | TransactionLogCreateWithoutUserInput[] | TransactionLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutUserInput | TransactionLogCreateOrConnectWithoutUserInput[]
    createMany?: TransactionLogCreateManyUserInputEnvelope
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
  }

  export type UserProductUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput> | UserProductCreateWithoutUserInput[] | UserProductUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutUserInput | UserProductCreateOrConnectWithoutUserInput[]
    createMany?: UserProductCreateManyUserInputEnvelope
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
  }

  export type TeamUpdateOneWithoutUsersNestedInput = {
    create?: XOR<TeamCreateWithoutUsersInput, TeamUncheckedCreateWithoutUsersInput>
    connectOrCreate?: TeamCreateOrConnectWithoutUsersInput
    upsert?: TeamUpsertWithoutUsersInput
    disconnect?: TeamWhereInput | boolean
    delete?: TeamWhereInput | boolean
    connect?: TeamWhereUniqueInput
    update?: XOR<XOR<TeamUpdateToOneWithWhereWithoutUsersInput, TeamUpdateWithoutUsersInput>, TeamUncheckedUpdateWithoutUsersInput>
  }

  export type ProjectUpdateManyWithoutUserNestedInput = {
    create?: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput> | ProjectCreateWithoutUserInput[] | ProjectUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutUserInput | ProjectCreateOrConnectWithoutUserInput[]
    upsert?: ProjectUpsertWithWhereUniqueWithoutUserInput | ProjectUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ProjectCreateManyUserInputEnvelope
    set?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    disconnect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    delete?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    update?: ProjectUpdateWithWhereUniqueWithoutUserInput | ProjectUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ProjectUpdateManyWithWhereWithoutUserInput | ProjectUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
  }

  export type ClientReferencesUpdateManyWithoutUserNestedInput = {
    create?: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput> | ClientReferencesCreateWithoutUserInput[] | ClientReferencesUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ClientReferencesCreateOrConnectWithoutUserInput | ClientReferencesCreateOrConnectWithoutUserInput[]
    upsert?: ClientReferencesUpsertWithWhereUniqueWithoutUserInput | ClientReferencesUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ClientReferencesCreateManyUserInputEnvelope
    set?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    disconnect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    delete?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    connect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    update?: ClientReferencesUpdateWithWhereUniqueWithoutUserInput | ClientReferencesUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ClientReferencesUpdateManyWithWhereWithoutUserInput | ClientReferencesUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ClientReferencesScalarWhereInput | ClientReferencesScalarWhereInput[]
  }

  export type TransactionLogUpdateManyWithoutUserNestedInput = {
    create?: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput> | TransactionLogCreateWithoutUserInput[] | TransactionLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutUserInput | TransactionLogCreateOrConnectWithoutUserInput[]
    upsert?: TransactionLogUpsertWithWhereUniqueWithoutUserInput | TransactionLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TransactionLogCreateManyUserInputEnvelope
    set?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    disconnect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    delete?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    update?: TransactionLogUpdateWithWhereUniqueWithoutUserInput | TransactionLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TransactionLogUpdateManyWithWhereWithoutUserInput | TransactionLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
  }

  export type UserProductUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput> | UserProductCreateWithoutUserInput[] | UserProductUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutUserInput | UserProductCreateOrConnectWithoutUserInput[]
    upsert?: UserProductUpsertWithWhereUniqueWithoutUserInput | UserProductUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserProductCreateManyUserInputEnvelope
    set?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    disconnect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    delete?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    update?: UserProductUpdateWithWhereUniqueWithoutUserInput | UserProductUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserProductUpdateManyWithWhereWithoutUserInput | UserProductUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
  }

  export type ProjectUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput> | ProjectCreateWithoutUserInput[] | ProjectUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProjectCreateOrConnectWithoutUserInput | ProjectCreateOrConnectWithoutUserInput[]
    upsert?: ProjectUpsertWithWhereUniqueWithoutUserInput | ProjectUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ProjectCreateManyUserInputEnvelope
    set?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    disconnect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    delete?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    connect?: ProjectWhereUniqueInput | ProjectWhereUniqueInput[]
    update?: ProjectUpdateWithWhereUniqueWithoutUserInput | ProjectUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ProjectUpdateManyWithWhereWithoutUserInput | ProjectUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
  }

  export type ClientReferencesUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput> | ClientReferencesCreateWithoutUserInput[] | ClientReferencesUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ClientReferencesCreateOrConnectWithoutUserInput | ClientReferencesCreateOrConnectWithoutUserInput[]
    upsert?: ClientReferencesUpsertWithWhereUniqueWithoutUserInput | ClientReferencesUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ClientReferencesCreateManyUserInputEnvelope
    set?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    disconnect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    delete?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    connect?: ClientReferencesWhereUniqueInput | ClientReferencesWhereUniqueInput[]
    update?: ClientReferencesUpdateWithWhereUniqueWithoutUserInput | ClientReferencesUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ClientReferencesUpdateManyWithWhereWithoutUserInput | ClientReferencesUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ClientReferencesScalarWhereInput | ClientReferencesScalarWhereInput[]
  }

  export type TransactionLogUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput> | TransactionLogCreateWithoutUserInput[] | TransactionLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutUserInput | TransactionLogCreateOrConnectWithoutUserInput[]
    upsert?: TransactionLogUpsertWithWhereUniqueWithoutUserInput | TransactionLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TransactionLogCreateManyUserInputEnvelope
    set?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    disconnect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    delete?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    update?: TransactionLogUpdateWithWhereUniqueWithoutUserInput | TransactionLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TransactionLogUpdateManyWithWhereWithoutUserInput | TransactionLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
  }

  export type UserProductUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput> | UserProductCreateWithoutUserInput[] | UserProductUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutUserInput | UserProductCreateOrConnectWithoutUserInput[]
    upsert?: UserProductUpsertWithWhereUniqueWithoutUserInput | UserProductUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserProductCreateManyUserInputEnvelope
    set?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    disconnect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    delete?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    update?: UserProductUpdateWithWhereUniqueWithoutUserInput | UserProductUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserProductUpdateManyWithWhereWithoutUserInput | UserProductUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutClientReferencesInput = {
    create?: XOR<UserCreateWithoutClientReferencesInput, UserUncheckedCreateWithoutClientReferencesInput>
    connectOrCreate?: UserCreateOrConnectWithoutClientReferencesInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutClientReferencesNestedInput = {
    create?: XOR<UserCreateWithoutClientReferencesInput, UserUncheckedCreateWithoutClientReferencesInput>
    connectOrCreate?: UserCreateOrConnectWithoutClientReferencesInput
    upsert?: UserUpsertWithoutClientReferencesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutClientReferencesInput, UserUpdateWithoutClientReferencesInput>, UserUncheckedUpdateWithoutClientReferencesInput>
  }

  export type ProductCreatefeaturesInput = {
    set: string[]
  }

  export type ProductCreateimagesInput = {
    set: string[]
  }

  export type TransactionLogCreateNestedManyWithoutProductInput = {
    create?: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput> | TransactionLogCreateWithoutProductInput[] | TransactionLogUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutProductInput | TransactionLogCreateOrConnectWithoutProductInput[]
    createMany?: TransactionLogCreateManyProductInputEnvelope
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
  }

  export type UserProductCreateNestedManyWithoutProductInput = {
    create?: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput> | UserProductCreateWithoutProductInput[] | UserProductUncheckedCreateWithoutProductInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutProductInput | UserProductCreateOrConnectWithoutProductInput[]
    createMany?: UserProductCreateManyProductInputEnvelope
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
  }

  export type TransactionLogUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput> | TransactionLogCreateWithoutProductInput[] | TransactionLogUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutProductInput | TransactionLogCreateOrConnectWithoutProductInput[]
    createMany?: TransactionLogCreateManyProductInputEnvelope
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
  }

  export type UserProductUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput> | UserProductCreateWithoutProductInput[] | UserProductUncheckedCreateWithoutProductInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutProductInput | UserProductCreateOrConnectWithoutProductInput[]
    createMany?: UserProductCreateManyProductInputEnvelope
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
  }

  export type ProductUpdatefeaturesInput = {
    set?: string[]
    push?: string | string[]
  }

  export type ProductUpdateimagesInput = {
    set?: string[]
    push?: string | string[]
  }

  export type TransactionLogUpdateManyWithoutProductNestedInput = {
    create?: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput> | TransactionLogCreateWithoutProductInput[] | TransactionLogUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutProductInput | TransactionLogCreateOrConnectWithoutProductInput[]
    upsert?: TransactionLogUpsertWithWhereUniqueWithoutProductInput | TransactionLogUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: TransactionLogCreateManyProductInputEnvelope
    set?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    disconnect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    delete?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    update?: TransactionLogUpdateWithWhereUniqueWithoutProductInput | TransactionLogUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: TransactionLogUpdateManyWithWhereWithoutProductInput | TransactionLogUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
  }

  export type UserProductUpdateManyWithoutProductNestedInput = {
    create?: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput> | UserProductCreateWithoutProductInput[] | UserProductUncheckedCreateWithoutProductInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutProductInput | UserProductCreateOrConnectWithoutProductInput[]
    upsert?: UserProductUpsertWithWhereUniqueWithoutProductInput | UserProductUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: UserProductCreateManyProductInputEnvelope
    set?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    disconnect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    delete?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    update?: UserProductUpdateWithWhereUniqueWithoutProductInput | UserProductUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: UserProductUpdateManyWithWhereWithoutProductInput | UserProductUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
  }

  export type TransactionLogUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput> | TransactionLogCreateWithoutProductInput[] | TransactionLogUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionLogCreateOrConnectWithoutProductInput | TransactionLogCreateOrConnectWithoutProductInput[]
    upsert?: TransactionLogUpsertWithWhereUniqueWithoutProductInput | TransactionLogUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: TransactionLogCreateManyProductInputEnvelope
    set?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    disconnect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    delete?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    connect?: TransactionLogWhereUniqueInput | TransactionLogWhereUniqueInput[]
    update?: TransactionLogUpdateWithWhereUniqueWithoutProductInput | TransactionLogUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: TransactionLogUpdateManyWithWhereWithoutProductInput | TransactionLogUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
  }

  export type UserProductUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput> | UserProductCreateWithoutProductInput[] | UserProductUncheckedCreateWithoutProductInput[]
    connectOrCreate?: UserProductCreateOrConnectWithoutProductInput | UserProductCreateOrConnectWithoutProductInput[]
    upsert?: UserProductUpsertWithWhereUniqueWithoutProductInput | UserProductUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: UserProductCreateManyProductInputEnvelope
    set?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    disconnect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    delete?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    connect?: UserProductWhereUniqueInput | UserProductWhereUniqueInput[]
    update?: UserProductUpdateWithWhereUniqueWithoutProductInput | UserProductUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: UserProductUpdateManyWithWhereWithoutProductInput | UserProductUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutCheckoutInput = {
    create?: XOR<UserCreateWithoutCheckoutInput, UserUncheckedCreateWithoutCheckoutInput>
    connectOrCreate?: UserCreateOrConnectWithoutCheckoutInput
    connect?: UserWhereUniqueInput
  }

  export type ProductCreateNestedOneWithoutCheckoutInput = {
    create?: XOR<ProductCreateWithoutCheckoutInput, ProductUncheckedCreateWithoutCheckoutInput>
    connectOrCreate?: ProductCreateOrConnectWithoutCheckoutInput
    connect?: ProductWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type UserUpdateOneWithoutCheckoutNestedInput = {
    create?: XOR<UserCreateWithoutCheckoutInput, UserUncheckedCreateWithoutCheckoutInput>
    connectOrCreate?: UserCreateOrConnectWithoutCheckoutInput
    upsert?: UserUpsertWithoutCheckoutInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCheckoutInput, UserUpdateWithoutCheckoutInput>, UserUncheckedUpdateWithoutCheckoutInput>
  }

  export type ProductUpdateOneWithoutCheckoutNestedInput = {
    create?: XOR<ProductCreateWithoutCheckoutInput, ProductUncheckedCreateWithoutCheckoutInput>
    connectOrCreate?: ProductCreateOrConnectWithoutCheckoutInput
    upsert?: ProductUpsertWithoutCheckoutInput
    disconnect?: ProductWhereInput | boolean
    delete?: ProductWhereInput | boolean
    connect?: ProductWhereUniqueInput
    update?: XOR<XOR<ProductUpdateToOneWithWhereWithoutCheckoutInput, ProductUpdateWithoutCheckoutInput>, ProductUncheckedUpdateWithoutCheckoutInput>
  }

  export type UserCreateNestedOneWithoutProjectsInput = {
    create?: XOR<UserCreateWithoutProjectsInput, UserUncheckedCreateWithoutProjectsInput>
    connectOrCreate?: UserCreateOrConnectWithoutProjectsInput
    connect?: UserWhereUniqueInput
  }

  export type BuildCreateNestedManyWithoutProjectInput = {
    create?: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput> | BuildCreateWithoutProjectInput[] | BuildUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: BuildCreateOrConnectWithoutProjectInput | BuildCreateOrConnectWithoutProjectInput[]
    createMany?: BuildCreateManyProjectInputEnvelope
    connect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
  }

  export type FileCreateNestedManyWithoutUploaderProjectInput = {
    create?: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput> | FileCreateWithoutUploaderProjectInput[] | FileUncheckedCreateWithoutUploaderProjectInput[]
    connectOrCreate?: FileCreateOrConnectWithoutUploaderProjectInput | FileCreateOrConnectWithoutUploaderProjectInput[]
    createMany?: FileCreateManyUploaderProjectInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type ProjectDomainCreateNestedManyWithoutProjectInput = {
    create?: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput> | ProjectDomainCreateWithoutProjectInput[] | ProjectDomainUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutProjectInput | ProjectDomainCreateOrConnectWithoutProjectInput[]
    createMany?: ProjectDomainCreateManyProjectInputEnvelope
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
  }

  export type AuthorizationTokenCreateNestedManyWithoutProjectInput = {
    create?: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput> | AuthorizationTokenCreateWithoutProjectInput[] | AuthorizationTokenUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: AuthorizationTokenCreateOrConnectWithoutProjectInput | AuthorizationTokenCreateOrConnectWithoutProjectInput[]
    createMany?: AuthorizationTokenCreateManyProjectInputEnvelope
    connect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
  }

  export type AssetCreateNestedOneWithoutProjectInput = {
    create?: XOR<AssetCreateWithoutProjectInput, AssetUncheckedCreateWithoutProjectInput>
    connectOrCreate?: AssetCreateOrConnectWithoutProjectInput
    connect?: AssetWhereUniqueInput
  }

  export type LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutProjectInput
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
  }

  export type BuildUncheckedCreateNestedManyWithoutProjectInput = {
    create?: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput> | BuildCreateWithoutProjectInput[] | BuildUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: BuildCreateOrConnectWithoutProjectInput | BuildCreateOrConnectWithoutProjectInput[]
    createMany?: BuildCreateManyProjectInputEnvelope
    connect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
  }

  export type FileUncheckedCreateNestedManyWithoutUploaderProjectInput = {
    create?: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput> | FileCreateWithoutUploaderProjectInput[] | FileUncheckedCreateWithoutUploaderProjectInput[]
    connectOrCreate?: FileCreateOrConnectWithoutUploaderProjectInput | FileCreateOrConnectWithoutUploaderProjectInput[]
    createMany?: FileCreateManyUploaderProjectInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type ProjectDomainUncheckedCreateNestedManyWithoutProjectInput = {
    create?: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput> | ProjectDomainCreateWithoutProjectInput[] | ProjectDomainUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutProjectInput | ProjectDomainCreateOrConnectWithoutProjectInput[]
    createMany?: ProjectDomainCreateManyProjectInputEnvelope
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
  }

  export type AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput = {
    create?: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput> | AuthorizationTokenCreateWithoutProjectInput[] | AuthorizationTokenUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: AuthorizationTokenCreateOrConnectWithoutProjectInput | AuthorizationTokenCreateOrConnectWithoutProjectInput[]
    createMany?: AuthorizationTokenCreateManyProjectInputEnvelope
    connect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
  }

  export type LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutProjectInput
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
  }

  export type EnumMarketplaceApprovalStatusFieldUpdateOperationsInput = {
    set?: $Enums.MarketplaceApprovalStatus
  }

  export type UserUpdateOneWithoutProjectsNestedInput = {
    create?: XOR<UserCreateWithoutProjectsInput, UserUncheckedCreateWithoutProjectsInput>
    connectOrCreate?: UserCreateOrConnectWithoutProjectsInput
    upsert?: UserUpsertWithoutProjectsInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutProjectsInput, UserUpdateWithoutProjectsInput>, UserUncheckedUpdateWithoutProjectsInput>
  }

  export type BuildUpdateManyWithoutProjectNestedInput = {
    create?: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput> | BuildCreateWithoutProjectInput[] | BuildUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: BuildCreateOrConnectWithoutProjectInput | BuildCreateOrConnectWithoutProjectInput[]
    upsert?: BuildUpsertWithWhereUniqueWithoutProjectInput | BuildUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: BuildCreateManyProjectInputEnvelope
    set?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    disconnect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    delete?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    connect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    update?: BuildUpdateWithWhereUniqueWithoutProjectInput | BuildUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: BuildUpdateManyWithWhereWithoutProjectInput | BuildUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: BuildScalarWhereInput | BuildScalarWhereInput[]
  }

  export type FileUpdateManyWithoutUploaderProjectNestedInput = {
    create?: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput> | FileCreateWithoutUploaderProjectInput[] | FileUncheckedCreateWithoutUploaderProjectInput[]
    connectOrCreate?: FileCreateOrConnectWithoutUploaderProjectInput | FileCreateOrConnectWithoutUploaderProjectInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutUploaderProjectInput | FileUpsertWithWhereUniqueWithoutUploaderProjectInput[]
    createMany?: FileCreateManyUploaderProjectInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutUploaderProjectInput | FileUpdateWithWhereUniqueWithoutUploaderProjectInput[]
    updateMany?: FileUpdateManyWithWhereWithoutUploaderProjectInput | FileUpdateManyWithWhereWithoutUploaderProjectInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type ProjectDomainUpdateManyWithoutProjectNestedInput = {
    create?: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput> | ProjectDomainCreateWithoutProjectInput[] | ProjectDomainUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutProjectInput | ProjectDomainCreateOrConnectWithoutProjectInput[]
    upsert?: ProjectDomainUpsertWithWhereUniqueWithoutProjectInput | ProjectDomainUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: ProjectDomainCreateManyProjectInputEnvelope
    set?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    disconnect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    delete?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    update?: ProjectDomainUpdateWithWhereUniqueWithoutProjectInput | ProjectDomainUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: ProjectDomainUpdateManyWithWhereWithoutProjectInput | ProjectDomainUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
  }

  export type AuthorizationTokenUpdateManyWithoutProjectNestedInput = {
    create?: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput> | AuthorizationTokenCreateWithoutProjectInput[] | AuthorizationTokenUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: AuthorizationTokenCreateOrConnectWithoutProjectInput | AuthorizationTokenCreateOrConnectWithoutProjectInput[]
    upsert?: AuthorizationTokenUpsertWithWhereUniqueWithoutProjectInput | AuthorizationTokenUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: AuthorizationTokenCreateManyProjectInputEnvelope
    set?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    disconnect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    delete?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    connect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    update?: AuthorizationTokenUpdateWithWhereUniqueWithoutProjectInput | AuthorizationTokenUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: AuthorizationTokenUpdateManyWithWhereWithoutProjectInput | AuthorizationTokenUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: AuthorizationTokenScalarWhereInput | AuthorizationTokenScalarWhereInput[]
  }

  export type AssetUpdateOneWithoutProjectNestedInput = {
    create?: XOR<AssetCreateWithoutProjectInput, AssetUncheckedCreateWithoutProjectInput>
    connectOrCreate?: AssetCreateOrConnectWithoutProjectInput
    upsert?: AssetUpsertWithoutProjectInput
    disconnect?: AssetWhereInput | boolean
    delete?: AssetWhereInput | boolean
    connect?: AssetWhereUniqueInput
    update?: XOR<XOR<AssetUpdateToOneWithWhereWithoutProjectInput, AssetUpdateWithoutProjectInput>, AssetUncheckedUpdateWithoutProjectInput>
  }

  export type LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutProjectInput
    upsert?: LatestStaticBuildPerProjectUpsertWithoutProjectInput
    disconnect?: LatestStaticBuildPerProjectWhereInput | boolean
    delete?: LatestStaticBuildPerProjectWhereInput | boolean
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
    update?: XOR<XOR<LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutProjectInput, LatestStaticBuildPerProjectUpdateWithoutProjectInput>, LatestStaticBuildPerProjectUncheckedUpdateWithoutProjectInput>
  }

  export type BuildUncheckedUpdateManyWithoutProjectNestedInput = {
    create?: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput> | BuildCreateWithoutProjectInput[] | BuildUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: BuildCreateOrConnectWithoutProjectInput | BuildCreateOrConnectWithoutProjectInput[]
    upsert?: BuildUpsertWithWhereUniqueWithoutProjectInput | BuildUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: BuildCreateManyProjectInputEnvelope
    set?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    disconnect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    delete?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    connect?: BuildWhereUniqueInput | BuildWhereUniqueInput[]
    update?: BuildUpdateWithWhereUniqueWithoutProjectInput | BuildUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: BuildUpdateManyWithWhereWithoutProjectInput | BuildUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: BuildScalarWhereInput | BuildScalarWhereInput[]
  }

  export type FileUncheckedUpdateManyWithoutUploaderProjectNestedInput = {
    create?: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput> | FileCreateWithoutUploaderProjectInput[] | FileUncheckedCreateWithoutUploaderProjectInput[]
    connectOrCreate?: FileCreateOrConnectWithoutUploaderProjectInput | FileCreateOrConnectWithoutUploaderProjectInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutUploaderProjectInput | FileUpsertWithWhereUniqueWithoutUploaderProjectInput[]
    createMany?: FileCreateManyUploaderProjectInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutUploaderProjectInput | FileUpdateWithWhereUniqueWithoutUploaderProjectInput[]
    updateMany?: FileUpdateManyWithWhereWithoutUploaderProjectInput | FileUpdateManyWithWhereWithoutUploaderProjectInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput = {
    create?: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput> | ProjectDomainCreateWithoutProjectInput[] | ProjectDomainUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutProjectInput | ProjectDomainCreateOrConnectWithoutProjectInput[]
    upsert?: ProjectDomainUpsertWithWhereUniqueWithoutProjectInput | ProjectDomainUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: ProjectDomainCreateManyProjectInputEnvelope
    set?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    disconnect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    delete?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    update?: ProjectDomainUpdateWithWhereUniqueWithoutProjectInput | ProjectDomainUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: ProjectDomainUpdateManyWithWhereWithoutProjectInput | ProjectDomainUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
  }

  export type AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput = {
    create?: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput> | AuthorizationTokenCreateWithoutProjectInput[] | AuthorizationTokenUncheckedCreateWithoutProjectInput[]
    connectOrCreate?: AuthorizationTokenCreateOrConnectWithoutProjectInput | AuthorizationTokenCreateOrConnectWithoutProjectInput[]
    upsert?: AuthorizationTokenUpsertWithWhereUniqueWithoutProjectInput | AuthorizationTokenUpsertWithWhereUniqueWithoutProjectInput[]
    createMany?: AuthorizationTokenCreateManyProjectInputEnvelope
    set?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    disconnect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    delete?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    connect?: AuthorizationTokenWhereUniqueInput | AuthorizationTokenWhereUniqueInput[]
    update?: AuthorizationTokenUpdateWithWhereUniqueWithoutProjectInput | AuthorizationTokenUpdateWithWhereUniqueWithoutProjectInput[]
    updateMany?: AuthorizationTokenUpdateManyWithWhereWithoutProjectInput | AuthorizationTokenUpdateManyWithWhereWithoutProjectInput[]
    deleteMany?: AuthorizationTokenScalarWhereInput | AuthorizationTokenScalarWhereInput[]
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutProjectInput
    upsert?: LatestStaticBuildPerProjectUpsertWithoutProjectInput
    disconnect?: LatestStaticBuildPerProjectWhereInput | boolean
    delete?: LatestStaticBuildPerProjectWhereInput | boolean
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
    update?: XOR<XOR<LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutProjectInput, LatestStaticBuildPerProjectUpdateWithoutProjectInput>, LatestStaticBuildPerProjectUncheckedUpdateWithoutProjectInput>
  }

  export type ProjectCreateNestedOneWithoutBuildInput = {
    create?: XOR<ProjectCreateWithoutBuildInput, ProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutBuildInput
    connect?: ProjectWhereUniqueInput
  }

  export type LatestStaticBuildPerProjectCreateNestedOneWithoutBuildInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutBuildInput
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
  }

  export type LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutBuildInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutBuildInput
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
  }

  export type EnumPublishStatusFieldUpdateOperationsInput = {
    set?: $Enums.PublishStatus
  }

  export type ProjectUpdateOneRequiredWithoutBuildNestedInput = {
    create?: XOR<ProjectCreateWithoutBuildInput, ProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutBuildInput
    upsert?: ProjectUpsertWithoutBuildInput
    connect?: ProjectWhereUniqueInput
    update?: XOR<XOR<ProjectUpdateToOneWithWhereWithoutBuildInput, ProjectUpdateWithoutBuildInput>, ProjectUncheckedUpdateWithoutBuildInput>
  }

  export type LatestStaticBuildPerProjectUpdateOneWithoutBuildNestedInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutBuildInput
    upsert?: LatestStaticBuildPerProjectUpsertWithoutBuildInput
    disconnect?: LatestStaticBuildPerProjectWhereInput | boolean
    delete?: LatestStaticBuildPerProjectWhereInput | boolean
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
    update?: XOR<XOR<LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutBuildInput, LatestStaticBuildPerProjectUpdateWithoutBuildInput>, LatestStaticBuildPerProjectUncheckedUpdateWithoutBuildInput>
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateOneWithoutBuildNestedInput = {
    create?: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
    connectOrCreate?: LatestStaticBuildPerProjectCreateOrConnectWithoutBuildInput
    upsert?: LatestStaticBuildPerProjectUpsertWithoutBuildInput
    disconnect?: LatestStaticBuildPerProjectWhereInput | boolean
    delete?: LatestStaticBuildPerProjectWhereInput | boolean
    connect?: LatestStaticBuildPerProjectWhereUniqueInput
    update?: XOR<XOR<LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutBuildInput, LatestStaticBuildPerProjectUpdateWithoutBuildInput>, LatestStaticBuildPerProjectUncheckedUpdateWithoutBuildInput>
  }

  export type ProjectCreateNestedOneWithoutAuthorizationTokenInput = {
    create?: XOR<ProjectCreateWithoutAuthorizationTokenInput, ProjectUncheckedCreateWithoutAuthorizationTokenInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutAuthorizationTokenInput
    connect?: ProjectWhereUniqueInput
  }

  export type EnumAuthorizationRelationFieldUpdateOperationsInput = {
    set?: $Enums.AuthorizationRelation
  }

  export type ProjectUpdateOneRequiredWithoutAuthorizationTokenNestedInput = {
    create?: XOR<ProjectCreateWithoutAuthorizationTokenInput, ProjectUncheckedCreateWithoutAuthorizationTokenInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutAuthorizationTokenInput
    upsert?: ProjectUpsertWithoutAuthorizationTokenInput
    connect?: ProjectWhereUniqueInput
    update?: XOR<XOR<ProjectUpdateToOneWithWhereWithoutAuthorizationTokenInput, ProjectUpdateWithoutAuthorizationTokenInput>, ProjectUncheckedUpdateWithoutAuthorizationTokenInput>
  }

  export type ProjectDomainCreateNestedManyWithoutDomainInput = {
    create?: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput> | ProjectDomainCreateWithoutDomainInput[] | ProjectDomainUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutDomainInput | ProjectDomainCreateOrConnectWithoutDomainInput[]
    createMany?: ProjectDomainCreateManyDomainInputEnvelope
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
  }

  export type ProjectDomainUncheckedCreateNestedManyWithoutDomainInput = {
    create?: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput> | ProjectDomainCreateWithoutDomainInput[] | ProjectDomainUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutDomainInput | ProjectDomainCreateOrConnectWithoutDomainInput[]
    createMany?: ProjectDomainCreateManyDomainInputEnvelope
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
  }

  export type EnumDomainStatusFieldUpdateOperationsInput = {
    set?: $Enums.DomainStatus
  }

  export type ProjectDomainUpdateManyWithoutDomainNestedInput = {
    create?: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput> | ProjectDomainCreateWithoutDomainInput[] | ProjectDomainUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutDomainInput | ProjectDomainCreateOrConnectWithoutDomainInput[]
    upsert?: ProjectDomainUpsertWithWhereUniqueWithoutDomainInput | ProjectDomainUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: ProjectDomainCreateManyDomainInputEnvelope
    set?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    disconnect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    delete?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    update?: ProjectDomainUpdateWithWhereUniqueWithoutDomainInput | ProjectDomainUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: ProjectDomainUpdateManyWithWhereWithoutDomainInput | ProjectDomainUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
  }

  export type ProjectDomainUncheckedUpdateManyWithoutDomainNestedInput = {
    create?: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput> | ProjectDomainCreateWithoutDomainInput[] | ProjectDomainUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ProjectDomainCreateOrConnectWithoutDomainInput | ProjectDomainCreateOrConnectWithoutDomainInput[]
    upsert?: ProjectDomainUpsertWithWhereUniqueWithoutDomainInput | ProjectDomainUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: ProjectDomainCreateManyDomainInputEnvelope
    set?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    disconnect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    delete?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    connect?: ProjectDomainWhereUniqueInput | ProjectDomainWhereUniqueInput[]
    update?: ProjectDomainUpdateWithWhereUniqueWithoutDomainInput | ProjectDomainUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: ProjectDomainUpdateManyWithWhereWithoutDomainInput | ProjectDomainUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
  }

  export type ProjectCreateNestedOneWithoutProjectDomainInput = {
    create?: XOR<ProjectCreateWithoutProjectDomainInput, ProjectUncheckedCreateWithoutProjectDomainInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutProjectDomainInput
    connect?: ProjectWhereUniqueInput
  }

  export type DomainCreateNestedOneWithoutProjectDomainInput = {
    create?: XOR<DomainCreateWithoutProjectDomainInput, DomainUncheckedCreateWithoutProjectDomainInput>
    connectOrCreate?: DomainCreateOrConnectWithoutProjectDomainInput
    connect?: DomainWhereUniqueInput
  }

  export type ProjectUpdateOneRequiredWithoutProjectDomainNestedInput = {
    create?: XOR<ProjectCreateWithoutProjectDomainInput, ProjectUncheckedCreateWithoutProjectDomainInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutProjectDomainInput
    upsert?: ProjectUpsertWithoutProjectDomainInput
    connect?: ProjectWhereUniqueInput
    update?: XOR<XOR<ProjectUpdateToOneWithWhereWithoutProjectDomainInput, ProjectUpdateWithoutProjectDomainInput>, ProjectUncheckedUpdateWithoutProjectDomainInput>
  }

  export type DomainUpdateOneRequiredWithoutProjectDomainNestedInput = {
    create?: XOR<DomainCreateWithoutProjectDomainInput, DomainUncheckedCreateWithoutProjectDomainInput>
    connectOrCreate?: DomainCreateOrConnectWithoutProjectDomainInput
    upsert?: DomainUpsertWithoutProjectDomainInput
    connect?: DomainWhereUniqueInput
    update?: XOR<XOR<DomainUpdateToOneWithWhereWithoutProjectDomainInput, DomainUpdateWithoutProjectDomainInput>, DomainUncheckedUpdateWithoutProjectDomainInput>
  }

  export type UserCreateNestedOneWithoutProductsInput = {
    create?: XOR<UserCreateWithoutProductsInput, UserUncheckedCreateWithoutProductsInput>
    connectOrCreate?: UserCreateOrConnectWithoutProductsInput
    connect?: UserWhereUniqueInput
  }

  export type ProductCreateNestedOneWithoutUserProductsInput = {
    create?: XOR<ProductCreateWithoutUserProductsInput, ProductUncheckedCreateWithoutUserProductsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutUserProductsInput
    connect?: ProductWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutProductsNestedInput = {
    create?: XOR<UserCreateWithoutProductsInput, UserUncheckedCreateWithoutProductsInput>
    connectOrCreate?: UserCreateOrConnectWithoutProductsInput
    upsert?: UserUpsertWithoutProductsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutProductsInput, UserUpdateWithoutProductsInput>, UserUncheckedUpdateWithoutProductsInput>
  }

  export type ProductUpdateOneRequiredWithoutUserProductsNestedInput = {
    create?: XOR<ProductCreateWithoutUserProductsInput, ProductUncheckedCreateWithoutUserProductsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutUserProductsInput
    upsert?: ProductUpsertWithoutUserProductsInput
    connect?: ProductWhereUniqueInput
    update?: XOR<XOR<ProductUpdateToOneWithWhereWithoutUserProductsInput, ProductUpdateWithoutUserProductsInput>, ProductUncheckedUpdateWithoutUserProductsInput>
  }

  export type BuildCreateNestedOneWithoutLatestStaticBuildPerProjectInput = {
    create?: XOR<BuildCreateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedCreateWithoutLatestStaticBuildPerProjectInput>
    connectOrCreate?: BuildCreateOrConnectWithoutLatestStaticBuildPerProjectInput
    connect?: BuildWhereUniqueInput
  }

  export type ProjectCreateNestedOneWithoutLatestStaticBuildInput = {
    create?: XOR<ProjectCreateWithoutLatestStaticBuildInput, ProjectUncheckedCreateWithoutLatestStaticBuildInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutLatestStaticBuildInput
    connect?: ProjectWhereUniqueInput
  }

  export type BuildUpdateOneRequiredWithoutLatestStaticBuildPerProjectNestedInput = {
    create?: XOR<BuildCreateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedCreateWithoutLatestStaticBuildPerProjectInput>
    connectOrCreate?: BuildCreateOrConnectWithoutLatestStaticBuildPerProjectInput
    upsert?: BuildUpsertWithoutLatestStaticBuildPerProjectInput
    connect?: BuildWhereUniqueInput
    update?: XOR<XOR<BuildUpdateToOneWithWhereWithoutLatestStaticBuildPerProjectInput, BuildUpdateWithoutLatestStaticBuildPerProjectInput>, BuildUncheckedUpdateWithoutLatestStaticBuildPerProjectInput>
  }

  export type ProjectUpdateOneRequiredWithoutLatestStaticBuildNestedInput = {
    create?: XOR<ProjectCreateWithoutLatestStaticBuildInput, ProjectUncheckedCreateWithoutLatestStaticBuildInput>
    connectOrCreate?: ProjectCreateOrConnectWithoutLatestStaticBuildInput
    upsert?: ProjectUpsertWithoutLatestStaticBuildInput
    connect?: ProjectWhereUniqueInput
    update?: XOR<XOR<ProjectUpdateToOneWithWhereWithoutLatestStaticBuildInput, ProjectUpdateWithoutLatestStaticBuildInput>, ProjectUncheckedUpdateWithoutLatestStaticBuildInput>
  }

  export type AssetCreateNestedOneWithoutDashboardProjectInput = {
    create?: XOR<AssetCreateWithoutDashboardProjectInput, AssetUncheckedCreateWithoutDashboardProjectInput>
    connectOrCreate?: AssetCreateOrConnectWithoutDashboardProjectInput
    connect?: AssetWhereUniqueInput
  }

  export type AssetUpdateOneWithoutDashboardProjectNestedInput = {
    create?: XOR<AssetCreateWithoutDashboardProjectInput, AssetUncheckedCreateWithoutDashboardProjectInput>
    connectOrCreate?: AssetCreateOrConnectWithoutDashboardProjectInput
    upsert?: AssetUpsertWithoutDashboardProjectInput
    disconnect?: AssetWhereInput | boolean
    delete?: AssetWhereInput | boolean
    connect?: AssetWhereUniqueInput
    update?: XOR<XOR<AssetUpdateToOneWithWhereWithoutDashboardProjectInput, AssetUpdateWithoutDashboardProjectInput>, AssetUncheckedUpdateWithoutDashboardProjectInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedEnumUploadStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.UploadStatus | EnumUploadStatusFieldRefInput<$PrismaModel>
    in?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumUploadStatusFilter<$PrismaModel> | $Enums.UploadStatus
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumUploadStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UploadStatus | EnumUploadStatusFieldRefInput<$PrismaModel>
    in?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.UploadStatus[] | ListEnumUploadStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumUploadStatusWithAggregatesFilter<$PrismaModel> | $Enums.UploadStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUploadStatusFilter<$PrismaModel>
    _max?: NestedEnumUploadStatusFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }
  export type NestedJsonFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> = 
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketplaceApprovalStatus | EnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel> | $Enums.MarketplaceApprovalStatus
  }

  export type NestedEnumMarketplaceApprovalStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MarketplaceApprovalStatus | EnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.MarketplaceApprovalStatus[] | ListEnumMarketplaceApprovalStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumMarketplaceApprovalStatusWithAggregatesFilter<$PrismaModel> | $Enums.MarketplaceApprovalStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel>
    _max?: NestedEnumMarketplaceApprovalStatusFilter<$PrismaModel>
  }

  export type NestedEnumPublishStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PublishStatus | EnumPublishStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPublishStatusFilter<$PrismaModel> | $Enums.PublishStatus
  }

  export type NestedEnumPublishStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PublishStatus | EnumPublishStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PublishStatus[] | ListEnumPublishStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPublishStatusWithAggregatesFilter<$PrismaModel> | $Enums.PublishStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPublishStatusFilter<$PrismaModel>
    _max?: NestedEnumPublishStatusFilter<$PrismaModel>
  }

  export type NestedEnumAuthorizationRelationFilter<$PrismaModel = never> = {
    equals?: $Enums.AuthorizationRelation | EnumAuthorizationRelationFieldRefInput<$PrismaModel>
    in?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    notIn?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    not?: NestedEnumAuthorizationRelationFilter<$PrismaModel> | $Enums.AuthorizationRelation
  }

  export type NestedEnumAuthorizationRelationWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.AuthorizationRelation | EnumAuthorizationRelationFieldRefInput<$PrismaModel>
    in?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    notIn?: $Enums.AuthorizationRelation[] | ListEnumAuthorizationRelationFieldRefInput<$PrismaModel>
    not?: NestedEnumAuthorizationRelationWithAggregatesFilter<$PrismaModel> | $Enums.AuthorizationRelation
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumAuthorizationRelationFilter<$PrismaModel>
    _max?: NestedEnumAuthorizationRelationFilter<$PrismaModel>
  }

  export type NestedEnumDomainStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumDomainStatusFilter<$PrismaModel> | $Enums.DomainStatus
  }

  export type NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.DomainStatus[] | ListEnumDomainStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel> | $Enums.DomainStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDomainStatusFilter<$PrismaModel>
    _max?: NestedEnumDomainStatusFilter<$PrismaModel>
  }

  export type UserCreateWithoutTeamInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    projects?: ProjectCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesCreateNestedManyWithoutUserInput
    checkout?: TransactionLogCreateNestedManyWithoutUserInput
    products?: UserProductCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutTeamInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    projects?: ProjectUncheckedCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesUncheckedCreateNestedManyWithoutUserInput
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutUserInput
    products?: UserProductUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutTeamInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput>
  }

  export type UserCreateManyTeamInputEnvelope = {
    data: UserCreateManyTeamInput | UserCreateManyTeamInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithWhereUniqueWithoutTeamInput = {
    where: UserWhereUniqueInput
    update: XOR<UserUpdateWithoutTeamInput, UserUncheckedUpdateWithoutTeamInput>
    create: XOR<UserCreateWithoutTeamInput, UserUncheckedCreateWithoutTeamInput>
  }

  export type UserUpdateWithWhereUniqueWithoutTeamInput = {
    where: UserWhereUniqueInput
    data: XOR<UserUpdateWithoutTeamInput, UserUncheckedUpdateWithoutTeamInput>
  }

  export type UserUpdateManyWithWhereWithoutTeamInput = {
    where: UserScalarWhereInput
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyWithoutTeamInput>
  }

  export type UserScalarWhereInput = {
    AND?: UserScalarWhereInput | UserScalarWhereInput[]
    OR?: UserScalarWhereInput[]
    NOT?: UserScalarWhereInput | UserScalarWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringNullableFilter<"User"> | string | null
    provider?: StringNullableFilter<"User"> | string | null
    image?: StringNullableFilter<"User"> | string | null
    username?: StringNullableFilter<"User"> | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    teamId?: StringNullableFilter<"User"> | string | null
  }

  export type ProjectCreateWithoutFilesInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutFilesInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutFilesInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutFilesInput, ProjectUncheckedCreateWithoutFilesInput>
  }

  export type AssetCreateWithoutFileInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
    Project?: ProjectCreateNestedManyWithoutPreviewImageAssetInput
    DashboardProject?: DashboardProjectCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetUncheckedCreateWithoutFileInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
    Project?: ProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
    DashboardProject?: DashboardProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetCreateOrConnectWithoutFileInput = {
    where: AssetWhereUniqueInput
    create: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput>
  }

  export type AssetCreateManyFileInputEnvelope = {
    data: AssetCreateManyFileInput | AssetCreateManyFileInput[]
    skipDuplicates?: boolean
  }

  export type ProjectUpsertWithoutFilesInput = {
    update: XOR<ProjectUpdateWithoutFilesInput, ProjectUncheckedUpdateWithoutFilesInput>
    create: XOR<ProjectCreateWithoutFilesInput, ProjectUncheckedCreateWithoutFilesInput>
    where?: ProjectWhereInput
  }

  export type ProjectUpdateToOneWithWhereWithoutFilesInput = {
    where?: ProjectWhereInput
    data: XOR<ProjectUpdateWithoutFilesInput, ProjectUncheckedUpdateWithoutFilesInput>
  }

  export type ProjectUpdateWithoutFilesInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type AssetUpsertWithWhereUniqueWithoutFileInput = {
    where: AssetWhereUniqueInput
    update: XOR<AssetUpdateWithoutFileInput, AssetUncheckedUpdateWithoutFileInput>
    create: XOR<AssetCreateWithoutFileInput, AssetUncheckedCreateWithoutFileInput>
  }

  export type AssetUpdateWithWhereUniqueWithoutFileInput = {
    where: AssetWhereUniqueInput
    data: XOR<AssetUpdateWithoutFileInput, AssetUncheckedUpdateWithoutFileInput>
  }

  export type AssetUpdateManyWithWhereWithoutFileInput = {
    where: AssetScalarWhereInput
    data: XOR<AssetUpdateManyMutationInput, AssetUncheckedUpdateManyWithoutFileInput>
  }

  export type AssetScalarWhereInput = {
    AND?: AssetScalarWhereInput | AssetScalarWhereInput[]
    OR?: AssetScalarWhereInput[]
    NOT?: AssetScalarWhereInput | AssetScalarWhereInput[]
    id?: StringFilter<"Asset"> | string
    projectId?: StringFilter<"Asset"> | string
    name?: StringFilter<"Asset"> | string
    filename?: StringNullableFilter<"Asset"> | string | null
    description?: StringNullableFilter<"Asset"> | string | null
  }

  export type FileCreateWithoutAssetsInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    uploaderProject?: ProjectCreateNestedOneWithoutFilesInput
  }

  export type FileUncheckedCreateWithoutAssetsInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    uploaderProjectId?: string | null
  }

  export type FileCreateOrConnectWithoutAssetsInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutAssetsInput, FileUncheckedCreateWithoutAssetsInput>
  }

  export type ProjectCreateWithoutPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutPreviewImageAssetInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput>
  }

  export type ProjectCreateManyPreviewImageAssetInputEnvelope = {
    data: ProjectCreateManyPreviewImageAssetInput | ProjectCreateManyPreviewImageAssetInput[]
    skipDuplicates?: boolean
  }

  export type DashboardProjectCreateWithoutPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectCreateOrConnectWithoutPreviewImageAssetInput = {
    where: DashboardProjectWhereUniqueInput
    create: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput>
  }

  export type DashboardProjectCreateManyPreviewImageAssetInputEnvelope = {
    data: DashboardProjectCreateManyPreviewImageAssetInput | DashboardProjectCreateManyPreviewImageAssetInput[]
    skipDuplicates?: boolean
  }

  export type FileUpsertWithoutAssetsInput = {
    update: XOR<FileUpdateWithoutAssetsInput, FileUncheckedUpdateWithoutAssetsInput>
    create: XOR<FileCreateWithoutAssetsInput, FileUncheckedCreateWithoutAssetsInput>
    where?: FileWhereInput
  }

  export type FileUpdateToOneWithWhereWithoutAssetsInput = {
    where?: FileWhereInput
    data: XOR<FileUpdateWithoutAssetsInput, FileUncheckedUpdateWithoutAssetsInput>
  }

  export type FileUpdateWithoutAssetsInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    uploaderProject?: ProjectUpdateOneWithoutFilesNestedInput
  }

  export type FileUncheckedUpdateWithoutAssetsInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    uploaderProjectId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput = {
    where: ProjectWhereUniqueInput
    update: XOR<ProjectUpdateWithoutPreviewImageAssetInput, ProjectUncheckedUpdateWithoutPreviewImageAssetInput>
    create: XOR<ProjectCreateWithoutPreviewImageAssetInput, ProjectUncheckedCreateWithoutPreviewImageAssetInput>
  }

  export type ProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput = {
    where: ProjectWhereUniqueInput
    data: XOR<ProjectUpdateWithoutPreviewImageAssetInput, ProjectUncheckedUpdateWithoutPreviewImageAssetInput>
  }

  export type ProjectUpdateManyWithWhereWithoutPreviewImageAssetInput = {
    where: ProjectScalarWhereInput
    data: XOR<ProjectUpdateManyMutationInput, ProjectUncheckedUpdateManyWithoutPreviewImageAssetInput>
  }

  export type ProjectScalarWhereInput = {
    AND?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
    OR?: ProjectScalarWhereInput[]
    NOT?: ProjectScalarWhereInput | ProjectScalarWhereInput[]
    id?: StringFilter<"Project"> | string
    createdAt?: DateTimeFilter<"Project"> | Date | string
    title?: StringFilter<"Project"> | string
    domain?: StringFilter<"Project"> | string
    userId?: StringNullableFilter<"Project"> | string | null
    isDeleted?: BoolFilter<"Project"> | boolean
    previewImageAssetId?: StringNullableFilter<"Project"> | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"Project"> | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUpsertWithWhereUniqueWithoutPreviewImageAssetInput = {
    where: DashboardProjectWhereUniqueInput
    update: XOR<DashboardProjectUpdateWithoutPreviewImageAssetInput, DashboardProjectUncheckedUpdateWithoutPreviewImageAssetInput>
    create: XOR<DashboardProjectCreateWithoutPreviewImageAssetInput, DashboardProjectUncheckedCreateWithoutPreviewImageAssetInput>
  }

  export type DashboardProjectUpdateWithWhereUniqueWithoutPreviewImageAssetInput = {
    where: DashboardProjectWhereUniqueInput
    data: XOR<DashboardProjectUpdateWithoutPreviewImageAssetInput, DashboardProjectUncheckedUpdateWithoutPreviewImageAssetInput>
  }

  export type DashboardProjectUpdateManyWithWhereWithoutPreviewImageAssetInput = {
    where: DashboardProjectScalarWhereInput
    data: XOR<DashboardProjectUpdateManyMutationInput, DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetInput>
  }

  export type DashboardProjectScalarWhereInput = {
    AND?: DashboardProjectScalarWhereInput | DashboardProjectScalarWhereInput[]
    OR?: DashboardProjectScalarWhereInput[]
    NOT?: DashboardProjectScalarWhereInput | DashboardProjectScalarWhereInput[]
    id?: StringFilter<"DashboardProject"> | string
    createdAt?: DateTimeFilter<"DashboardProject"> | Date | string
    title?: StringFilter<"DashboardProject"> | string
    domain?: StringFilter<"DashboardProject"> | string
    userId?: StringNullableFilter<"DashboardProject"> | string | null
    previewImageAssetId?: StringNullableFilter<"DashboardProject"> | string | null
    isDeleted?: BoolFilter<"DashboardProject"> | boolean
    isPublished?: BoolFilter<"DashboardProject"> | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFilter<"DashboardProject"> | $Enums.MarketplaceApprovalStatus
  }

  export type TeamCreateWithoutUsersInput = {
    id?: string
  }

  export type TeamUncheckedCreateWithoutUsersInput = {
    id?: string
  }

  export type TeamCreateOrConnectWithoutUsersInput = {
    where: TeamWhereUniqueInput
    create: XOR<TeamCreateWithoutUsersInput, TeamUncheckedCreateWithoutUsersInput>
  }

  export type ProjectCreateWithoutUserInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutUserInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutUserInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput>
  }

  export type ProjectCreateManyUserInputEnvelope = {
    data: ProjectCreateManyUserInput | ProjectCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ClientReferencesCreateWithoutUserInput = {
    reference?: string
    service: string
    createdAt?: Date | string
  }

  export type ClientReferencesUncheckedCreateWithoutUserInput = {
    reference?: string
    service: string
    createdAt?: Date | string
  }

  export type ClientReferencesCreateOrConnectWithoutUserInput = {
    where: ClientReferencesWhereUniqueInput
    create: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput>
  }

  export type ClientReferencesCreateManyUserInputEnvelope = {
    data: ClientReferencesCreateManyUserInput | ClientReferencesCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type TransactionLogCreateWithoutUserInput = {
    eventId: string
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
    product?: ProductCreateNestedOneWithoutCheckoutInput
  }

  export type TransactionLogUncheckedCreateWithoutUserInput = {
    eventId: string
    productId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type TransactionLogCreateOrConnectWithoutUserInput = {
    where: TransactionLogWhereUniqueInput
    create: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput>
  }

  export type TransactionLogCreateManyUserInputEnvelope = {
    data: TransactionLogCreateManyUserInput | TransactionLogCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type UserProductCreateWithoutUserInput = {
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
    product: ProductCreateNestedOneWithoutUserProductsInput
  }

  export type UserProductUncheckedCreateWithoutUserInput = {
    productId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type UserProductCreateOrConnectWithoutUserInput = {
    where: UserProductWhereUniqueInput
    create: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput>
  }

  export type UserProductCreateManyUserInputEnvelope = {
    data: UserProductCreateManyUserInput | UserProductCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type TeamUpsertWithoutUsersInput = {
    update: XOR<TeamUpdateWithoutUsersInput, TeamUncheckedUpdateWithoutUsersInput>
    create: XOR<TeamCreateWithoutUsersInput, TeamUncheckedCreateWithoutUsersInput>
    where?: TeamWhereInput
  }

  export type TeamUpdateToOneWithWhereWithoutUsersInput = {
    where?: TeamWhereInput
    data: XOR<TeamUpdateWithoutUsersInput, TeamUncheckedUpdateWithoutUsersInput>
  }

  export type TeamUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type TeamUncheckedUpdateWithoutUsersInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ProjectUpsertWithWhereUniqueWithoutUserInput = {
    where: ProjectWhereUniqueInput
    update: XOR<ProjectUpdateWithoutUserInput, ProjectUncheckedUpdateWithoutUserInput>
    create: XOR<ProjectCreateWithoutUserInput, ProjectUncheckedCreateWithoutUserInput>
  }

  export type ProjectUpdateWithWhereUniqueWithoutUserInput = {
    where: ProjectWhereUniqueInput
    data: XOR<ProjectUpdateWithoutUserInput, ProjectUncheckedUpdateWithoutUserInput>
  }

  export type ProjectUpdateManyWithWhereWithoutUserInput = {
    where: ProjectScalarWhereInput
    data: XOR<ProjectUpdateManyMutationInput, ProjectUncheckedUpdateManyWithoutUserInput>
  }

  export type ClientReferencesUpsertWithWhereUniqueWithoutUserInput = {
    where: ClientReferencesWhereUniqueInput
    update: XOR<ClientReferencesUpdateWithoutUserInput, ClientReferencesUncheckedUpdateWithoutUserInput>
    create: XOR<ClientReferencesCreateWithoutUserInput, ClientReferencesUncheckedCreateWithoutUserInput>
  }

  export type ClientReferencesUpdateWithWhereUniqueWithoutUserInput = {
    where: ClientReferencesWhereUniqueInput
    data: XOR<ClientReferencesUpdateWithoutUserInput, ClientReferencesUncheckedUpdateWithoutUserInput>
  }

  export type ClientReferencesUpdateManyWithWhereWithoutUserInput = {
    where: ClientReferencesScalarWhereInput
    data: XOR<ClientReferencesUpdateManyMutationInput, ClientReferencesUncheckedUpdateManyWithoutUserInput>
  }

  export type ClientReferencesScalarWhereInput = {
    AND?: ClientReferencesScalarWhereInput | ClientReferencesScalarWhereInput[]
    OR?: ClientReferencesScalarWhereInput[]
    NOT?: ClientReferencesScalarWhereInput | ClientReferencesScalarWhereInput[]
    reference?: StringFilter<"ClientReferences"> | string
    service?: StringFilter<"ClientReferences"> | string
    createdAt?: DateTimeFilter<"ClientReferences"> | Date | string
    userId?: StringFilter<"ClientReferences"> | string
  }

  export type TransactionLogUpsertWithWhereUniqueWithoutUserInput = {
    where: TransactionLogWhereUniqueInput
    update: XOR<TransactionLogUpdateWithoutUserInput, TransactionLogUncheckedUpdateWithoutUserInput>
    create: XOR<TransactionLogCreateWithoutUserInput, TransactionLogUncheckedCreateWithoutUserInput>
  }

  export type TransactionLogUpdateWithWhereUniqueWithoutUserInput = {
    where: TransactionLogWhereUniqueInput
    data: XOR<TransactionLogUpdateWithoutUserInput, TransactionLogUncheckedUpdateWithoutUserInput>
  }

  export type TransactionLogUpdateManyWithWhereWithoutUserInput = {
    where: TransactionLogScalarWhereInput
    data: XOR<TransactionLogUpdateManyMutationInput, TransactionLogUncheckedUpdateManyWithoutUserInput>
  }

  export type TransactionLogScalarWhereInput = {
    AND?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
    OR?: TransactionLogScalarWhereInput[]
    NOT?: TransactionLogScalarWhereInput | TransactionLogScalarWhereInput[]
    eventId?: StringFilter<"TransactionLog"> | string
    userId?: StringNullableFilter<"TransactionLog"> | string | null
    productId?: StringNullableFilter<"TransactionLog"> | string | null
    createdAt?: DateTimeFilter<"TransactionLog"> | Date | string
    eventData?: JsonNullableFilter<"TransactionLog">
    eventType?: StringNullableFilter<"TransactionLog"> | string | null
    eventCreated?: IntNullableFilter<"TransactionLog"> | number | null
    status?: StringNullableFilter<"TransactionLog"> | string | null
    customerId?: StringNullableFilter<"TransactionLog"> | string | null
    customerEmail?: StringNullableFilter<"TransactionLog"> | string | null
    subscriptionId?: StringNullableFilter<"TransactionLog"> | string | null
    paymentIntent?: StringNullableFilter<"TransactionLog"> | string | null
  }

  export type UserProductUpsertWithWhereUniqueWithoutUserInput = {
    where: UserProductWhereUniqueInput
    update: XOR<UserProductUpdateWithoutUserInput, UserProductUncheckedUpdateWithoutUserInput>
    create: XOR<UserProductCreateWithoutUserInput, UserProductUncheckedCreateWithoutUserInput>
  }

  export type UserProductUpdateWithWhereUniqueWithoutUserInput = {
    where: UserProductWhereUniqueInput
    data: XOR<UserProductUpdateWithoutUserInput, UserProductUncheckedUpdateWithoutUserInput>
  }

  export type UserProductUpdateManyWithWhereWithoutUserInput = {
    where: UserProductScalarWhereInput
    data: XOR<UserProductUpdateManyMutationInput, UserProductUncheckedUpdateManyWithoutUserInput>
  }

  export type UserProductScalarWhereInput = {
    AND?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
    OR?: UserProductScalarWhereInput[]
    NOT?: UserProductScalarWhereInput | UserProductScalarWhereInput[]
    userId?: StringFilter<"UserProduct"> | string
    productId?: StringFilter<"UserProduct"> | string
    subscriptionId?: StringNullableFilter<"UserProduct"> | string | null
    customerId?: StringNullableFilter<"UserProduct"> | string | null
    customerEmail?: StringNullableFilter<"UserProduct"> | string | null
  }

  export type UserCreateWithoutClientReferencesInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    team?: TeamCreateNestedOneWithoutUsersInput
    projects?: ProjectCreateNestedManyWithoutUserInput
    checkout?: TransactionLogCreateNestedManyWithoutUserInput
    products?: UserProductCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutClientReferencesInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
    projects?: ProjectUncheckedCreateNestedManyWithoutUserInput
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutUserInput
    products?: UserProductUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutClientReferencesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutClientReferencesInput, UserUncheckedCreateWithoutClientReferencesInput>
  }

  export type UserUpsertWithoutClientReferencesInput = {
    update: XOR<UserUpdateWithoutClientReferencesInput, UserUncheckedUpdateWithoutClientReferencesInput>
    create: XOR<UserCreateWithoutClientReferencesInput, UserUncheckedCreateWithoutClientReferencesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutClientReferencesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutClientReferencesInput, UserUncheckedUpdateWithoutClientReferencesInput>
  }

  export type UserUpdateWithoutClientReferencesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    team?: TeamUpdateOneWithoutUsersNestedInput
    projects?: ProjectUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUpdateManyWithoutUserNestedInput
    products?: UserProductUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutClientReferencesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
    projects?: ProjectUncheckedUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUncheckedUpdateManyWithoutUserNestedInput
    products?: UserProductUncheckedUpdateManyWithoutUserNestedInput
  }

  export type TransactionLogCreateWithoutProductInput = {
    eventId: string
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
    user?: UserCreateNestedOneWithoutCheckoutInput
  }

  export type TransactionLogUncheckedCreateWithoutProductInput = {
    eventId: string
    userId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type TransactionLogCreateOrConnectWithoutProductInput = {
    where: TransactionLogWhereUniqueInput
    create: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput>
  }

  export type TransactionLogCreateManyProductInputEnvelope = {
    data: TransactionLogCreateManyProductInput | TransactionLogCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type UserProductCreateWithoutProductInput = {
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
    user: UserCreateNestedOneWithoutProductsInput
  }

  export type UserProductUncheckedCreateWithoutProductInput = {
    userId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type UserProductCreateOrConnectWithoutProductInput = {
    where: UserProductWhereUniqueInput
    create: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput>
  }

  export type UserProductCreateManyProductInputEnvelope = {
    data: UserProductCreateManyProductInput | UserProductCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type TransactionLogUpsertWithWhereUniqueWithoutProductInput = {
    where: TransactionLogWhereUniqueInput
    update: XOR<TransactionLogUpdateWithoutProductInput, TransactionLogUncheckedUpdateWithoutProductInput>
    create: XOR<TransactionLogCreateWithoutProductInput, TransactionLogUncheckedCreateWithoutProductInput>
  }

  export type TransactionLogUpdateWithWhereUniqueWithoutProductInput = {
    where: TransactionLogWhereUniqueInput
    data: XOR<TransactionLogUpdateWithoutProductInput, TransactionLogUncheckedUpdateWithoutProductInput>
  }

  export type TransactionLogUpdateManyWithWhereWithoutProductInput = {
    where: TransactionLogScalarWhereInput
    data: XOR<TransactionLogUpdateManyMutationInput, TransactionLogUncheckedUpdateManyWithoutProductInput>
  }

  export type UserProductUpsertWithWhereUniqueWithoutProductInput = {
    where: UserProductWhereUniqueInput
    update: XOR<UserProductUpdateWithoutProductInput, UserProductUncheckedUpdateWithoutProductInput>
    create: XOR<UserProductCreateWithoutProductInput, UserProductUncheckedCreateWithoutProductInput>
  }

  export type UserProductUpdateWithWhereUniqueWithoutProductInput = {
    where: UserProductWhereUniqueInput
    data: XOR<UserProductUpdateWithoutProductInput, UserProductUncheckedUpdateWithoutProductInput>
  }

  export type UserProductUpdateManyWithWhereWithoutProductInput = {
    where: UserProductScalarWhereInput
    data: XOR<UserProductUpdateManyMutationInput, UserProductUncheckedUpdateManyWithoutProductInput>
  }

  export type UserCreateWithoutCheckoutInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    team?: TeamCreateNestedOneWithoutUsersInput
    projects?: ProjectCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesCreateNestedManyWithoutUserInput
    products?: UserProductCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutCheckoutInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
    projects?: ProjectUncheckedCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesUncheckedCreateNestedManyWithoutUserInput
    products?: UserProductUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutCheckoutInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCheckoutInput, UserUncheckedCreateWithoutCheckoutInput>
  }

  export type ProductCreateWithoutCheckoutInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    userProducts?: UserProductCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutCheckoutInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    userProducts?: UserProductUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutCheckoutInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutCheckoutInput, ProductUncheckedCreateWithoutCheckoutInput>
  }

  export type UserUpsertWithoutCheckoutInput = {
    update: XOR<UserUpdateWithoutCheckoutInput, UserUncheckedUpdateWithoutCheckoutInput>
    create: XOR<UserCreateWithoutCheckoutInput, UserUncheckedCreateWithoutCheckoutInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCheckoutInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCheckoutInput, UserUncheckedUpdateWithoutCheckoutInput>
  }

  export type UserUpdateWithoutCheckoutInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    team?: TeamUpdateOneWithoutUsersNestedInput
    projects?: ProjectUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUpdateManyWithoutUserNestedInput
    products?: UserProductUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutCheckoutInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
    projects?: ProjectUncheckedUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUncheckedUpdateManyWithoutUserNestedInput
    products?: UserProductUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ProductUpsertWithoutCheckoutInput = {
    update: XOR<ProductUpdateWithoutCheckoutInput, ProductUncheckedUpdateWithoutCheckoutInput>
    create: XOR<ProductCreateWithoutCheckoutInput, ProductUncheckedCreateWithoutCheckoutInput>
    where?: ProductWhereInput
  }

  export type ProductUpdateToOneWithWhereWithoutCheckoutInput = {
    where?: ProductWhereInput
    data: XOR<ProductUpdateWithoutCheckoutInput, ProductUncheckedUpdateWithoutCheckoutInput>
  }

  export type ProductUpdateWithoutCheckoutInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userProducts?: UserProductUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutCheckoutInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userProducts?: UserProductUncheckedUpdateManyWithoutProductNestedInput
  }

  export type UserCreateWithoutProjectsInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    team?: TeamCreateNestedOneWithoutUsersInput
    clientReferences?: ClientReferencesCreateNestedManyWithoutUserInput
    checkout?: TransactionLogCreateNestedManyWithoutUserInput
    products?: UserProductCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutProjectsInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
    clientReferences?: ClientReferencesUncheckedCreateNestedManyWithoutUserInput
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutUserInput
    products?: UserProductUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutProjectsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutProjectsInput, UserUncheckedCreateWithoutProjectsInput>
  }

  export type BuildCreateWithoutProjectInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectCreateNestedOneWithoutBuildInput
  }

  export type BuildUncheckedCreateWithoutProjectInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutBuildInput
  }

  export type BuildCreateOrConnectWithoutProjectInput = {
    where: BuildWhereUniqueInput
    create: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput>
  }

  export type BuildCreateManyProjectInputEnvelope = {
    data: BuildCreateManyProjectInput | BuildCreateManyProjectInput[]
    skipDuplicates?: boolean
  }

  export type FileCreateWithoutUploaderProjectInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    assets?: AssetCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutUploaderProjectInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
    assets?: AssetUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutUploaderProjectInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput>
  }

  export type FileCreateManyUploaderProjectInputEnvelope = {
    data: FileCreateManyUploaderProjectInput | FileCreateManyUploaderProjectInput[]
    skipDuplicates?: boolean
  }

  export type ProjectDomainCreateWithoutProjectInput = {
    createdAt?: Date | string
    txtRecord?: string
    cname: string
    domain: DomainCreateNestedOneWithoutProjectDomainInput
  }

  export type ProjectDomainUncheckedCreateWithoutProjectInput = {
    domainId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type ProjectDomainCreateOrConnectWithoutProjectInput = {
    where: ProjectDomainWhereUniqueInput
    create: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput>
  }

  export type ProjectDomainCreateManyProjectInputEnvelope = {
    data: ProjectDomainCreateManyProjectInput | ProjectDomainCreateManyProjectInput[]
    skipDuplicates?: boolean
  }

  export type AuthorizationTokenCreateWithoutProjectInput = {
    token?: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
  }

  export type AuthorizationTokenUncheckedCreateWithoutProjectInput = {
    token?: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
  }

  export type AuthorizationTokenCreateOrConnectWithoutProjectInput = {
    where: AuthorizationTokenWhereUniqueInput
    create: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput>
  }

  export type AuthorizationTokenCreateManyProjectInputEnvelope = {
    data: AuthorizationTokenCreateManyProjectInput | AuthorizationTokenCreateManyProjectInput[]
    skipDuplicates?: boolean
  }

  export type AssetCreateWithoutProjectInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
    file: FileCreateNestedOneWithoutAssetsInput
    DashboardProject?: DashboardProjectCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetUncheckedCreateWithoutProjectInput = {
    id?: string
    projectId: string
    name: string
    filename?: string | null
    description?: string | null
    DashboardProject?: DashboardProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetCreateOrConnectWithoutProjectInput = {
    where: AssetWhereUniqueInput
    create: XOR<AssetCreateWithoutProjectInput, AssetUncheckedCreateWithoutProjectInput>
  }

  export type LatestStaticBuildPerProjectCreateWithoutProjectInput = {
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
    build: BuildCreateNestedOneWithoutLatestStaticBuildPerProjectInput
  }

  export type LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput = {
    buildId: string
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
  }

  export type LatestStaticBuildPerProjectCreateOrConnectWithoutProjectInput = {
    where: LatestStaticBuildPerProjectWhereUniqueInput
    create: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
  }

  export type UserUpsertWithoutProjectsInput = {
    update: XOR<UserUpdateWithoutProjectsInput, UserUncheckedUpdateWithoutProjectsInput>
    create: XOR<UserCreateWithoutProjectsInput, UserUncheckedCreateWithoutProjectsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutProjectsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutProjectsInput, UserUncheckedUpdateWithoutProjectsInput>
  }

  export type UserUpdateWithoutProjectsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    team?: TeamUpdateOneWithoutUsersNestedInput
    clientReferences?: ClientReferencesUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUpdateManyWithoutUserNestedInput
    products?: UserProductUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutProjectsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
    clientReferences?: ClientReferencesUncheckedUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUncheckedUpdateManyWithoutUserNestedInput
    products?: UserProductUncheckedUpdateManyWithoutUserNestedInput
  }

  export type BuildUpsertWithWhereUniqueWithoutProjectInput = {
    where: BuildWhereUniqueInput
    update: XOR<BuildUpdateWithoutProjectInput, BuildUncheckedUpdateWithoutProjectInput>
    create: XOR<BuildCreateWithoutProjectInput, BuildUncheckedCreateWithoutProjectInput>
  }

  export type BuildUpdateWithWhereUniqueWithoutProjectInput = {
    where: BuildWhereUniqueInput
    data: XOR<BuildUpdateWithoutProjectInput, BuildUncheckedUpdateWithoutProjectInput>
  }

  export type BuildUpdateManyWithWhereWithoutProjectInput = {
    where: BuildScalarWhereInput
    data: XOR<BuildUpdateManyMutationInput, BuildUncheckedUpdateManyWithoutProjectInput>
  }

  export type BuildScalarWhereInput = {
    AND?: BuildScalarWhereInput | BuildScalarWhereInput[]
    OR?: BuildScalarWhereInput[]
    NOT?: BuildScalarWhereInput | BuildScalarWhereInput[]
    id?: StringFilter<"Build"> | string
    version?: IntFilter<"Build"> | number
    lastTransactionId?: StringNullableFilter<"Build"> | string | null
    createdAt?: DateTimeFilter<"Build"> | Date | string
    updatedAt?: DateTimeFilter<"Build"> | Date | string
    pages?: StringFilter<"Build"> | string
    projectId?: StringFilter<"Build"> | string
    breakpoints?: StringFilter<"Build"> | string
    styles?: StringFilter<"Build"> | string
    styleSources?: StringFilter<"Build"> | string
    styleSourceSelections?: StringFilter<"Build"> | string
    props?: StringFilter<"Build"> | string
    dataSources?: StringFilter<"Build"> | string
    resources?: StringFilter<"Build"> | string
    instances?: StringFilter<"Build"> | string
    marketplaceProduct?: StringFilter<"Build"> | string
    deployment?: StringNullableFilter<"Build"> | string | null
    publishStatus?: EnumPublishStatusFilter<"Build"> | $Enums.PublishStatus
  }

  export type FileUpsertWithWhereUniqueWithoutUploaderProjectInput = {
    where: FileWhereUniqueInput
    update: XOR<FileUpdateWithoutUploaderProjectInput, FileUncheckedUpdateWithoutUploaderProjectInput>
    create: XOR<FileCreateWithoutUploaderProjectInput, FileUncheckedCreateWithoutUploaderProjectInput>
  }

  export type FileUpdateWithWhereUniqueWithoutUploaderProjectInput = {
    where: FileWhereUniqueInput
    data: XOR<FileUpdateWithoutUploaderProjectInput, FileUncheckedUpdateWithoutUploaderProjectInput>
  }

  export type FileUpdateManyWithWhereWithoutUploaderProjectInput = {
    where: FileScalarWhereInput
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyWithoutUploaderProjectInput>
  }

  export type FileScalarWhereInput = {
    AND?: FileScalarWhereInput | FileScalarWhereInput[]
    OR?: FileScalarWhereInput[]
    NOT?: FileScalarWhereInput | FileScalarWhereInput[]
    name?: StringFilter<"File"> | string
    format?: StringFilter<"File"> | string
    size?: IntFilter<"File"> | number
    description?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    updatedAt?: DateTimeFilter<"File"> | Date | string
    meta?: StringFilter<"File"> | string
    status?: EnumUploadStatusFilter<"File"> | $Enums.UploadStatus
    isDeleted?: BoolFilter<"File"> | boolean
    uploaderProjectId?: StringNullableFilter<"File"> | string | null
  }

  export type ProjectDomainUpsertWithWhereUniqueWithoutProjectInput = {
    where: ProjectDomainWhereUniqueInput
    update: XOR<ProjectDomainUpdateWithoutProjectInput, ProjectDomainUncheckedUpdateWithoutProjectInput>
    create: XOR<ProjectDomainCreateWithoutProjectInput, ProjectDomainUncheckedCreateWithoutProjectInput>
  }

  export type ProjectDomainUpdateWithWhereUniqueWithoutProjectInput = {
    where: ProjectDomainWhereUniqueInput
    data: XOR<ProjectDomainUpdateWithoutProjectInput, ProjectDomainUncheckedUpdateWithoutProjectInput>
  }

  export type ProjectDomainUpdateManyWithWhereWithoutProjectInput = {
    where: ProjectDomainScalarWhereInput
    data: XOR<ProjectDomainUpdateManyMutationInput, ProjectDomainUncheckedUpdateManyWithoutProjectInput>
  }

  export type ProjectDomainScalarWhereInput = {
    AND?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
    OR?: ProjectDomainScalarWhereInput[]
    NOT?: ProjectDomainScalarWhereInput | ProjectDomainScalarWhereInput[]
    projectId?: StringFilter<"ProjectDomain"> | string
    domainId?: StringFilter<"ProjectDomain"> | string
    createdAt?: DateTimeFilter<"ProjectDomain"> | Date | string
    txtRecord?: StringFilter<"ProjectDomain"> | string
    cname?: StringFilter<"ProjectDomain"> | string
  }

  export type AuthorizationTokenUpsertWithWhereUniqueWithoutProjectInput = {
    where: AuthorizationTokenWhereUniqueInput
    update: XOR<AuthorizationTokenUpdateWithoutProjectInput, AuthorizationTokenUncheckedUpdateWithoutProjectInput>
    create: XOR<AuthorizationTokenCreateWithoutProjectInput, AuthorizationTokenUncheckedCreateWithoutProjectInput>
  }

  export type AuthorizationTokenUpdateWithWhereUniqueWithoutProjectInput = {
    where: AuthorizationTokenWhereUniqueInput
    data: XOR<AuthorizationTokenUpdateWithoutProjectInput, AuthorizationTokenUncheckedUpdateWithoutProjectInput>
  }

  export type AuthorizationTokenUpdateManyWithWhereWithoutProjectInput = {
    where: AuthorizationTokenScalarWhereInput
    data: XOR<AuthorizationTokenUpdateManyMutationInput, AuthorizationTokenUncheckedUpdateManyWithoutProjectInput>
  }

  export type AuthorizationTokenScalarWhereInput = {
    AND?: AuthorizationTokenScalarWhereInput | AuthorizationTokenScalarWhereInput[]
    OR?: AuthorizationTokenScalarWhereInput[]
    NOT?: AuthorizationTokenScalarWhereInput | AuthorizationTokenScalarWhereInput[]
    token?: StringFilter<"AuthorizationToken"> | string
    projectId?: StringFilter<"AuthorizationToken"> | string
    name?: StringFilter<"AuthorizationToken"> | string
    relation?: EnumAuthorizationRelationFilter<"AuthorizationToken"> | $Enums.AuthorizationRelation
    createdAt?: DateTimeFilter<"AuthorizationToken"> | Date | string
    canClone?: BoolFilter<"AuthorizationToken"> | boolean
    canCopy?: BoolFilter<"AuthorizationToken"> | boolean
  }

  export type AssetUpsertWithoutProjectInput = {
    update: XOR<AssetUpdateWithoutProjectInput, AssetUncheckedUpdateWithoutProjectInput>
    create: XOR<AssetCreateWithoutProjectInput, AssetUncheckedCreateWithoutProjectInput>
    where?: AssetWhereInput
  }

  export type AssetUpdateToOneWithWhereWithoutProjectInput = {
    where?: AssetWhereInput
    data: XOR<AssetUpdateWithoutProjectInput, AssetUncheckedUpdateWithoutProjectInput>
  }

  export type AssetUpdateWithoutProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    file?: FileUpdateOneRequiredWithoutAssetsNestedInput
    DashboardProject?: DashboardProjectUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetUncheckedUpdateWithoutProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    DashboardProject?: DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type LatestStaticBuildPerProjectUpsertWithoutProjectInput = {
    update: XOR<LatestStaticBuildPerProjectUpdateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedUpdateWithoutProjectInput>
    create: XOR<LatestStaticBuildPerProjectCreateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedCreateWithoutProjectInput>
    where?: LatestStaticBuildPerProjectWhereInput
  }

  export type LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutProjectInput = {
    where?: LatestStaticBuildPerProjectWhereInput
    data: XOR<LatestStaticBuildPerProjectUpdateWithoutProjectInput, LatestStaticBuildPerProjectUncheckedUpdateWithoutProjectInput>
  }

  export type LatestStaticBuildPerProjectUpdateWithoutProjectInput = {
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    build?: BuildUpdateOneRequiredWithoutLatestStaticBuildPerProjectNestedInput
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateWithoutProjectInput = {
    buildId?: StringFieldUpdateOperationsInput | string
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProjectCreateWithoutBuildInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutBuildInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutBuildInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutBuildInput, ProjectUncheckedCreateWithoutBuildInput>
  }

  export type LatestStaticBuildPerProjectCreateWithoutBuildInput = {
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
    project: ProjectCreateNestedOneWithoutLatestStaticBuildInput
  }

  export type LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput = {
    publishStatus: $Enums.PublishStatus
    updatedAt: Date | string
  }

  export type LatestStaticBuildPerProjectCreateOrConnectWithoutBuildInput = {
    where: LatestStaticBuildPerProjectWhereUniqueInput
    create: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
  }

  export type ProjectUpsertWithoutBuildInput = {
    update: XOR<ProjectUpdateWithoutBuildInput, ProjectUncheckedUpdateWithoutBuildInput>
    create: XOR<ProjectCreateWithoutBuildInput, ProjectUncheckedCreateWithoutBuildInput>
    where?: ProjectWhereInput
  }

  export type ProjectUpdateToOneWithWhereWithoutBuildInput = {
    where?: ProjectWhereInput
    data: XOR<ProjectUpdateWithoutBuildInput, ProjectUncheckedUpdateWithoutBuildInput>
  }

  export type ProjectUpdateWithoutBuildInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutBuildInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type LatestStaticBuildPerProjectUpsertWithoutBuildInput = {
    update: XOR<LatestStaticBuildPerProjectUpdateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedUpdateWithoutBuildInput>
    create: XOR<LatestStaticBuildPerProjectCreateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedCreateWithoutBuildInput>
    where?: LatestStaticBuildPerProjectWhereInput
  }

  export type LatestStaticBuildPerProjectUpdateToOneWithWhereWithoutBuildInput = {
    where?: LatestStaticBuildPerProjectWhereInput
    data: XOR<LatestStaticBuildPerProjectUpdateWithoutBuildInput, LatestStaticBuildPerProjectUncheckedUpdateWithoutBuildInput>
  }

  export type LatestStaticBuildPerProjectUpdateWithoutBuildInput = {
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    project?: ProjectUpdateOneRequiredWithoutLatestStaticBuildNestedInput
  }

  export type LatestStaticBuildPerProjectUncheckedUpdateWithoutBuildInput = {
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProjectCreateWithoutAuthorizationTokenInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutAuthorizationTokenInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutAuthorizationTokenInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutAuthorizationTokenInput, ProjectUncheckedCreateWithoutAuthorizationTokenInput>
  }

  export type ProjectUpsertWithoutAuthorizationTokenInput = {
    update: XOR<ProjectUpdateWithoutAuthorizationTokenInput, ProjectUncheckedUpdateWithoutAuthorizationTokenInput>
    create: XOR<ProjectCreateWithoutAuthorizationTokenInput, ProjectUncheckedCreateWithoutAuthorizationTokenInput>
    where?: ProjectWhereInput
  }

  export type ProjectUpdateToOneWithWhereWithoutAuthorizationTokenInput = {
    where?: ProjectWhereInput
    data: XOR<ProjectUpdateWithoutAuthorizationTokenInput, ProjectUncheckedUpdateWithoutAuthorizationTokenInput>
  }

  export type ProjectUpdateWithoutAuthorizationTokenInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutAuthorizationTokenInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type ProjectDomainCreateWithoutDomainInput = {
    createdAt?: Date | string
    txtRecord?: string
    cname: string
    project: ProjectCreateNestedOneWithoutProjectDomainInput
  }

  export type ProjectDomainUncheckedCreateWithoutDomainInput = {
    projectId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type ProjectDomainCreateOrConnectWithoutDomainInput = {
    where: ProjectDomainWhereUniqueInput
    create: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput>
  }

  export type ProjectDomainCreateManyDomainInputEnvelope = {
    data: ProjectDomainCreateManyDomainInput | ProjectDomainCreateManyDomainInput[]
    skipDuplicates?: boolean
  }

  export type ProjectDomainUpsertWithWhereUniqueWithoutDomainInput = {
    where: ProjectDomainWhereUniqueInput
    update: XOR<ProjectDomainUpdateWithoutDomainInput, ProjectDomainUncheckedUpdateWithoutDomainInput>
    create: XOR<ProjectDomainCreateWithoutDomainInput, ProjectDomainUncheckedCreateWithoutDomainInput>
  }

  export type ProjectDomainUpdateWithWhereUniqueWithoutDomainInput = {
    where: ProjectDomainWhereUniqueInput
    data: XOR<ProjectDomainUpdateWithoutDomainInput, ProjectDomainUncheckedUpdateWithoutDomainInput>
  }

  export type ProjectDomainUpdateManyWithWhereWithoutDomainInput = {
    where: ProjectDomainScalarWhereInput
    data: XOR<ProjectDomainUpdateManyMutationInput, ProjectDomainUncheckedUpdateManyWithoutDomainInput>
  }

  export type ProjectCreateWithoutProjectDomainInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutProjectDomainInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedCreateNestedOneWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutProjectDomainInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutProjectDomainInput, ProjectUncheckedCreateWithoutProjectDomainInput>
  }

  export type DomainCreateWithoutProjectDomainInput = {
    id?: string
    domain: string
    createdAt?: Date | string
    updatedAt?: Date | string
    txtRecord?: string | null
    status?: $Enums.DomainStatus
    error?: string | null
  }

  export type DomainUncheckedCreateWithoutProjectDomainInput = {
    id?: string
    domain: string
    createdAt?: Date | string
    updatedAt?: Date | string
    txtRecord?: string | null
    status?: $Enums.DomainStatus
    error?: string | null
  }

  export type DomainCreateOrConnectWithoutProjectDomainInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutProjectDomainInput, DomainUncheckedCreateWithoutProjectDomainInput>
  }

  export type ProjectUpsertWithoutProjectDomainInput = {
    update: XOR<ProjectUpdateWithoutProjectDomainInput, ProjectUncheckedUpdateWithoutProjectDomainInput>
    create: XOR<ProjectCreateWithoutProjectDomainInput, ProjectUncheckedCreateWithoutProjectDomainInput>
    where?: ProjectWhereInput
  }

  export type ProjectUpdateToOneWithWhereWithoutProjectDomainInput = {
    where?: ProjectWhereInput
    data: XOR<ProjectUpdateWithoutProjectDomainInput, ProjectUncheckedUpdateWithoutProjectDomainInput>
  }

  export type ProjectUpdateWithoutProjectDomainInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutProjectDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type DomainUpsertWithoutProjectDomainInput = {
    update: XOR<DomainUpdateWithoutProjectDomainInput, DomainUncheckedUpdateWithoutProjectDomainInput>
    create: XOR<DomainCreateWithoutProjectDomainInput, DomainUncheckedCreateWithoutProjectDomainInput>
    where?: DomainWhereInput
  }

  export type DomainUpdateToOneWithWhereWithoutProjectDomainInput = {
    where?: DomainWhereInput
    data: XOR<DomainUpdateWithoutProjectDomainInput, DomainUncheckedUpdateWithoutProjectDomainInput>
  }

  export type DomainUpdateWithoutProjectDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUncheckedUpdateWithoutProjectDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    error?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserCreateWithoutProductsInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    team?: TeamCreateNestedOneWithoutUsersInput
    projects?: ProjectCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesCreateNestedManyWithoutUserInput
    checkout?: TransactionLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutProductsInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
    teamId?: string | null
    projects?: ProjectUncheckedCreateNestedManyWithoutUserInput
    clientReferences?: ClientReferencesUncheckedCreateNestedManyWithoutUserInput
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutProductsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutProductsInput, UserUncheckedCreateWithoutProductsInput>
  }

  export type ProductCreateWithoutUserProductsInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    checkout?: TransactionLogCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutUserProductsInput = {
    id: string
    name: string
    description?: string | null
    features?: ProductCreatefeaturesInput | string[]
    images?: ProductCreateimagesInput | string[]
    meta: JsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    checkout?: TransactionLogUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutUserProductsInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutUserProductsInput, ProductUncheckedCreateWithoutUserProductsInput>
  }

  export type UserUpsertWithoutProductsInput = {
    update: XOR<UserUpdateWithoutProductsInput, UserUncheckedUpdateWithoutProductsInput>
    create: XOR<UserCreateWithoutProductsInput, UserUncheckedCreateWithoutProductsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutProductsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutProductsInput, UserUncheckedUpdateWithoutProductsInput>
  }

  export type UserUpdateWithoutProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    team?: TeamUpdateOneWithoutUsersNestedInput
    projects?: ProjectUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    teamId?: NullableStringFieldUpdateOperationsInput | string | null
    projects?: ProjectUncheckedUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUncheckedUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ProductUpsertWithoutUserProductsInput = {
    update: XOR<ProductUpdateWithoutUserProductsInput, ProductUncheckedUpdateWithoutUserProductsInput>
    create: XOR<ProductCreateWithoutUserProductsInput, ProductUncheckedCreateWithoutUserProductsInput>
    where?: ProductWhereInput
  }

  export type ProductUpdateToOneWithWhereWithoutUserProductsInput = {
    where?: ProductWhereInput
    data: XOR<ProductUpdateWithoutUserProductsInput, ProductUncheckedUpdateWithoutUserProductsInput>
  }

  export type ProductUpdateWithoutUserProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    checkout?: TransactionLogUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutUserProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    features?: ProductUpdatefeaturesInput | string[]
    images?: ProductUpdateimagesInput | string[]
    meta?: JsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    checkout?: TransactionLogUncheckedUpdateManyWithoutProductNestedInput
  }

  export type BuildCreateWithoutLatestStaticBuildPerProjectInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
    project: ProjectCreateNestedOneWithoutBuildInput
  }

  export type BuildUncheckedCreateWithoutLatestStaticBuildPerProjectInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    projectId: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
  }

  export type BuildCreateOrConnectWithoutLatestStaticBuildPerProjectInput = {
    where: BuildWhereUniqueInput
    create: XOR<BuildCreateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedCreateWithoutLatestStaticBuildPerProjectInput>
  }

  export type ProjectCreateWithoutLatestStaticBuildInput = {
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    user?: UserCreateNestedOneWithoutProjectsInput
    build?: BuildCreateNestedManyWithoutProjectInput
    files?: FileCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenCreateNestedManyWithoutProjectInput
    previewImageAsset?: AssetCreateNestedOneWithoutProjectInput
  }

  export type ProjectUncheckedCreateWithoutLatestStaticBuildInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedCreateNestedManyWithoutProjectInput
    files?: FileUncheckedCreateNestedManyWithoutUploaderProjectInput
    projectDomain?: ProjectDomainUncheckedCreateNestedManyWithoutProjectInput
    authorizationToken?: AuthorizationTokenUncheckedCreateNestedManyWithoutProjectInput
  }

  export type ProjectCreateOrConnectWithoutLatestStaticBuildInput = {
    where: ProjectWhereUniqueInput
    create: XOR<ProjectCreateWithoutLatestStaticBuildInput, ProjectUncheckedCreateWithoutLatestStaticBuildInput>
  }

  export type BuildUpsertWithoutLatestStaticBuildPerProjectInput = {
    update: XOR<BuildUpdateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedUpdateWithoutLatestStaticBuildPerProjectInput>
    create: XOR<BuildCreateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedCreateWithoutLatestStaticBuildPerProjectInput>
    where?: BuildWhereInput
  }

  export type BuildUpdateToOneWithWhereWithoutLatestStaticBuildPerProjectInput = {
    where?: BuildWhereInput
    data: XOR<BuildUpdateWithoutLatestStaticBuildPerProjectInput, BuildUncheckedUpdateWithoutLatestStaticBuildPerProjectInput>
  }

  export type BuildUpdateWithoutLatestStaticBuildPerProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    project?: ProjectUpdateOneRequiredWithoutBuildNestedInput
  }

  export type BuildUncheckedUpdateWithoutLatestStaticBuildPerProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
  }

  export type ProjectUpsertWithoutLatestStaticBuildInput = {
    update: XOR<ProjectUpdateWithoutLatestStaticBuildInput, ProjectUncheckedUpdateWithoutLatestStaticBuildInput>
    create: XOR<ProjectCreateWithoutLatestStaticBuildInput, ProjectUncheckedCreateWithoutLatestStaticBuildInput>
    where?: ProjectWhereInput
  }

  export type ProjectUpdateToOneWithWhereWithoutLatestStaticBuildInput = {
    where?: ProjectWhereInput
    data: XOR<ProjectUpdateWithoutLatestStaticBuildInput, ProjectUncheckedUpdateWithoutLatestStaticBuildInput>
  }

  export type ProjectUpdateWithoutLatestStaticBuildInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutLatestStaticBuildInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
  }

  export type AssetCreateWithoutDashboardProjectInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
    file: FileCreateNestedOneWithoutAssetsInput
    Project?: ProjectCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetUncheckedCreateWithoutDashboardProjectInput = {
    id?: string
    projectId: string
    name: string
    filename?: string | null
    description?: string | null
    Project?: ProjectUncheckedCreateNestedManyWithoutPreviewImageAssetInput
  }

  export type AssetCreateOrConnectWithoutDashboardProjectInput = {
    where: AssetWhereUniqueInput
    create: XOR<AssetCreateWithoutDashboardProjectInput, AssetUncheckedCreateWithoutDashboardProjectInput>
  }

  export type AssetUpsertWithoutDashboardProjectInput = {
    update: XOR<AssetUpdateWithoutDashboardProjectInput, AssetUncheckedUpdateWithoutDashboardProjectInput>
    create: XOR<AssetCreateWithoutDashboardProjectInput, AssetUncheckedCreateWithoutDashboardProjectInput>
    where?: AssetWhereInput
  }

  export type AssetUpdateToOneWithWhereWithoutDashboardProjectInput = {
    where?: AssetWhereInput
    data: XOR<AssetUpdateWithoutDashboardProjectInput, AssetUncheckedUpdateWithoutDashboardProjectInput>
  }

  export type AssetUpdateWithoutDashboardProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    file?: FileUpdateOneRequiredWithoutAssetsNestedInput
    Project?: ProjectUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetUncheckedUpdateWithoutDashboardProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    Project?: ProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type UserCreateManyTeamInput = {
    id?: string
    email?: string | null
    provider?: string | null
    image?: string | null
    username?: string | null
    createdAt?: Date | string
  }

  export type UserUpdateWithoutTeamInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    projects?: ProjectUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUpdateManyWithoutUserNestedInput
    products?: UserProductUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutTeamInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    projects?: ProjectUncheckedUpdateManyWithoutUserNestedInput
    clientReferences?: ClientReferencesUncheckedUpdateManyWithoutUserNestedInput
    checkout?: TransactionLogUncheckedUpdateManyWithoutUserNestedInput
    products?: UserProductUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateManyWithoutTeamInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    provider?: NullableStringFieldUpdateOperationsInput | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AssetCreateManyFileInput = {
    id?: string
    projectId: string
    filename?: string | null
    description?: string | null
  }

  export type AssetUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    Project?: ProjectUpdateManyWithoutPreviewImageAssetNestedInput
    DashboardProject?: DashboardProjectUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetUncheckedUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    Project?: ProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
    DashboardProject?: DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetNestedInput
  }

  export type AssetUncheckedUpdateManyWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    projectId?: StringFieldUpdateOperationsInput | string
    filename?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ProjectCreateManyPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectCreateManyPreviewImageAssetInput = {
    createdAt?: Date | string
    title: string
    domain: string
    userId?: string | null
    isDeleted?: boolean
    isPublished: boolean
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type ProjectUpdateWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    user?: UserUpdateOneWithoutProjectsNestedInput
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateManyWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUpdateWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUncheckedUpdateWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type DashboardProjectUncheckedUpdateManyWithoutPreviewImageAssetInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    isPublished?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type ProjectCreateManyUserInput = {
    id?: string
    createdAt?: Date | string
    title: string
    domain: string
    isDeleted?: boolean
    previewImageAssetId?: string | null
    marketplaceApprovalStatus?: $Enums.MarketplaceApprovalStatus
  }

  export type ClientReferencesCreateManyUserInput = {
    reference?: string
    service: string
    createdAt?: Date | string
  }

  export type TransactionLogCreateManyUserInput = {
    eventId: string
    productId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type UserProductCreateManyUserInput = {
    productId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type ProjectUpdateWithoutUserInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUpdateManyWithoutProjectNestedInput
    files?: FileUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUpdateManyWithoutProjectNestedInput
    previewImageAsset?: AssetUpdateOneWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
    build?: BuildUncheckedUpdateManyWithoutProjectNestedInput
    files?: FileUncheckedUpdateManyWithoutUploaderProjectNestedInput
    projectDomain?: ProjectDomainUncheckedUpdateManyWithoutProjectNestedInput
    authorizationToken?: AuthorizationTokenUncheckedUpdateManyWithoutProjectNestedInput
    latestStaticBuild?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutProjectNestedInput
  }

  export type ProjectUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    domain?: StringFieldUpdateOperationsInput | string
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    previewImageAssetId?: NullableStringFieldUpdateOperationsInput | string | null
    marketplaceApprovalStatus?: EnumMarketplaceApprovalStatusFieldUpdateOperationsInput | $Enums.MarketplaceApprovalStatus
  }

  export type ClientReferencesUpdateWithoutUserInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClientReferencesUncheckedUpdateWithoutUserInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClientReferencesUncheckedUpdateManyWithoutUserInput = {
    reference?: StringFieldUpdateOperationsInput | string
    service?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionLogUpdateWithoutUserInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductUpdateOneWithoutCheckoutNestedInput
  }

  export type TransactionLogUncheckedUpdateWithoutUserInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type TransactionLogUncheckedUpdateManyWithoutUserInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    productId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductUpdateWithoutUserInput = {
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductUpdateOneRequiredWithoutUserProductsNestedInput
  }

  export type UserProductUncheckedUpdateWithoutUserInput = {
    productId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductUncheckedUpdateManyWithoutUserInput = {
    productId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type TransactionLogCreateManyProductInput = {
    eventId: string
    userId?: string | null
    createdAt?: Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: string | null
    eventCreated?: number | null
    status?: string | null
    customerId?: string | null
    customerEmail?: string | null
    subscriptionId?: string | null
    paymentIntent?: string | null
  }

  export type UserProductCreateManyProductInput = {
    userId: string
    subscriptionId?: string | null
    customerId?: string | null
    customerEmail?: string | null
  }

  export type TransactionLogUpdateWithoutProductInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneWithoutCheckoutNestedInput
  }

  export type TransactionLogUncheckedUpdateWithoutProductInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type TransactionLogUncheckedUpdateManyWithoutProductInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    userId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventData?: NullableJsonNullValueInput | InputJsonValue
    eventType?: NullableStringFieldUpdateOperationsInput | string | null
    eventCreated?: NullableIntFieldUpdateOperationsInput | number | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    paymentIntent?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductUpdateWithoutProductInput = {
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneRequiredWithoutProductsNestedInput
  }

  export type UserProductUncheckedUpdateWithoutProductInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserProductUncheckedUpdateManyWithoutProductInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    customerId?: NullableStringFieldUpdateOperationsInput | string | null
    customerEmail?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type BuildCreateManyProjectInput = {
    id?: string
    version?: number
    lastTransactionId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    pages: string
    breakpoints?: string
    styles?: string
    styleSources?: string
    styleSourceSelections?: string
    props?: string
    dataSources?: string
    resources?: string
    instances?: string
    marketplaceProduct?: string
    deployment?: string | null
    publishStatus?: $Enums.PublishStatus
  }

  export type FileCreateManyUploaderProjectInput = {
    name: string
    format: string
    size: number
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    meta?: string
    status?: $Enums.UploadStatus
    isDeleted?: boolean
  }

  export type ProjectDomainCreateManyProjectInput = {
    domainId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type AuthorizationTokenCreateManyProjectInput = {
    token?: string
    name?: string
    relation?: $Enums.AuthorizationRelation
    createdAt?: Date | string
    canClone?: boolean
    canCopy?: boolean
  }

  export type BuildUpdateWithoutProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUpdateOneWithoutBuildNestedInput
  }

  export type BuildUncheckedUpdateWithoutProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
    latestStaticBuildPerProject?: LatestStaticBuildPerProjectUncheckedUpdateOneWithoutBuildNestedInput
  }

  export type BuildUncheckedUpdateManyWithoutProjectInput = {
    id?: StringFieldUpdateOperationsInput | string
    version?: IntFieldUpdateOperationsInput | number
    lastTransactionId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    pages?: StringFieldUpdateOperationsInput | string
    breakpoints?: StringFieldUpdateOperationsInput | string
    styles?: StringFieldUpdateOperationsInput | string
    styleSources?: StringFieldUpdateOperationsInput | string
    styleSourceSelections?: StringFieldUpdateOperationsInput | string
    props?: StringFieldUpdateOperationsInput | string
    dataSources?: StringFieldUpdateOperationsInput | string
    resources?: StringFieldUpdateOperationsInput | string
    instances?: StringFieldUpdateOperationsInput | string
    marketplaceProduct?: StringFieldUpdateOperationsInput | string
    deployment?: NullableStringFieldUpdateOperationsInput | string | null
    publishStatus?: EnumPublishStatusFieldUpdateOperationsInput | $Enums.PublishStatus
  }

  export type FileUpdateWithoutUploaderProjectInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    assets?: AssetUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutUploaderProjectInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
    assets?: AssetUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateManyWithoutUploaderProjectInput = {
    name?: StringFieldUpdateOperationsInput | string
    format?: StringFieldUpdateOperationsInput | string
    size?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meta?: StringFieldUpdateOperationsInput | string
    status?: EnumUploadStatusFieldUpdateOperationsInput | $Enums.UploadStatus
    isDeleted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type ProjectDomainUpdateWithoutProjectInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
    domain?: DomainUpdateOneRequiredWithoutProjectDomainNestedInput
  }

  export type ProjectDomainUncheckedUpdateWithoutProjectInput = {
    domainId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type ProjectDomainUncheckedUpdateManyWithoutProjectInput = {
    domainId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type AuthorizationTokenUpdateWithoutProjectInput = {
    token?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AuthorizationTokenUncheckedUpdateWithoutProjectInput = {
    token?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AuthorizationTokenUncheckedUpdateManyWithoutProjectInput = {
    token?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    relation?: EnumAuthorizationRelationFieldUpdateOperationsInput | $Enums.AuthorizationRelation
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    canClone?: BoolFieldUpdateOperationsInput | boolean
    canCopy?: BoolFieldUpdateOperationsInput | boolean
  }

  export type ProjectDomainCreateManyDomainInput = {
    projectId: string
    createdAt?: Date | string
    txtRecord?: string
    cname: string
  }

  export type ProjectDomainUpdateWithoutDomainInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
    project?: ProjectUpdateOneRequiredWithoutProjectDomainNestedInput
  }

  export type ProjectDomainUncheckedUpdateWithoutDomainInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }

  export type ProjectDomainUncheckedUpdateManyWithoutDomainInput = {
    projectId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    txtRecord?: StringFieldUpdateOperationsInput | string
    cname?: StringFieldUpdateOperationsInput | string
  }



  /**
   * Aliases for legacy arg types
   */
    /**
     * @deprecated Use TeamCountOutputTypeDefaultArgs instead
     */
    export type TeamCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TeamCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use FileCountOutputTypeDefaultArgs instead
     */
    export type FileCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = FileCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use AssetCountOutputTypeDefaultArgs instead
     */
    export type AssetCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = AssetCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use UserCountOutputTypeDefaultArgs instead
     */
    export type UserCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = UserCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ProductCountOutputTypeDefaultArgs instead
     */
    export type ProductCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ProductCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ProjectCountOutputTypeDefaultArgs instead
     */
    export type ProjectCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ProjectCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use DomainCountOutputTypeDefaultArgs instead
     */
    export type DomainCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = DomainCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use TeamDefaultArgs instead
     */
    export type TeamArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TeamDefaultArgs<ExtArgs>
    /**
     * @deprecated Use FileDefaultArgs instead
     */
    export type FileArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = FileDefaultArgs<ExtArgs>
    /**
     * @deprecated Use AssetDefaultArgs instead
     */
    export type AssetArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = AssetDefaultArgs<ExtArgs>
    /**
     * @deprecated Use UserDefaultArgs instead
     */
    export type UserArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = UserDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ClientReferencesDefaultArgs instead
     */
    export type ClientReferencesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ClientReferencesDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ProductDefaultArgs instead
     */
    export type ProductArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ProductDefaultArgs<ExtArgs>
    /**
     * @deprecated Use TransactionLogDefaultArgs instead
     */
    export type TransactionLogArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TransactionLogDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ProjectDefaultArgs instead
     */
    export type ProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ProjectDefaultArgs<ExtArgs>
    /**
     * @deprecated Use BuildDefaultArgs instead
     */
    export type BuildArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = BuildDefaultArgs<ExtArgs>
    /**
     * @deprecated Use AuthorizationTokenDefaultArgs instead
     */
    export type AuthorizationTokenArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = AuthorizationTokenDefaultArgs<ExtArgs>
    /**
     * @deprecated Use DomainDefaultArgs instead
     */
    export type DomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = DomainDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ProjectDomainDefaultArgs instead
     */
    export type ProjectDomainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ProjectDomainDefaultArgs<ExtArgs>
    /**
     * @deprecated Use UserProductDefaultArgs instead
     */
    export type UserProductArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = UserProductDefaultArgs<ExtArgs>
    /**
     * @deprecated Use LatestStaticBuildPerProjectDefaultArgs instead
     */
    export type LatestStaticBuildPerProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = LatestStaticBuildPerProjectDefaultArgs<ExtArgs>
    /**
     * @deprecated Use DashboardProjectDefaultArgs instead
     */
    export type DashboardProjectArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = DashboardProjectDefaultArgs<ExtArgs>
    /**
     * @deprecated Use ApprovedMarketplaceProductDefaultArgs instead
     */
    export type ApprovedMarketplaceProductArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = ApprovedMarketplaceProductDefaultArgs<ExtArgs>

  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}