# Webstudio SDK

Webstudio SDK is a TypeScript API that lets you use your Webstudio project or some components in your custom codebase or just render a complete Remix Document.
It is currently under development, but feel free to play with the the current [landing site](https://github.com/webstudio-is/webstudio-landing)
