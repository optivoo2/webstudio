# Radix Components for Webstudio

Radix Primitives is a low-level UI component library with a focus on accessibility and customization.
Default styling is inspired by https://ui.shadcn.com/docs.
