export { meta as VideoAnimation } from "./video-animation.template";
