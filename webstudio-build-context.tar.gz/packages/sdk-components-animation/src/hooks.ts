import type { Hook } from "@webstudio-is/react-sdk";
import { hooksAnimateChildren } from "./animate-children";

export const hooks: Hook[] = [hooksAnimateChildren];
