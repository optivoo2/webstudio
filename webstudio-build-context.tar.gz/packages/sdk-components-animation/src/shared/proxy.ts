import { createProxy } from "@webstudio-is/template";

export const animation = createProxy("@webstudio-is/sdk-components-animation:");
