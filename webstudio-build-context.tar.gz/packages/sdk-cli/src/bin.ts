#!/usr/bin/env tsx --conditions=webstudio --experimental-import-meta-resolve
import "./cli";
