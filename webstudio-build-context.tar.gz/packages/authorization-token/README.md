# Webstudio Project

Project related functionalities. This was temporarily placed here to reuse between other packages, but we need to split this into separate packages and probably remove this package entirely or keep it only for "project" specific functionality.
