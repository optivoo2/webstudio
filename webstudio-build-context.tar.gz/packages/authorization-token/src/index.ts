export type { AuthorizationTokensRouter } from "./trpc";
export type { TokenPermissions } from "./db/authorization-token";
