export { Link as RichTextLink } from "./link";
